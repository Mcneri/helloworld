import { base44 } from './base44Client';


export const Member = base44.entities.Member;

export const Service = base44.entities.Service;

export const ConciergeInquiry = base44.entities.ConciergeInquiry;

export const ForumPost = base44.entities.ForumPost;

export const ForumComment = base44.entities.ForumComment;

export const MemberNote = base44.entities.MemberNote;

export const EmailTemplate = base44.entities.EmailTemplate;



// auth sdk:
export const User = base44.auth;