import { base44 } from './base44Client';


export const createPaymentIntent = base44.functions.createPaymentIntent;

export const handleStripeWebhook = base44.functions.handleStripeWebhook;

export const updateSubscription = base44.functions.updateSubscription;

export const cleanupMembers = base44.functions.cleanupMembers;

export const sitemap = base44.functions.sitemap;

export const sendWelcomeEmail = base44.functions.sendWelcomeEmail;

export const sendApplicationReceivedEmail = base44.functions.sendApplicationReceivedEmail;

export const sendAdminEmail = base44.functions.sendAdminEmail;

export const getStripePubKey = base44.functions.getStripePubKey;

export const sendRenewalReminders = base44.functions.sendRenewalReminders;

