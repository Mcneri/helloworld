import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, UserCog } from "lucide-react";

export default function AdminSignIn() {
  const navigate = useNavigate();

  useEffect(() => {
    const checkUser = async () => {
      try {
        const user = await User.me();
        if (user && user.role === 'admin') {
          navigate(createPageUrl("Admin"));
        } else if (user) {
          navigate(createPageUrl("Dashboard"));
        }
      } catch (e) {
        // User not logged in, stay on this page
      }
    };
    checkUser();
  }, [navigate]);

  const handleSignIn = async () => {
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Admin"));
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-0">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <UserCog className="w-8 h-8 text-purple-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Admin Sign In</CardTitle>
          <p className="text-gray-600">Access administrative functions and member management</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <Button onClick={handleSignIn} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg">
            Sign In with Google
          </Button>
          <div className="text-center text-sm text-gray-500">
            <p>Admin access only. <a href={createPageUrl("MemberSignIn")} className="text-purple-600 hover:underline">Member Sign In</a></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}