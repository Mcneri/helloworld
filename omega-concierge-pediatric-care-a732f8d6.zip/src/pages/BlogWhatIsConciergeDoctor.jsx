
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight, Phone, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CtaSection from '../components/home/CtaSection';
import MiniFAQ from '../components/MiniFAQ';
import PrefetchLink from '../components/PrefetchLink';

export default function BlogWhatIsConciergeDoctor() {
  useEffect(() => {
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    const title = "What is a Concierge Doctor? Private Pediatrician Near You | Atlanta DPC";
    const description = "Learn what a concierge doctor is and how concierge pediatric practice doctors offer personalized pediatric care Atlanta families trust. Find the best private pediatrician nearby offering direct primary care (DPC) and children's medical concierge services in Atlanta, GA.";
    document.title = title;

    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = description;
    metaDescription.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(metaDescription);

    const schema = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": window.location.href
      },
      "headline": "What is a Concierge Doctor? Private Pediatrician Near You Offering DPC Pediatric Care Atlanta",
      "alternativeHeadline": "Understanding Concierge Pediatric Practice and Children's Medical Concierge Services in Atlanta",
      "description": description,
      "image": "https://images.unsplash.com/photo-1584432810601-6c7f27d2362b?w=800&auto=format&fit=crop&q=60",
      "author": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Top Pediatrician Atlanta",
        "url": window.location.origin
      },
      "publisher": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Premier Pediatric Clinic Atlanta",
        "logo": {
          "@type": "ImageObject",
          "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png"
        },
        "url": window.location.origin
      },
      "datePublished": new Date().toISOString().split('T')[0],
      "dateModified": new Date().toISOString().split('T')[0],
      "keywords": "concierge doctor, private pediatrician near me, concierge pediatric practice, pediatric clinic atlanta, pediatric care atlanta, direct primary care, DPC, children's medical concierge, pediatrics atlanta, at home pediatrics, concierge medicine doctors nearby",
      "about": [
        {
          "@type": "Thing",
          "name": "Concierge Pediatric Medicine",
          "description": "Membership-based pediatric care offering unlimited visits and direct access to top pediatrician Atlanta"
        },
        {
          "@type": "Thing", 
          "name": "Direct Primary Care Atlanta",
          "description": "DPC model providing personalized pediatric care Atlanta families with private pediatrician nearby"
        },
        {
          "@type": "Thing",
          "name": "Dr. Michael Nwaneri",
          "description": "Leading pediatrician Atlanta GA with 30+ years experience, offering concierge doctor Atlanta services"
        }
      ],
      "mentions": [
        {
          "@type": "MedicalBusiness",
          "name": "Omega Pediatrics",
          "description": "Premier pediatric clinic Atlanta offering concierge pediatric practice and at home pediatrics services"
        }
      ]
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.innerHTML = JSON.stringify(schema);
    schemaScript.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(schemaScript);
  }, []);

  return (
    <div className="bg-white text-gray-800">
      <header className="relative py-20 md:py-32 bg-gradient-to-br from-blue-50 via-teal-50 to-green-50">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-1 lg:gap-8">
            <div className="mx-auto max-w-4xl px-4 sm:max-w-2xl sm:px-6 text-center lg:px-0 lg:flex lg:items-center">
              <div className="lg:py-24">
                <h1 className="mt-4 text-4xl tracking-tight font-extrabold text-gray-900 sm:mt-5 sm:text-6xl lg:mt-6 xl:text-6xl">
                  <span className="block">What is a Concierge Doctor?</span>
                  <span className="block text-teal-600">Unpacking the Model</span>
                </h1>
                <div className="mt-10 sm:mt-12">
                  <Link to={createPageUrl("Services")}>
                    <Button size="lg" className="btn-enhanced bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg">
                      Explore Our Services
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 prose prose-lg prose-indigo">
        <p className="lead">
          Ever heard the term "concierge doctor" and wondered what it's all about? It's a question a lot of families are asking these days, especially when it comes to their kids' health. The easiest way to think about a <strong>concierge doctor</strong> is that they are part of a membership-based healthcare model, also known as <strong>direct primary care</strong> or <strong>DPC</strong>. This approach is all about putting you and your child first, giving you more time, better access, and truly personalized care. It's a game-changer that lets your pediatrician genuinely focus on your child's unique health needs, without the usual rush.
        </p>

        <figure className="my-12">
          {/* PERF: Added responsive sources, width/height, loading, and decoding attributes */}
          <picture>
            <source
              media="(min-width: 768px)"
              srcSet="https://images.unsplash.com/photo-1551192422-a5b6f04b23de?w=800&auto=format&fit=crop&q=80 800w, https://images.unsplash.com/photo-1551192422-a5b6f04b23de?w=1200&auto=format&fit=crop&q=80 1200w"
              sizes="800px"
            />
            <img
              src="https://images.unsplash.com/photo-1551192422-a5b6f04b23de?w=600&auto=format&fit=crop&q=80"
              srcSet="https://images.unsplash.com/photo-1551192422-a5b6f04b23de?w=400&auto=format&fit=crop&q=80 400w, https://images.unsplash.com/photo-1551192422-a5b6f04b23de?w=600&auto=format&fit=crop&q=80 600w"
              sizes="(max-width: 639px) 400px, 600px"
              alt="A caring doctor is listening to a child's heartbeat with a stethoscope."
              className="rounded-xl shadow-2xl w-full"
              width="800"
              height="533"
              loading="lazy"
              decoding="async"
            />
          </picture>
          <figcaption className="text-center text-sm text-gray-500 mt-2">
            The concierge model focuses on a stronger, more personal doctor-patient relationship.
          </figcaption>
        </figure>

        <h2>What is a Concierge Doctor?</h2>
        <p>
          Tired of crowded waiting rooms and feeling like your appointment is over before it even begins? Families who choose a <strong>concierge pediatric practice</strong> get to skip all that. They enjoy perks like same-day appointments, longer visits, and a direct line to their doctor via phone, text, or email. This model builds a much deeper doctor-patient relationship, leading to more proactive and thorough <strong>pediatric care Atlanta</strong> families can really count on. If you're searching for <strong>concierge medicine doctors nearby</strong> who prioritize both accessibility and a personal touch, understanding this <strong>DPC</strong> model is the perfect first step. It's truly about investing in a healthcare experience that's tailored specifically for your family.
        </p>
        
        <figure className="my-12 float-right ml-8 w-1/2 hidden md:block">
          {/* PERF: Added responsive sources, width/height, loading, and decoding attributes */}
          <picture>
            <source 
              srcSet="https://images.unsplash.com/photo-1584515933487-779824d29309?w=400&auto=format&fit=crop&q=80 400w, https://images.unsplash.com/photo-1584515933487-779824d29309?w=600&auto=format&fit=crop&q=80 600w"
              sizes="400px"
            />
            <img
              src="https://images.unsplash.com/photo-1584515933487-779824d29309?w=400&auto=format&fit=crop&q=80"
              alt="A doctor and patient having a detailed discussion in a comfortable office."
              className="rounded-xl shadow-xl"
              width="400"
              height="600"
              loading="lazy"
              decoding="async"
            />
          </picture>
          <figcaption className="text-center text-sm text-gray-500 mt-2">
            Longer, unhurried appointments are a key benefit.
          </figcaption>
        </figure>

        <p>
          Here in Atlanta, many young mothers are looking for a <strong>private pediatrician near your home</strong> that offers this kind of dedicated care. The demand for such a personal approach has grown nationwide, and for good reason. At the heart of Omega Pediatrics, our <strong>concierge doctor Atlanta</strong> service is led by Dr. Michael Nwaneri. With over 30 years of experience practicing in the UK, Nigeria, Ghana, and now the USA, Dr. Nwaneri has a remarkable way of connecting with both parents and children. When he walks into a room, concerns, worries, and even illness seem to just… fade away.
        </p>
        
        <p>
          Dr. Nwaneri’s straightforward approach and knack for explaining complex medical ideas using simple metaphors are truly impressive—he makes things so clear that anyone can understand! This unique clarity is a huge reason our team's standout approach to pediatric care is in such high demand across Atlanta. Choosing our advanced <strong>children's medical concierge</strong> care offers tremendous peace of mind, knowing your child’s well-being is in the hands of a pediatrician who deeply understands them. It’s a real departure from impersonal healthcare, offering a holistic approach to your child’s needs, whether at our welcoming <strong>pediatric clinic Atlanta</strong> or, for eligible plans, through the incredible convenience of <strong>at home pediatrics</strong>.
        </p>
        <h3>Key Characteristics of Concierge Medicine:</h3>
      </article>

      <CtaSection />
    </div>
  );
}
