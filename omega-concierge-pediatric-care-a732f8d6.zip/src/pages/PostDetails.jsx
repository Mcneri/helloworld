import React, { useState, useEffect } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { ForumPost } from "@/api/entities";
import { ForumComment } from "@/api/entities";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, User as UserIcon, ArrowLeft } from "lucide-react";
import { format } from "date-fns";

export default function PostDetails() {
  const [post, setPost] = useState(null);
  const [comments, setComments] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [newComment, setNewComment] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const location = useLocation();
  const navigate = useNavigate();
  const postId = new URLSearchParams(location.search).get("id");

  const loadData = async () => {
    if (!postId) {
      navigate(createPageUrl("Forum"));
      return;
    }
    try {
      const user = await User.me();
      setCurrentUser(user);
      const postData = await ForumPost.get(postId);
      setPost(postData);
      const commentData = await ForumComment.filter({ post_id: postId }, '-created_date');
      setComments(commentData);
    } catch (error) {
      console.error("Error fetching post details:", error);
      navigate(createPageUrl("Forum"));
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [postId, navigate]);

  const handleCreateComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim() || !currentUser) return;
    setIsSubmitting(true);
    try {
      await ForumComment.create({
        content: newComment,
        post_id: postId,
        author_name: currentUser.full_name,
        author_email: currentUser.email,
      });
      setNewComment("");
      await loadData(); // Reload comments
    } catch (error) {
      console.error("Failed to post comment:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;
  }

  if (!post) {
    return <div className="text-center py-12">Post not found.</div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <Link to={createPageUrl("Forum")} className="flex items-center gap-2 text-blue-600 hover:underline mb-6">
          <ArrowLeft className="w-4 h-4" />
          Back to Forum
        </Link>
        
        {/* Post */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="text-2xl md:text-3xl">{post.title}</CardTitle>
            <div className="text-sm text-gray-500 flex items-center gap-4 pt-2">
              <div className="flex items-center gap-2"><UserIcon className="w-4 h-4"/>{post.author_name}</div>
              <span>{format(new Date(post.created_date), 'MMMM d, yyyy HH:mm')}</span>
            </div>
          </CardHeader>
          <CardContent className="prose max-w-none text-gray-800">
            <p>{post.content}</p>
          </CardContent>
        </Card>

        {/* Comments */}
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Comments ({comments.length})</h2>
        
        {/* New Comment Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-lg">Leave a Comment</CardTitle>
          </CardHeader>
          <form onSubmit={handleCreateComment}>
            <CardContent>
              <Textarea
                placeholder="Write your comment here..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                required
                rows={4}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Submitting...</> : "Post Comment"}
              </Button>
            </CardFooter>
          </form>
        </Card>

        {/* Existing Comments */}
        <div className="space-y-6">
          {comments.map(comment => (
            <Card key={comment.id}>
              <CardHeader className="pb-2">
                <div className="flex items-center gap-2 text-sm">
                  <UserIcon className="w-4 h-4" />
                  <span className="font-semibold text-gray-800">{comment.author_name}</span>
                  <span className="text-gray-500">{format(new Date(comment.created_date), 'MMM d, yyyy')}</span>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700">{comment.content}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}