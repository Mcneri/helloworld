
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CtaSection from '../components/home/CtaSection';

export default function BlogAreTheyWorthIt() {
  useEffect(() => {
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    const title = "Are Concierge Doctors Worth It? Top Pediatrician Atlanta Cost & Value";
    const description = "Discover if concierge doctors are worth the investment. Learn about pediatrician Atlanta GA costs, pediatric care Atlanta benefits, and why families choose our concierge pediatric practice over pediatric urgent care Atlanta visits.";
    document.title = title;

    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = description;
    metaDescription.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(metaDescription);
    
    const schema = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": window.location.href
      },
      "headline": "Are Concierge Doctors Worth It? Top Pediatrician Atlanta Value vs Pediatric Urgent Care Atlanta",
      "alternativeHeadline": "Understanding Concierge Doctor Costs and Benefits for Pediatric Care Atlanta Families",
      "description": description,
      "image": "https://images.unsplash.com/photo-1550831107-1553da8c8464?auto=format&fit=crop&q=60&fm=webp&w=800",
      "author": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Leading Pediatrician Atlanta GA",
        "url": window.location.origin
      },
      "publisher": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Premier Children Doctor Atlanta",
        "logo": {
          "@type": "ImageObject",
          "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png"
        },
        "url": window.location.origin
      },
      "datePublished": new Date().toISOString().split('T')[0],
      "dateModified": new Date().toISOString().split('T')[0],
      "keywords": "concierge doctors worth it, top pediatrician atlanta, pediatric care atlanta, pediatric urgent care atlanta, concierge doctor cost, pediatrician atlanta ga, children doctor atlanta, at home pediatrics, direct primary care, DPC",
      "about": [
        {
          "@type": "Thing",
          "name": "Concierge Doctor Value",
          "description": "Cost-benefit analysis of top pediatrician Atlanta concierge services vs traditional pediatric urgent care Atlanta visits"
        },
        {
          "@type": "Thing",
          "name": "Dr. Michael Nwaneri Excellence", 
          "description": "Why families travel 2+ hours for this top pediatrician Atlanta offering personalized pediatric care Atlanta"
        },
        {
          "@type": "Thing",
          "name": "At Home Pediatrics Benefits",
          "description": "Convenience of at home pediatrics services and children's medical concierge care"
        }
      ],
      "mentions": [
        {
          "@type": "Person",
          "name": "Dr. Michael Nwaneri",
          "description": "Top pediatrician Atlanta GA with 30+ years experience, leading children doctor Atlanta practice"
        }
      ]
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.innerHTML = JSON.stringify(schema);
    schemaScript.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(schemaScript);
  }, []);

  return (
    <div className="bg-white">
      <div className="relative pt-12 pb-16 sm:pt-16 sm:pb-24 lg:pt-24 lg:pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-1 lg:gap-8">
            <div className="mx-auto max-w-4xl px-4 sm:max-w-2xl sm:px-6 text-center lg:px-0 lg:flex lg:items-center">
              <div className="lg:py-24">
                <h1 className="mt-4 text-4xl tracking-tight font-extrabold text-gray-900 sm:mt-5 sm:text-6xl lg:mt-6 xl:text-6xl">
                  <span className="block">Are Concierge Doctors Worth It?</span>
                  <span className="block text-teal-600">Understanding the Value</span>
                </h1>
                <div className="mt-6 text-left max-w-4xl mx-auto space-y-6 text-lg text-gray-700 leading-relaxed">
                  <p>
                    "Are concierge doctors worth it?" This is one of the most common questions we hear from families considering this unique healthcare model. While choosing a <strong>concierge doctor</strong> does involve a membership fee, the value you get often far outweighs the cost. This is especially true for pediatric care, where having quick, easy access to a doctor is absolutely essential. Parents consistently tell us that the peace of mind they gain is priceless.
                  </p>
                  
                  <p>
                    So, you might be wondering, "How much does <strong>concierge doctor</strong> care cost?" The annual or monthly fee can vary, but it unlocks some incredible benefits. Imagine unlimited wellness visits, a direct line to your pediatrician by phone or text, and priority scheduling—meaning you get appointments when you need them most. For many families, avoiding rushed visits to <strong>pediatric urgent care Atlanta</strong> and having a physician who truly knows your child's health history inside and out makes a <strong>concierge doctor</strong> a truly wise investment. When you're searching for <strong>concierge doctors near you</strong>, it's so important to think beyond the price tag and focus on the comprehensive, high-quality care that improves health outcomes and reduces stress for your whole family. For countless parents, choosing a <strong>top pediatrician Atlanta</strong> through the concierge model is absolutely worth it.
                  </p>
                  
                  <p>
                    At Omega Pediatrics, families literally drive for two hours just to have their child seen by Dr. Michael Nwaneri. His almost spiritual way of connecting with both parents and children is legendary. Parents tell us that when Dr. Nwaneri enters a room, their concerns and worries about illness seem to just vanish. This level of impact is just one of the reasons he is considered a <strong>top pediatrician Atlanta</strong> parents choose, making him an invaluable partner in your child's health journey. This highly personalized care, which is a key part of our <strong>direct primary care</strong> model, fundamentally changes the dynamic of your child's medical experience.
                  </p>
                  
                  <p>
                    Consider the convenience of services like <strong>at home pediatrics</strong>, sometimes included in higher-tier plans, which further simplifies how your family's <strong>pediatric care Atlanta</strong> needs are met. This level of accessible and personalized care, combined with Dr. Nwaneri's unique ability to make complex medical concepts understandable through his direct, metaphor-filled communication style, truly justifies the investment. With over 30 years of experience across multiple countries, he brings a depth of knowledge that's rarely found in traditional practice settings. When parents experience this level of care and see their children's health flourish under such dedicated attention, the value becomes crystal clear—and for most families, a <strong>concierge doctor</strong> is absolutely worth every penny.
                  </p>
                </div>
                <div className="mt-10 sm:mt-12">
                  <Link to={createPageUrl("Plans")}>
                    <Button size="lg" className="btn-enhanced bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg">
                      View Plans & Pricing
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <CtaSection />
    </div>
  );
}
