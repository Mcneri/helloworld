import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  HelpCircle,
  ExternalLink,
  ArrowRight
} from "lucide-react";

import FAQSection from "../components/FAQSection";
import { faqsByPage } from "../components/ExpandableFAQSection";
import CtaSection from "../components/home/CtaSection"; // Corrected path

export default function FAQ() {
  const [faqs, setFaqs] = useState([]);

  useEffect(() => {
    // Populate the faqs state from the existing source
    setFaqs(faqsByPage.FAQ || []);

    // SEO and Metadata Setup
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());

    const title = "Concierge Pediatrics FAQ | DPC Membership Questions Atlanta GA";
    const description = "Get answers about concierge pediatrics, DPC plans, billing, services & more. Complete FAQ for Atlanta families considering membership pediatrics care.";
    
    document.title = title;

    const createMetaTag = (attrs) => {
        const el = document.createElement('meta');
        Object.keys(attrs).forEach(attr => el.setAttribute(attr, attrs[attr]));
        el.setAttribute('data-b44-seo', 'true');
        document.head.appendChild(el);
    };

    createMetaTag({ name: 'description', content: description });
    
    // Twitter Card
    createMetaTag({ name: 'twitter:card', content: 'summary' });
    createMetaTag({ name: 'twitter:title', content: title });
    createMetaTag({ name: 'twitter:description', content: description });

    // Schema.org - FAQPage
    const allFAQsForSchema = faqsByPage.FAQ || [];
    if (Array.isArray(allFAQsForSchema) && allFAQsForSchema.length > 0) {
      const extractTextFromAnswer = (answer) => {
        if (typeof answer === 'string') {
          return answer.replace(/<[^>]*>?/gm, '');
        } else if (React.isValidElement(answer) || typeof answer === 'object' && answer !== null && !Array.isArray(answer)) {
          return "Please visit our website for detailed information about this topic.";
        } else {
          return String(answer).replace(/<[^>]*>?/gm, '');
        }
      };

      const schema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": allFAQsForSchema.map(faq => ({
          "@type": "Question",
          "name": faq.question,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": extractTextFromAnswer(faq.answer)
          }
        }))
      };
      
      const schemaScript = document.createElement('script');
      schemaScript.type = 'application/ld+json';
      schemaScript.innerHTML = JSON.stringify(schema);
      schemaScript.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(schemaScript);
    }

    // Cleanup function
    return () => {
      document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    };

  }, []);

  return (
    <div className="bg-white">
      {/* Enhanced Header */}
      <section className="relative bg-gradient-to-r from-teal-500 via-cyan-500 to-sky-500 text-white overflow-hidden rounded-3xl mx-4 sm:mx-6 lg:mx-auto max-w-5xl mb-12">
        <div className="absolute inset-0">
          <div className="absolute top-10 left-20 w-16 h-16 bg-teal-200/20 rounded-full animate-bounce delay-100"></div>
          <div className="absolute bottom-12 right-24 w-12 h-12 bg-sky-200/20 rounded-full animate-pulse"></div>
          <div className="absolute top-1/2 left-1/3 w-8 h-8 bg-white/20 rounded-full animate-ping"></div>
          <div className="absolute bottom-1/4 right-1/3 w-20 h-20 bg-cyan-200/20 rounded-full animate-pulse delay-300"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-full mb-4 animate-pulse">
                <HelpCircle className="w-10 h-10 text-cyan-200" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Frequently Asked <span className="text-cyan-200">Questions</span>
            </h1>
            <p className="text-xl text-teal-100 max-w-3xl mx-auto">
              Find comprehensive answers to all your questions about Omega Pediatrics Premium Membership Care.
            </p>
            <div className="mt-6 flex justify-center">
              <div className="w-2 h-2 bg-teal-200 rounded-full animate-ping"></div>
              <div className="w-2 h-2 bg-sky-200 rounded-full animate-ping delay-100"></div>
              <div className="w-2 h-2 bg-cyan-200 rounded-full animate-ping delay-200"></div>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="sr-only">Complete List of Frequently Asked Questions</h2>
        <FAQSection faqs={faqs} />

        {/* Guidance for Choosing a Doctor Section */}
        <section className="bg-gray-50 py-16 mt-12 mb-12 rounded-lg shadow-sm">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Guidance for Choosing Your Pediatric Concierge
            </h2>
            <p className="text-lg text-gray-600 mb-4">
              Knowing "<strong>how to find a concierge doctor</strong>" is the first step. It's about more than just searching for "<strong>concierge doctors in my area</strong>"; it's about finding a true healthcare partner for your family.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              We provide tips on what to look for when you want to <strong>find concierge doctor near me</strong>, ensuring you make the best choice for your children's needs.
            </p>
            <Link to={createPageUrl("BlogHowToFind")}>
              <Button size="lg" variant="outline" className="btn-enhanced border-gray-300 hover:bg-teal-50 hover:border-teal-300 text-gray-700 hover:text-teal-700 transition-colors duration-200">
                Read Our Guide to Finding a Doctor
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </section>

        {/* Contact Section */}
        <Card className="shadow-lg border-0 mt-8 bg-gradient-to-r from-teal-50 to-cyan-50">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Still Have Questions?</h3>
            <p className="text-gray-600 mb-6">
              Can't find what you're looking for? Our team is here to help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild className="bg-teal-600 hover:bg-teal-700">
                <a href="tel:470-485-6342">Call Us: 470-485-6342</a>
              </Button>
              <Button asChild variant="outline">
                <a href="mailto:info@omegapediatrics.com">Email Us</a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <CtaSection />
    </div>
  );
}