
import React, { useState, useEffect, lazy, Suspense, useMemo, useCallback } from "react";
import { FixedSizeList as List } from 'react-window';
import { User } from "@/api/entities";
import { Member } from "@/api/entities";
import { ConciergeInquiry } from "@/api/entities";
import { MemberNote } from "@/api/entities";
import { sendWelcomeEmail } from "@/api/functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Loader2, ShieldCheck, AlertTriangle, Eye, Archive, Trash2, Users,
  Calendar, DollarSign, UserCog, Send, Briefcase, Mail, Phone, CheckSquare,
  Clock, XCircle, MoreHorizontal, LayoutTemplate, BarChart, TrendingUp, PieChart
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

// Lazy load heavy admin components
const EmailSender = lazy(() => import("../components/EmailSender"));
const EmailTemplateManager = lazy(() => import("../components/EmailTemplateManager"));

// MemberSummary component now manages its own state for notes
const MemberSummary = ({ member, adminUser }) => {
  const [notes, setNotes] = useState([]);
  const [newNote, setNewNote] = useState("");
  const [isSubmittingNote, setIsSubmittingNote] = useState(false);
  const [isLoadingNotes, setIsLoadingNotes] = useState(true);

  useEffect(() => {
    if (member) {
      const fetchNotes = async () => {
        setIsLoadingNotes(true);
        try {
          const memberNotes = await MemberNote.filter({ member_id: member.id }, '-created_date');
          setNotes(memberNotes || []); // Added safety check
        } catch (error) {
          console.error("Failed to fetch notes:", error);
          setNotes([]); // Set empty array on error
        }
        setIsLoadingNotes(false);
      };
      fetchNotes();
    }
  }, [member]);

  const handleAddNote = async (e) => {
    e.preventDefault();
    if (!newNote.trim() || !adminUser) return;
    setIsSubmittingNote(true);
    try {
      await MemberNote.create({
        member_id: member.id,
        content: newNote,
        author_name: adminUser.full_name,
      });
      setNewNote("");
      const memberNotes = await MemberNote.filter({ member_id: member.id }, '-created_date');
      setNotes(memberNotes || []); // Added safety check
      toast.success("Note added successfully!");
    } catch (error) {
      console.error("Failed to add note:", error);
      toast.error("Failed to add note. Please try again.");
    } finally {
      setIsSubmittingNote(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <h4 className="font-semibold text-gray-900 mb-2">Contact Information</h4>
          <div className="space-y-2 text-sm">
            <p><strong>Name:</strong> {member.full_name}</p>
            <p><strong>Email:</strong> {member.email}</p>
            <p><strong>Phone:</strong> {member.phone}</p>
          </div>
        </div>
        <div>
          <h4 className="font-semibold text-gray-900 mb-2">Membership Details</h4>
          <div className="space-y-2 text-sm">
            <p><strong>Plan:</strong> {member.plan_tier} ({member.payment_frequency})</p>
            <p><strong>Status:</strong> <Badge className={getStatusColor(member.status)}>{member.status}</Badge></p>
            <p><strong>Children:</strong> {member.children_count}</p>
            <p><strong>Payment Method:</strong> {member.payment_method}</p>
          </div>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-gray-900 mb-2">Financial Information</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <p><strong>Monthly Amount:</strong> ${member.monthly_amount}</p>
          <p><strong>Annual Amount:</strong> ${member.annual_amount}</p>
          <p><strong>Start Date:</strong> {format(new Date(member.start_date), 'MMM d, yyyy')}</p>
          <p><strong>Renewal Date:</strong> {format(new Date(member.renewal_date), 'MMM d, yyyy')}</p>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-gray-900 mb-2">Admin Notes</h4>
        <div className="space-y-4">
          <form onSubmit={handleAddNote} className="flex gap-2">
            <Textarea
              placeholder="Add a new note..."
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              className="flex-grow"
              rows={2}
            />
            <Button type="submit" size="icon" disabled={isSubmittingNote}>
              {isSubmittingNote ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </Button>
          </form>
          <div className="max-h-60 overflow-y-auto space-y-3 pr-2">
            {isLoadingNotes ? (
              <div className="flex justify-center p-4"><Loader2 className="w-6 h-6 animate-spin text-gray-400"/></div>
            ) : (notes && notes.length > 0) ? (
              notes.map(note => (
                <div key={note.id} className="bg-gray-50 p-3 rounded-lg text-sm">
                  <p className="text-gray-800">{note.content}</p>
                  <p className="text-xs text-gray-500 mt-2 text-right">
                    - {note.author_name} on {format(new Date(note.created_date), 'MMM d, yyyy @ h:mm a')}
                  </p>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">No notes for this member yet.</p>
            )}
          </div>
        </div>
      </div>

      <div>
        <h4 className="font-semibold text-gray-900 mb-2">Account History</h4>
        <div className="text-sm space-y-1">
          <p><strong>Created:</strong> {format(new Date(member.created_date), 'MMM d, yyyy HH:mm')}</p>
          <p><strong>Last Updated:</strong> {format(new Date(member.updated_date), 'MMM d, yyyy HH:mm')}</p>
        </div>
      </div>
    </div>
  );
};

// VIRTUALIZATION: The Row component for the virtualized list.
// It's defined outside the main component to prevent recreation on re-renders.
// `style` is passed by react-window to position the item absolutely.
const MemberRow = ({ index, style, data }) => {
    const { members, handleRowClick, getStatusColor, user, isUpdating, isDeleting, handleStatusChange, handleDeleteMember, setSelectedMember, MemberActionsDropdownComponent } = data;
    const member = members[index];

    // Ensure member exists before rendering
    if (!member) return null;

    return (
        <div
            style={style}
            key={member.id}
            className="group hover:bg-teal-50 border-b border-gray-200"
        >
            {/* Using a table row inside a div for fixed-size list for consistent styling, though not ideal */}
            {/* The fixed size list expects a single root element per item, so we're making the div the row */}
            <TableRow className="w-full grid grid-cols-[1.5fr_2fr_1fr_1fr_1fr_0.5fr] items-center"> {/* Adjusted grid-cols to match table header below */}
                <TableCell className="p-3 text-sm text-gray-700 font-medium">
                    <span className="cursor-pointer hover:underline" onClick={() => handleRowClick(member)}>
                        {member.full_name}
                    </span>
                </TableCell>
                <TableCell className="p-3 text-sm text-gray-500">{member.email}</TableCell>
                <TableCell className="p-3 text-sm text-gray-500 capitalize">{member.plan_tier}</TableCell>
                <TableCell className="p-3 text-sm text-gray-500 capitalize">{member.payment_frequency}</TableCell>
                <TableCell className="p-3 text-sm text-gray-500">
                    <Badge className={getStatusColor(member.status)}> {/* Using getStatusColor for consistency */}
                        {member.status}
                    </Badge>
                </TableCell>
                <TableCell className="text-right pr-3"> {/* Added padding for actions */}
                    <MemberActionsDropdownComponent
                        member={member}
                        user={user}
                        isUpdating={isUpdating}
                        isDeleting={isDeleting}
                        handleStatusChange={handleStatusChange}
                        handleDeleteMember={handleDeleteMember}
                        setSelectedMember={setSelectedMember}
                    />
                </TableCell>
            </TableRow>
        </div>
    );
};

// ConciergeInterestTab component with safety checks
function ConciergeInterestTab({ conciergeInquiries = [], isLoadingData }) {
  const getStatusColor = (status) => {
      switch (status) {
          case 'new': return 'bg-blue-100 text-blue-800';
          case 'lead': return 'bg-yellow-100 text-yellow-800';
          case 'contacted': return 'bg-green-100 text-green-800';
          case 'closed': return 'bg-gray-100 text-gray-800';
          default: return 'bg-gray-100 text-gray-800';
      }
  };

  if (isLoadingData) return <div className="flex justify-center items-center h-64"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Diamond Concierge Inquiries</CardTitle>
        <CardDescription>
          Users who have expressed interest in the Diamond Concierge plan. "Lead" status means they viewed details; "New" means they submitted the full inquiry.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Date</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Message</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {conciergeInquiries && conciergeInquiries.length > 0 ? (
              conciergeInquiries.map(inquiry => (
                <TableRow key={inquiry.id}>
                  <TableCell className="text-sm text-gray-500">{format(new Date(inquiry.created_date), 'MMM d, yyyy h:mm a')}</TableCell>
                  <TableCell className="font-medium">{inquiry.full_name || 'Lead'}</TableCell>
                  <TableCell>
                    {inquiry.email}
                    {inquiry.initial_email && (
                        <span className="block text-xs text-gray-500 italic">
                            (was: {inquiry.initial_email})
                        </span>
                    )}
                  </TableCell>
                  <TableCell>
                    {inquiry.phone || 'N/A'}
                    {inquiry.initial_phone && (
                        <span className="block text-xs text-gray-500 italic">
                            (was: {inquiry.initial_phone})
                        </span>
                    )}
                  </TableCell>
                  <TableCell className="max-w-xs truncate">{inquiry.message}</TableCell>
                  <TableCell>
                    <Badge className={`${getStatusColor(inquiry.status)} capitalize`}>
                        {inquiry.status}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan="6" className="text-center py-8 text-gray-500">No inquiries yet.</TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function StatisticsTab({ allMembers = [] }) { // Added default value
  try {
    // Calculate statistics with safe defaults
    const totalMembers = allMembers.length;
    const activeMembers = allMembers.filter(m => m.status === 'active').length;
    const pendingMembers = allMembers.filter(m => m.status === 'pending').length;
    
    // Plan tier breakdown
    const planBreakdown = allMembers.reduce((acc, member) => {
      if (member.plan_tier) {
        acc[member.plan_tier] = (acc[member.plan_tier] || 0) + 1;
      }
      return acc;
    }, {});

    // Payment frequency breakdown
    const paymentFrequencyBreakdown = allMembers.reduce((acc, member) => {
      if (member.payment_frequency) {
        acc[member.payment_frequency] = (acc[member.payment_frequency] || 0) + 1;
      }
      return acc;
    }, {});

    // Recent signups (last 7 and 30 days) - simplified calculation
    const now = new Date();
    const last7Days = new Date(now.getTime() - (7 * 24 * 60 * 60 * 1000));
    const last30Days = new Date(now.getTime() - (30 * 24 * 60 * 60 * 1000));
    
    const recentSignups7 = allMembers.filter(m => {
      if (!m.created_date) return false;
      const createdDate = new Date(m.created_date);
      return createdDate > last7Days;
    }).length;
    
    const recentSignups30 = allMembers.filter(m => {
      if (!m.created_date) return false;
      const createdDate = new Date(m.created_date);
      return createdDate > last30Days;
    }).length;

    // Revenue calculations (approximate)
    const totalMonthlyRevenue = allMembers
      .filter(m => m.status === 'active')
      .reduce((sum, member) => {
        if (!member.monthly_amount && !member.annual_amount) return sum;
        const monthlyAmount = member.payment_frequency === 'annual' 
          ? (member.annual_amount || 0) / 12 
          : (member.monthly_amount || 0);
        return sum + monthlyAmount;
      }, 0);

    return (
      <div className="space-y-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Membership Statistics</h2>
          <p className="text-gray-600">Overview of your membership analytics</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{totalMembers}</div>
                <div className="text-sm text-gray-600">Total Members</div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <CheckSquare className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{activeMembers}</div>
                <div className="text-sm text-gray-600">Active Members</div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">{pendingMembers}</div>
                <div className="text-sm text-gray-600">Pending Members</div>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-teal-100 rounded-lg flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-teal-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-gray-900">${Math.round(totalMonthlyRevenue)}</div>
                <div className="text-sm text-gray-600">Monthly Revenue</div>
              </div>
            </div>
          </Card>
        </div>

        {/* Plan Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <PieChart className="w-5 h-5 text-blue-600" />
              <h3 className="text-lg font-semibold text-gray-900">Plan Distribution</h3>
            </div>
            <div className="space-y-3">
              {Object.entries(planBreakdown).length > 0 ? Object.entries(planBreakdown).map(([plan, count]) => (
                <div key={plan} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${
                      plan === 'bronze' ? 'bg-amber-500' :
                      plan === 'silver' ? 'bg-gray-400' :
                      plan === 'gold' ? 'bg-yellow-500' : 'bg-purple-500'
                    }`}></div>
                    <span className="font-medium text-gray-700 capitalize">{plan}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-gray-900">{count}</span>
                    <span className="text-sm text-gray-500 ml-1">({totalMembers > 0 ? Math.round((count / totalMembers) * 100) : 0}%)</span>
                  </div>
                </div>
              )) : (
                <p className="text-gray-500 text-center py-4">No plan data available</p>
              )}
            </div>
          </Card>

          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <BarChart className="w-5 h-5 text-green-600" />
              <h3 className="text-lg font-semibold text-gray-900">Payment Frequency</h3>
            </div>
            <div className="space-y-3">
              {Object.entries(paymentFrequencyBreakdown).length > 0 ? Object.entries(paymentFrequencyBreakdown).map(([frequency, count]) => (
                <div key={frequency} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${
                      frequency === 'annual' ? 'bg-green-500' : 'bg-blue-500'
                    }`}></div>
                    <span className="font-medium text-gray-700 capitalize">{frequency}</span>
                  </div>
                  <div className="text-right">
                    <span className="font-bold text-gray-900">{count}</span>
                    <span className="text-sm text-gray-500 ml-1">({totalMembers > 0 ? Math.round((count / totalMembers) * 100) : 0}%)</span>
                  </div>
                </div>
              )) : (
                <p className="text-gray-500 text-center py-4">No payment data available</p>
              )}
            </div>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="w-5 h-5 text-purple-600" />
            <h3 className="text-lg font-semibold text-gray-900">Recent Activity</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-purple-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-purple-700">{recentSignups7}</div>
              <div className="text-sm text-purple-600">New members (7 days)</div>
            </div>
            <div className="bg-indigo-50 rounded-lg p-4">
              <div className="text-2xl font-bold text-indigo-700">{recentSignups30}</div>
              <div className="text-sm text-indigo-600">New members (30 days)</div>
            </div>
          </div>
        </Card>
      </div>
    );
  } catch (error) {
    console.error('Error in StatisticsTab:', error);
    return (
      <div className="text-center py-8">
        <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Statistics Unavailable</h3>
        <p className="text-gray-600">There was an error loading the statistics. Please try refreshing the page.</p>
      </div>
    );
  }
}


export default function Admin() {
  const [activeTab, setActiveTab] = useState("members");
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [members, setMembers] = useState([]);
  const [inquiries, setInquiries] = useState([]);
  const [allAdmins, setAllAdmins] = useState([]);
  const [selectedMember, setSelectedMember] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [isUpdating, setIsUpdating] = useState(null);
  const [isDeleting, setIsDeleting] = useState(null);
  const [isCleaning, setIsCleaning] = useState(false);

  // FIX: Moved useMemo hooks to the top level, before any early returns.
  const filteredMembers = useMemo(() =>
    members.filter(member =>
      member.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      member.email.toLowerCase().includes(searchTerm.toLowerCase())
    ),
    [members, searchTerm]
  );
  
  const pendingMembers = useMemo(() => members.filter(member => member.status === 'pending'), [members]);

  // FIX: Wrapped `loadAllData` in useCallback to give it a stable identity.
  const loadAllData = useCallback(async () => {
    // Guard against running before user is set or if not an admin.
    if (!user || user.role !== 'admin') {
      setIsLoading(false); // Stop loading if no user or not admin
      return;
    }
    
    setIsLoading(true);
    try {
      const [all, inquiriesData] = await Promise.all([
        Member.list('-created_date'),
        ConciergeInquiry.list('-created_date')
      ]);
      setMembers(all || []);
      setInquiries(inquiriesData || []);

      if (user.admin_level === 'super') {
        const admins = await User.filter({ role: 'admin' });
        setAllAdmins(admins || []);
      } else {
        setAllAdmins([]);
      }
    } catch (error) {
      console.error("Error loading admin data:", error);
      toast.error("Failed to load admin data.");
      setMembers([]);
      setInquiries([]);
      setAllAdmins([]);
    } finally {
      setIsLoading(false);
    }
  }, [user]); // Now this function only changes if the `user` object changes.

  // Effect 1: Loads current user once on mount.
  useEffect(() => {
    const loadCurrentUser = async () => {
      setIsLoading(true); // Set initial loading state for user fetch
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        // Do NOT call loadAllData here directly. It will be triggered by the next effect
        // when `user` state updates, and `loadAllData` reference changes.
      } catch (error) {
        console.error("Error loading current user:", error);
        toast.error("Failed to load user data.");
        setUser(null); // Ensure user is null on error
        setIsLoading(false); // Stop loading if user fetch fails
      }
    };
    loadCurrentUser();
  }, []); // Empty dependency array means this runs once on mount

  // Effect 2: Triggers data loading when `user` (or the memoized `loadAllData` which depends on user) changes.
  useEffect(() => {
    loadAllData();
  }, [loadAllData]); // This effect now correctly depends on the memoized loadAllData.

  const getStatusColor = useCallback((status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'archived': return 'bg-gray-100 text-gray-800';
      case 'cancelled': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }, []);

  // FIX: All these useCallback hooks now have a stable `loadAllData` dependency.
  const handleStatusChange = useCallback(async (memberId, newStatus, confirmMessage) => {
    if (confirmMessage && !window.confirm(confirmMessage)) return;
    
    // Find the member to get its original status before updating
    const memberToUpdate = members.find(m => m.id === memberId);
    const originalStatus = memberToUpdate ? memberToUpdate.status : null;

    setIsUpdating(memberId);
    try {
      await Member.update(memberId, { status: newStatus });
      
      // If status changed from pending to active, send welcome email
      if (originalStatus === 'pending' && newStatus === 'active') {
          try {
              await sendWelcomeEmail({ memberId: memberId });
              toast.success("Welcome email sent!");
          } catch (emailError) {
              const errorMessage = emailError.response?.data?.error || emailError.message;
              console.error(`Failed to send welcome email for member ${memberId}:`, emailError);
              toast.error(`Member updated, but failed to send the welcome email. Error: ${errorMessage}`);
          }
      }

      await loadAllData(); // Call the refresh function
      toast.success("Member status updated successfully!");
    } catch (error) {
      console.error(`Failed to update member status to ${newStatus}:`, error);
      toast.error(`Status update failed. Please try again.`);
    } finally {
      setIsUpdating(null);
    }
  }, [members, loadAllData]); // Dependencies for useCallback

  const handleDeleteMember = useCallback(async (memberId, memberEmail) => {
    if (!window.confirm(`WARNING: This will permanently delete the member account for ${memberEmail}. This action cannot be undone. Are you sure?`)) return;
    
    setIsDeleting(memberId);
    try {
      await Member.delete(memberId);
      await loadAllData(); // Call the refresh function
      toast.success("Member deleted successfully!");
    } catch (error) {
      console.error("Failed to delete member:", error);
      toast.error("Deletion failed. Please try again.");
    } finally {
      setIsDeleting(null);
    }
  }, [loadAllData]); // Dependencies for useCallback

  const handleUpdateAdminLevel = useCallback(async (adminId, newLevel) => {
    try {
      await User.update(adminId, { admin_level: newLevel });
      await loadAllData(); // Call the refresh function
      toast.success("Admin level updated successfully.");
    } catch (error) {
      console.error("Failed to update admin level:", error);
      toast.error("Failed to update admin level.");
    }
  }, [loadAllData]); // Dependencies for useCallback

  const handleRemoveAdmin = useCallback(async (adminId) => {
     if (!window.confirm("Are you sure you want to remove this admin? They will be demoted to a regular user and lose all admin privileges.")) return;
    try {
      await User.update(adminId, { role: 'user', admin_level: null });
      await loadAllData(); // Call the refresh function
      toast.success("Admin removed successfully.");
    } catch (error) {
      console.error("Failed to remove admin:", error);
      toast.error("Failed to remove admin.");
    }
  }, [loadAllData]); // Dependencies for useCallback

  const handleCleanupMembers = useCallback(async () => {
    if (!window.confirm("WARNING: This will permanently delete ALL members except clinic@omegapeds.com. This action cannot be undone. Are you absolutely sure?")) return;
    
    setIsCleaning(true);
    try {
      // Reverted to original handling of fetch response as outline's `{ data: result }` is not typical for `fetch`.
      const response = await fetch('/functions/cleanupMembers', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token')}`,
          'Content-Type': 'application/json'
        }
      });
      
      const result = await response.json();
      if (result.success) {
        toast.success(`Cleanup completed: ${result.message}`);
        await loadAllData(); // Call the refresh function
      } else {
        toast.error(`Cleanup failed: ${result.error}`);
      }
    } catch (error) {
      console.error("Cleanup failed:", error);
      toast.error("Cleanup failed. Please try again.");
    } finally {
      setIsCleaning(false);
    }
  }, [loadAllData]); // Dependencies for useCallback

  // MemberActionsDropdown component (moved from MembersTab)
  const MemberActionsDropdown = useCallback(({ member }) => {
    const canModify = user?.admin_level === 'super' || user?.admin_level === 'manager';
    const canDelete = user?.admin_level === 'super';
    
    return (
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="sm" disabled={isUpdating === member.id || isDeleting === member.id}>
            {(isUpdating === member.id || isDeleting === member.id) ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <MoreHorizontal className="w-4 h-4" />
            )}
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem 
            onSelect={() => setSelectedMember(member)}
            className="flex items-center gap-2 cursor-pointer"
          >
            <Eye className="w-4 h-4" />
            View Details
          </DropdownMenuItem>
          
          {canModify && (
            <>
              <DropdownMenuSeparator />
              
              {member.status !== 'active' && (
                <DropdownMenuItem 
                  onClick={() => handleStatusChange(member.id, 'active')}
                  className="flex items-center gap-2 text-green-600 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  Activate Member
                </DropdownMenuItem>
              )}
              
              {member.status !== 'pending' && (
                <DropdownMenuItem 
                  onClick={() => handleStatusChange(member.id, 'pending', 'Are you sure you want to set this member to pending status?')}
                  className="flex items-center gap-2 text-yellow-600 cursor-pointer"
                >
                  <Clock className="w-4 h-4" />
                  Set to Pending
                </DropdownMenuItem>
              )}
              
              {member.status !== 'archived' && (
                <DropdownMenuItem 
                  onClick={() => handleStatusChange(member.id, 'archived', 'Are you sure you want to archive this member?')}
                  className="flex items-center gap-2 text-gray-600 cursor-pointer"
                >
                  <Archive className="w-4 h-4" />
                  Archive Member
                </DropdownMenuItem>
              )}
              
              {member.status !== 'cancelled' && (
                <DropdownMenuItem 
                  onClick={() => handleStatusChange(member.id, 'cancelled', 'Are you sure you want to cancel this membership?')}
                  className="flex items-center gap-2 text-orange-600 cursor-pointer"
                >
                  <XCircle className="w-4 h-4" />
                  Cancel Membership
                </DropdownMenuItem>
              )}
            </>
          )}
          
          {canDelete && (
            <>
              <DropdownMenuSeparator />
              <DropdownMenuItem 
                onClick={() => handleDeleteMember(member.id, member.email)}
                className="flex items-center gap-2 text-red-600 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
                Delete Account
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
    );
  }, [user, isUpdating, isDeleting, handleStatusChange, handleDeleteMember, setSelectedMember]); // Dependencies for useCallback

  // Handle row click for the virtualized list
  const handleRowClick = useCallback((member) => {
    setSelectedMember(member);
  }, []);

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;
  }

  if (user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="mb-4 text-6xl">
              <ShieldCheck className="w-16 h-16 text-red-600 mx-auto" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Access Denied</h2>
            <p className="text-gray-600 mb-4">You need admin privileges to access this page.</p>
            <Button onClick={() => window.location.href = '/'}>Go to Home</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50 p-4 sm:p-6 lg:p-8">
        <div className="max-w-7xl mx-auto">
          <header className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-lg text-gray-600">Manage members, communications, and system settings.</p>
          </header>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="flex justify-between items-center mb-4">
              <TabsList className={`grid w-full ${user?.admin_level === 'super' ? 'grid-cols-6' : 'grid-cols-5'}`}> {/* Adjusted grid-cols */}
                <TabsTrigger value="members" className="font-semibold data-[state=active]:bg-green-600 data-[state=active]:text-white">
                    <Users className="w-4 h-4 mr-2" />All Members <Badge className="ml-2">{members.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="pending" className="font-semibold data-[state=active]:bg-orange-600 data-[state=active]:text-white">
                    <Clock className="w-4 h-4 mr-2" />Pending Activations <Badge className="ml-2">{pendingMembers.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="concierge" className="font-semibold data-[state=active]:bg-indigo-600 data-[state=active]:text-white">
                    <Briefcase className="w-4 h-4 mr-2" />Concierge Interest <Badge className="ml-2">{inquiries.length}</Badge>
                </TabsTrigger>
                <TabsTrigger value="email" className="font-semibold data-[state=active]:bg-blue-600 data-[state=active]:text-white">
                    <Mail className="w-4 h-4 mr-2" />Email Members
                </TabsTrigger>
                <TabsTrigger value="templates" className="font-semibold data-[state=active]:bg-purple-600 data-[state=active]:text-white">
                    <LayoutTemplate className="w-4 h-4 mr-2" />Email Templates
                </TabsTrigger>
                {user?.admin_level === 'super' && 
                    <TabsTrigger value="admins" className="font-semibold data-[state=active]:bg-cyan-600 data-[state=active]:text-white">
                      <UserCog className="w-4 h-4 mr-2" />Admin Management
                    </TabsTrigger>
                }
                <TabsTrigger value="statistics" className="font-semibold data-[state=active]:bg-yellow-600 data-[state=active]:text-white">
                    <BarChart className="w-4 h-4 mr-2" />Statistics
                </TabsTrigger>
              </TabsList>

              {user?.admin_level === 'super' && (
                <Button 
                  onClick={handleCleanupMembers}
                  disabled={isCleaning}
                  variant="destructive"
                  size="sm"
                  className="ml-4 flex-shrink-0"
                >
                  {isCleaning ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Cleaning...
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-4 h-4 mr-2" />
                      Cleanup Test Data
                    </>
                  )}
                </Button>
              )}
            </div>
            
            <TabsContent value="members" className="mt-4">
                <Card>
                    <CardHeader>
                        <CardTitle>All Members</CardTitle>
                        <CardDescription>
                            Browse, search, and manage all member accounts.
                        </CardDescription>
                        <Input 
                            placeholder="Search by name or email..."
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            className="max-w-sm mt-2"
                        />
                    </CardHeader>
                    <CardContent>
                        <div className="border rounded-lg overflow-hidden">
                            <div className="w-full">
                                <table className="w-full">
                                    <thead className="bg-gray-50">
                                        <TableRow className="w-full grid grid-cols-[1.5fr_2fr_1fr_1fr_1fr_0.5fr]">
                                            <TableHead className="p-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Name</TableHead>
                                            <TableHead className="p-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Email</TableHead>
                                            <TableHead className="p-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Plan</TableHead>
                                            <TableHead className="p-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Frequency</TableHead>
                                            <TableHead className="p-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</TableHead>
                                            <TableHead className="p-3 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</TableHead>
                                        </TableRow>
                                    </thead>
                                </table>
                                <div className="h-[550px] overflow-auto">
                                  <List
                                      height={550}
                                      itemCount={filteredMembers.length}
                                      itemSize={55}
                                      width="100%"
                                      itemData={{
                                          members: filteredMembers,
                                          handleRowClick,
                                          getStatusColor,
                                          user,
                                          isUpdating,
                                          isDeleting,
                                          handleStatusChange,
                                          handleDeleteMember,
                                          setSelectedMember,
                                          MemberActionsDropdownComponent: MemberActionsDropdown
                                      }}
                                      className="w-full"
                                  >
                                      {MemberRow}
                                  </List>
                                </div>
                            </div>
                        </div>
                        {filteredMembers.length === 0 && (
                          <div className="text-center py-12 text-gray-500">
                            <p>No members found matching your criteria.</p>
                          </div>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>

            <TabsContent value="pending" className="mt-4">
                <Card>
                    <CardHeader>
                        <CardTitle>Pending Member Activations</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {pendingMembers && pendingMembers.length > 0 ? (
                            <Table>
                                <TableHeader>
                                <TableRow>
                                    <TableHead>Name</TableHead>
                                    <TableHead>Email</TableHead>
                                    <TableHead>Plan</TableHead>
                                    <TableHead>Joined</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                                </TableHeader>
                                <TableBody>
                                {pendingMembers.map(member => (
                                    <TableRow key={member.id}>
                                    <TableCell>{member.full_name}</TableCell>
                                    <TableCell>{member.email}</TableCell>
                                    <TableCell>
                                        <Badge variant="secondary" className="capitalize">
                                        {member.plan_tier} ({member.payment_frequency})
                                        </Badge>
                                    </TableCell>
                                    <TableCell>{format(new Date(member.created_date), 'MMM d, yyyy')}</TableCell>
                                    <TableCell className="text-right">
                                        <MemberActionsDropdown member={member} />
                                    </TableCell>
                                    </TableRow>
                                ))}
                                </TableBody>
                            </Table>
                        ) : (
                            <div className="text-center py-12 text-gray-500">
                                <p>No pending activations at this time.</p>
                            </div>
                        )}
                    </CardContent>
                </Card>
            </TabsContent>
            
            <TabsContent value="admins" className="mt-4">
                <Card>
                    <CardHeader>
                        <CardTitle>Admin User Management</CardTitle>
                        <CardDescription>Invite new admins from the Base44 user management panel and set their permission level here.</CardDescription>
                    </CardHeader>
                    <CardContent>
                    {allAdmins && allAdmins.length > 0 ? (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Name</TableHead>
                                    <TableHead>Email</TableHead>
                                    <TableHead>Permission Level</TableHead>
                                    <TableHead className="text-right">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {allAdmins.map(admin => (
                                    <TableRow key={admin.id}>
                                        <TableCell>{admin.full_name}</TableCell>
                                        <TableCell>{admin.email}</TableCell>
                                        <TableCell>
                                            <Select
                                                value={admin.admin_level || 'staff'}
                                                onValueChange={(newLevel) => handleUpdateAdminLevel(admin.id, newLevel)}
                                                disabled={admin.id === user.id}
                                            >
                                                <SelectTrigger className="w-[180px]">
                                                <SelectValue placeholder="Set level" />
                                                </SelectTrigger>
                                                <SelectContent>
                                                <SelectItem value="staff">Staff</SelectItem>
                                                <SelectItem value="manager">Manager</SelectItem>
                                                <SelectItem value="super">Super Admin</SelectItem>
                                                </SelectContent>
                                            </Select>
                                        </TableCell>
                                        <TableCell className="text-right">
                                            <Button
                                                variant="destructive"
                                                size="sm"
                                                disabled={admin.id === user.id}
                                                onClick={() => handleRemoveAdmin(admin.id)}
                                            >
                                                <Trash2 className="w-4 h-4 mr-2"/> Remove Admin
                                            </Button>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    ) : (
                        <div className="text-center py-12 text-gray-500">
                            <p>No admin users found.</p>
                        </div>
                    )}
                    </CardContent>
                </Card>
            </TabsContent>
            
            <TabsContent value="concierge" className="mt-4">
              <ConciergeInterestTab 
                conciergeInquiries={inquiries} 
                isLoadingData={isLoading}
              />
            </TabsContent>

            <TabsContent value="email" className="mt-4">
              <Suspense fallback={
                <Card className="p-8">
                  <div className="flex items-center justify-center">
                    <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                    <span className="ml-2">Loading email tools...</span>
                  </div>
                </Card>
              }>
                <EmailSender members={members} conciergeInquiries={inquiries} />
              </Suspense>
            </TabsContent>

            <TabsContent value="templates" className="mt-4">
              <Suspense fallback={
                <Card className="p-8">
                  <div className="flex items-center justify-center">
                    <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
                    <span className="ml-2">Loading email templates...</span>
                  </div>
                </Card>
              }>
                <EmailTemplateManager />
              </Suspense>
            </TabsContent>

            <TabsContent value="statistics" className="mt-4">
              <StatisticsTab allMembers={members} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Dialog open={!!selectedMember} onOpenChange={(isOpen) => { if(!isOpen) setSelectedMember(null) }}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Member Summary - {selectedMember?.full_name}</DialogTitle>
          </DialogHeader>
          {selectedMember && <MemberSummary member={selectedMember} adminUser={user} />}
        </DialogContent>
      </Dialog>
    </>
  );
}
