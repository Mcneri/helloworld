
import React, { useState, useEffect, lazy, Suspense } from "react";
import { useNavigate, Link, useSearchParams } from "react-router-dom";
import { useForm, Controller } from "react-hook-form";
import { Member } from "@/api/entities";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { sendWelcomeEmail } from "@/api/functions";
import { sendApplicationReceivedEmail } from "@/api/functions";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Shield,
  CheckCircle,
  ArrowRight,
  User as UserIcon,
  Mail,
  Phone,
  Users2,
  Calendar,
  CreditCard,
  Banknote,
  Calculator,
  Info,
  Lock,
  AtSign,
  DollarSign,
  Loader2,
  AlertCircle,
  ExternalLink,
  X
} from "lucide-react";
import { format, addMonths } from "date-fns";
import ExpandableFAQSection, { faqsByPage } from "../components/ExpandableFAQSection";
import { useApiError, ApiErrorAlert } from "../components/ApiErrorHandler";

// Lazy load Stripe elements since they're heavy and only needed when payment is initiated
const StripePaymentForm = lazy(() => import("../components/StripePaymentForm"));

const encouragingQuotes = [
  "The days are long, but the years are short. Cherish every moment.",
  "You are the parent your child needs. Trust your instincts.",
  "Raising a child is messy and challenging, but it's also the most beautiful adventure.",
  "You are building a legacy of love, one day at a time.",
  "There is no such thing as a perfect parent. So just be a real one.",
  "Your love is the greatest gift you can give your child.",
];

const plans = {
  bronze: { name: "Bronze", subtitle: "Essential Care", monthlyPrice: 250, annualPrice: 2190, color: "from-amber-500 to-orange-500" },
  silver: { name: "Silver", subtitle: "Enhanced Care", monthlyPrice: 400, annualPrice: 3504, color: "from-gray-400 to-gray-500" },
  gold: { name: "Gold", subtitle: "Premium Care", monthlyPrice: 500, annualPrice: 4380, color: "from-yellow-400 to-amber-500" }
};

const getFormValidation = (paymentFrequency) => ({
  full_name: { required: "Full name is required", minLength: { value: 2, message: "Name must be at least 2 characters" }, pattern: { value: /^[a-zA-Z\s'-]+$/, message: "Name can only contain letters, spaces, hyphens, and apostrophes" } },
  email: { required: "Email address is required", pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: "Please enter a valid email address" } },
  phone: { required: "Phone number is required", pattern: { value: /^[\+]?[1-9][\d]{0,15}$/, message: "Please enter a valid phone number" } },
  children_count: { required: "Number of children is required", min: { value: 1, message: "Must have at least 1 child" }, max: { value: 10, message: "Maximum 10 children supported" }, validate: value => (value > 0 && value <= 10) || "Number of children must be between 1 and 10" },
  payment_method: { required: "Payment method is required", validate: (value) => { if (paymentFrequency === 'annual' && !['ach', 'zelle'].includes(value)) { return "Annual plans only support ACH or Zelle payments"; } if (paymentFrequency === 'monthly' && !['card', 'paypal'].includes(value)) { return "Monthly plans only support Credit Card or PayPal payments"; } return true; } }
});

const calculatePrice = (planTier, paymentFrequency, childrenCount) => {
    const selectedPlan = plans[planTier];
    let basePricePerChildUnit;
    if (paymentFrequency === "annual") { basePricePerChildUnit = selectedPlan.annualPrice; } else { basePricePerChildUnit = selectedPlan.monthlyPrice * 2; }
    const discountRates = [1, 0.85, 0.7, 0.55];
    let calculatedPrice = 0;
    for (let i = 0; i < childrenCount; i++) { const rate = i < discountRates.length ? discountRates[i] : discountRates[discountRates.length - 1]; calculatedPrice += basePricePerChildUnit * rate; }
    let savings = 0;
    if (paymentFrequency === "annual") { let monthlyCostForChildren = 0; const baseMonthlyPrice = selectedPlan.monthlyPrice; for (let i = 0; i < childrenCount; i++) { const rate = i < discountRates.length ? discountRates[i] : discountRates[discountRates.length - 1]; monthlyCostForChildren += baseMonthlyPrice * rate; } const annualCostIfMonthly = monthlyCostForChildren * 12; savings = annualCostIfMonthly - calculatedPrice; }
    return { totalPrice: calculatedPrice, savings };
};

export default function Join() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const [quote, setQuote] = useState("");
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [memberId, setMemberId] = useState(null);
  const { error: apiError, handleApiCall, clearError: clearApiError } = useApiError();
  const { register, handleSubmit, control, watch, setValue, formState: { errors }, trigger, clearErrors } = useForm({ defaultValues: { full_name: "", email: "", phone: "", plan_tier: searchParams.get('plan') || "silver", payment_frequency: searchParams.get('billing') || "annual", payment_method: (searchParams.get("billing") || "annual") === 'annual' ? 'ach' : 'card', children_count: 1, start_date: format(addMonths(new Date(), 1), 'yyyy-MM-01'), notes: "", terms_accepted: false }, mode: 'onBlur' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [validationSchema, setValidationSchema] = useState(getFormValidation(watch("payment_frequency")));

  const planTier = watch("plan_tier");
  const paymentFrequency = watch("payment_frequency");
  const paymentMethod = watch("payment_method");
  const childrenCount = watch("children_count");

  useEffect(() => {
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    const title = "Start Your Concierge DPC Membership Today | Join Omega Pediatrics";
    const description = "Begin your journey with Atlanta's top direct primary care pediatrician. Sign up for your premium membership plan and secure personalized pediatric care.";
    document.title = title;
    const createMetaTag = (attrs) => { const el = document.createElement('meta'); Object.keys(attrs).forEach(attr => el.setAttribute(attr, attrs[attr])); el.setAttribute('data-b44-seo', 'true'); document.head.appendChild(el); };
    createMetaTag({ name: 'description', content: description });
    createMetaTag({ property: 'og:title', content: title });
    createMetaTag({ property: 'og:description', content: description });
    createMetaTag({ name: 'twitter:title', content: title });
    createMetaTag({ name: 'twitter:description', content: description });
    const joinFAQs = faqsByPage.Join || [];
    if (joinFAQs.length > 0) { const faqSchema = { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": joinFAQs.map(faq => ({ "@type": "Question", "name": faq.question, "acceptedAnswer": { "@type": "Answer", "text": typeof faq.answer === 'string' ? faq.answer.replace(/<[^>]*>?/gm, '') : "Please visit our website for detailed information about this topic." } })) }; const faqScript = document.createElement('script'); faqScript.type = 'application/ld+json'; faqScript.innerHTML = JSON.stringify(faqSchema); faqScript.setAttribute('data-b44-seo', 'true'); document.head.appendChild(faqScript); }
    return () => { document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove()); };
  }, [searchParams]);

  useEffect(() => {
    setQuote(encouragingQuotes[Math.floor(Math.random() * encouragingQuotes.length)]);
    const checkUser = async () => { try { const user = await User.me().catch(() => null); if (user) { setValue('full_name', user.full_name || ''); setValue('email', user.email || ''); } } catch (e) { /* Not logged in */ } };
    checkUser();
  }, [setValue]);

  useEffect(() => {
    setValidationSchema(getFormValidation(paymentFrequency));
    if (paymentFrequency === 'annual' && (paymentMethod === 'card' || paymentMethod === 'paypal')) { setValue('payment_method', 'ach'); } else if (paymentFrequency === 'monthly' && (paymentMethod === 'ach' || paymentMethod === 'zelle')) { setValue('payment_method', 'card'); }
  }, [paymentFrequency, paymentMethod, setValue]);

  const { totalPrice, savings } = calculatePrice(planTier, paymentFrequency, childrenCount);
  const selectedPlan = plans[planTier];

  const onSubmit = async (data) => {
    clearApiError();
    setIsSubmitting(true);
    const currentSelectedPlan = plans[data.plan_tier];
    const selectedStartDate = new Date(data.start_date);
    let renewalDate;
    if (data.payment_frequency === "annual") { renewalDate = addMonths(selectedStartDate, 12); } else { renewalDate = addMonths(selectedStartDate, 1); }
    const memberData = { full_name: data.full_name, email: data.email, phone: data.phone, plan_tier: data.plan_tier, payment_frequency: data.payment_frequency, payment_method: data.payment_method, monthly_amount: currentSelectedPlan.monthlyPrice, annual_amount: currentSelectedPlan.annualPrice, start_date: format(selectedStartDate, 'yyyy-MM-dd'), renewal_date: format(renewalDate, 'yyyy-MM-dd'), children_count: data.children_count, notes: data.notes, status: "pending" };
    try {
      let currentUser = await User.me().catch(() => null);
      if (!currentUser) { await User.loginWithRedirect(window.location.href); setIsSubmitting(false); return; }
      if (data.payment_method === "card" && totalPrice > 0) { setMemberId(null); setShowPaymentForm(true); setIsSubmitting(false); } else { const newMember = await handleApiCall(() => Member.create(memberData)); if (newMember) { setMemberId(newMember.id); await handleApiCall(() => User.updateMyUserData({ member_id: newMember.id })); await handleApiCall(() => sendApplicationReceivedEmail({ memberId: newMember.id })); navigate(createPageUrl("ThankYou") + `?member_id=${newMember.id}&payment_method=${data.payment_method}`); } }
    } catch (err) { console.error("Submission error:", err); } finally { if (data.payment_method !== "card" || totalPrice === 0) { setIsSubmitting(false); } }
  };

  const handlePaymentSuccess = async (paymentIntent) => {
    const formData = watch();
    const currentSelectedPlan = plans[formData.plan_tier];
    const selectedStartDate = new Date(formData.start_date);
    let renewalDate;
    if (formData.payment_frequency === "annual") { renewalDate = addMonths(selectedStartDate, 12); } else { renewalDate = addMonths(selectedStartDate, 1); }
    const memberData = { full_name: formData.full_name, email: formData.email, phone: formData.phone, plan_tier: formData.plan_tier, payment_frequency: formData.payment_frequency, payment_method: 'card', monthly_amount: currentSelectedPlan.monthlyPrice, annual_amount: currentSelectedPlan.annualPrice, start_date: format(selectedStartDate, 'yyyy-MM-dd'), renewal_date: format(renewalDate, 'yyyy-MM-dd'), children_count: formData.children_count, notes: formData.notes, stripe_payment_intent_id: paymentIntent.id, status: "active", };
    setIsSubmitting(true);
    try {
      const newMember = await handleApiCall(() => Member.create(memberData));
      if (newMember) { setMemberId(newMember.id); await handleApiCall(() => User.updateMyUserData({ member_id: newMember.id })); await handleApiCall(() => sendWelcomeEmail({ memberId: newMember.id })); navigate(createPageUrl("ThankYou") + `?member_id=${newMember.id}&payment_method=card&payment_success=true`); }
    } catch (err) { console.error("Post-payment submission error:", err); navigate(createPageUrl("ThankYou") + `?member_id=${memberId || "error"}&payment_method=card&payment_success=true&email_failed=true`); } finally { setIsSubmitting(false); }
  };

  const handlePaymentError = (error) => { console.error("Payment error:", error); clearApiError(); };
  const startMonthOptions = [0, 1, 2].map(i => { const date = addMonths(new Date(), i); return { value: format(date, 'yyyy-MM-01'), label: format(date, 'MMMM yyyy') }; });
  const paymentOptions = [ { id: 'card', name: 'Credit Card', icon: CreditCard, monthly: true, annual: false }, { id: 'ach', name: 'ACH Bank Transfer', icon: Banknote, monthly: true, annual: true }, { id: 'zelle', name: 'Zelle', icon: AtSign, monthly: true, annual: true }, { id: 'paypal', name: 'PayPal', icon: DollarSign, monthly: true, annual: false }, ];
  const availablePaymentOptions = paymentOptions.filter(opt => paymentFrequency === 'annual' ? opt.annual : opt.monthly);

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50/50 via-white to-teal-50/50">
      <section className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in-up"> Join the Omega Family </h1>
            <p className="text-xl text-teal-100 max-w-3xl mx-auto animate-fade-in-up animation-delay-200"> Start your membership today and give your family access to comprehensive pediatric care. </p>
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {apiError && ( <ApiErrorAlert error={apiError} onDismiss={clearApiError} className="mb-6" /> )}

        <form onSubmit={handleSubmit(onSubmit)} noValidate>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              {!showPaymentForm ? (
                <Card className="shadow-xl border-gray-200 transform transition-all duration-300 hover:-translate-y-2">
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold flex items-center gap-2"> <UserIcon className="w-6 h-6 text-teal-600" /> Your Information </CardTitle>
                    <p className="text-gray-600"> Fill out the form below to start your membership application. </p>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2"> <UserIcon className="w-5 h-5 text-blue-600" /> Parent/Guardian Information </h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <Label htmlFor="full_name" className="flex items-center gap-2"><UserIcon className="w-4 h-4"/>Full Name *</Label>
                          <Input id="full_name" {...register("full_name", validationSchema.full_name)} placeholder="e.g., Jane Doe" className={`transition-colors focus:border-teal-500 ${errors.full_name ? "border-red-500" : ""}`} />
                          {errors.full_name && ( <p className="text-red-500 text-sm mt-1">{errors.full_name.message}</p> )}
                        </div>
                        <div>
                          <Label htmlFor="email" className="flex items-center gap-2"><Mail className="w-4 h-4"/>Email Address *</Label>
                          <Input id="email" type="email" {...register("email", validationSchema.email)} placeholder="you@example.com" className={`transition-colors focus:border-teal-500 ${errors.email ? "border-red-500" : ""}`} />
                          {errors.email && ( <p className="text-red-500 text-sm mt-1">{errors.email.message}</p> )}
                        </div>
                      </div>
                      <div>
                        <Label htmlFor="phone">Phone Number *</Label>
                        <Input id="phone" type="tel" {...register("phone", validationSchema.phone)} placeholder="Enter your phone number" className={errors.phone ? "border-red-500" : ""} />
                        {errors.phone && ( <p className="text-red-500 text-sm mt-1">{errors.phone.message}</p> )}
                      </div>
                      <div>
                        <Label htmlFor="children_count">Number of Children</Label>
                        <Controller name="children_count" control={control} rules={validationSchema.children_count} render={({ field }) => ( <Select value={field.value?.toString()} onValueChange={(value) => field.onChange(parseInt(value))}> <SelectTrigger className={errors.children_count ? "border-red-500" : ""}> <SelectValue /> </SelectTrigger> <SelectContent> {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(num => ( <SelectItem key={num} value={num.toString()}>{num}</SelectItem> ))} </SelectContent> </Select> )} />
                        {errors.children_count && ( <p className="text-red-500 text-sm mt-1">{errors.children_count.message}</p> )}
                      </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2"> <Shield className="w-5 h-5 text-blue-600" /> Plan Selection </h3>
                      <div>
                        <Label htmlFor="plan_tier">Membership Plan</Label>
                        <Controller name="plan_tier" control={control} render={({ field }) => ( <Select {...field}> <SelectTrigger> <SelectValue /> </SelectTrigger> <SelectContent> <SelectItem value="bronze">Bronze - Essential Care</SelectItem> <SelectItem value="silver">Silver - Enhanced Care</SelectItem> <SelectItem value="gold">Gold - Premium Care</SelectItem> </SelectContent> </Select> )} />
                      </div>
                      <div>
                        <Label htmlFor="payment_frequency">Payment Frequency</Label>
                        <Controller name="payment_frequency" control={control} render={({ field }) => ( <Select onValueChange={(value) => { field.onChange(value); trigger("payment_method"); }} value={field.value}> <SelectTrigger> <SelectValue /> </SelectTrigger> <SelectContent> <SelectItem value="monthly">Monthly (2-month minimum)</SelectItem> <SelectItem value="annual">Annual (Save 27%)</SelectItem> </SelectContent> </Select> )} />
                      </div>
                      <div>
                        <Label htmlFor="start_date">Membership Start Month</Label>
                        <Controller name="start_date" control={control} render={({ field }) => ( <Select {...field}> <SelectTrigger> <SelectValue /> </SelectTrigger> <SelectContent> {startMonthOptions.map(opt => ( <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem> ))} </SelectContent> </Select> )} />
                      </div>
                      <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-800 space-y-1"> <p className="font-semibold">Important Billing Information</p> <p> Memberships are billed by the <strong>full calendar month</strong>. Your term begins on the 1st of your selected start month. </p> <p> <strong>Monthly plans:</strong> Require 2-month minimum commitment. You pay for the first and last month upfront. </p> </div>
                    </div>
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2"> <CreditCard className="w-5 h-5 text-blue-600" /> Payment Method </h3>
                      <Controller name="payment_method" control={control} rules={validationSchema.payment_method} render={({ field }) => ( <div className="grid grid-cols-2 gap-3"> {availablePaymentOptions.map(opt => { const Icon = opt.icon; return ( <button key={opt.id} type="button" onClick={() => { field.onChange(opt.id); trigger('payment_method'); }} className={`flex-1 flex items-center justify-center gap-2 p-3 rounded-lg border-2 transition-all ${ field.value === opt.id ? 'border-blue-600 bg-blue-50' : 'border-gray-200 bg-white' } ${errors.payment_method ? 'border-red-500' : ''}`} > <Icon className="w-5 h-5" /> <span>{opt.name}</span> </button> ) })} </div> )} />
                      {errors.payment_method && ( <p className="text-red-500 text-sm mt-1">{errors.payment_method.message}</p> )}
                      {paymentMethod === 'card' && ( <div className="p-4 border rounded-xl bg-blue-50 text-blue-800 text-sm space-y-3"> <div className="font-semibold text-lg text-blue-900">Card Payment</div> <p>You will be redirected to a secure payment page after submitting your application details.</p> </div> )}
                      {paymentMethod === 'ach' && ( <div className="p-4 border rounded-xl bg-blue-50 text-blue-800 text-sm space-y-3"> <div className="font-semibold text-lg text-blue-900">ACH Bank Transfer Details</div> <div className="bg-white p-3 rounded-lg border border-blue-200 space-y-2"> <div><strong>Account Name:</strong> Realtime Clinics PC dba Omega Pediatric</div> <div><strong>Address:</strong> 1305 Hembree Road STE 203, Roswell GA 30076</div> <div><strong>Bank Name:</strong> Middlesex Federal Savings, F.A.</div> <div><strong>Routing Number:</strong> 211370150</div> <div><strong>Account Number:</strong> 98925236</div> <div className="pt-2 border-t border-blue-200"> <strong>Transfer Amount:</strong> ${totalPrice.toFixed(2)} </div> </div> <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3"> <p className="font-semibold text-yellow-800">Important Instructions:</p> <ul className="text-yellow-700 text-sm mt-1 space-y-1"> <li>• Payment must be completed within <strong>24 hours</strong> of signup</li> <li>• Email your bank transfer receipt to <strong>info@omegapediatrics.com</strong></li> <li>• Include your full name and phone number in the email</li> <li>• Setup recurring transfers for ongoing monthly/annual payments</li> </ul> </div> </div> )}
                      {paymentMethod === 'zelle' && ( <div className="p-4 border rounded-xl bg-blue-50 text-blue-800 text-sm space-y-3"> <div className="font-semibold text-lg text-blue-900">Zelle Payment Instructions</div> <div className="bg-white p-4 rounded-lg border border-blue-200 space-y-3"> <div> <p className="font-medium text-gray-700">Send Zelle Payment To:</p> <p className="font-bold text-lg text-gray-900">info@omegapediatrics.com</p> </div> <div className="pt-3 border-t border-blue-100"> <p className="font-medium text-gray-700">Payment Amount:</p> <p className="font-bold font-bold text-2xl text-blue-700">${totalPrice.toFixed(2)}</p> </div> </div> <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3"> <p className="font-semibold text-yellow-800">Important Instructions:</p> <ul className="text-yellow-700 text-sm mt-1 space-y-1"> <li>• <strong>Setup RECURRING Zelle</strong> payments for ${totalPrice.toFixed(2)} {paymentFrequency === 'annual' ? 'annually' : 'monthly'}</li> <li>• Initial payment must be completed within <strong>24 hours</strong> of signup</li> <li>• Email screenshot of payment confirmation to <strong>info@omegapediatrics.com</strong></li> <li>• Include your full name and phone number in the email</li> </ul> </div> </div> )}
                      {paymentMethod === 'paypal' && ( <div className="p-4 border rounded-xl bg-blue-50 text-blue-800 text-sm space-y-3"> <div className="font-semibold text-lg text-blue-900">PayPal Payment Instructions</div> <div className="bg-white p-3 rounded-lg border border-blue-200 space-y-2"> <div><strong>Send PayPal Payment To:</strong> info@omegapediatrics.com</div> <div className="pt-2 border-t border-blue-200"> <strong>Payment Amount:</strong> ${totalPrice.toFixed(2)} </div> </div> <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3"> <p className="font-semibold text-yellow-800">Important Instructions:</p> <ul className="text-yellow-700 text-sm mt-1 space-y-1"> <li>• Setup recurring PayPal payments for ${totalPrice.toFixed(2)} {paymentFrequency === 'annual' ? 'annually' : 'monthly'}</li> <li>• Initial payment must be completed within <strong>24 hours</strong> of signup</li> <li>• Email PayPal receipt to <strong>info@omegapediatrics.com</strong></li> <li>• Include your full name and phone number in the email</li> </ul> </div> </div> )}
                    </div>
                    <div>
                      <Label htmlFor="notes">Additional Notes (Optional)</Label>
                      <Input id="notes" {...register("notes")} placeholder="Any special requirements or notes" />
                    </div>
                    <div className="pt-6">
                      <Label htmlFor="terms_accepted" className="flex items-start space-x-3">
                        <Controller name="terms_accepted" control={control} rules={{ required: "You must accept the terms and conditions" }} render={({ field }) => ( <Checkbox id="terms_accepted" checked={field.value} onCheckedChange={field.onChange} className="mt-1" /> )} />
                        <div className="grid gap-1.5 leading-none">
                          <span className="font-medium text-gray-800"> I agree to the terms and conditions. <span className="text-red-500">*</span> </span>
                          <p className="text-sm text-gray-600"> I understand that this is a membership service with recurring payments and that I can cancel according to the policy. <a href="https://www.omegapediatrics.com/terms-of-service/" target="_blank" rel="noopener noreferrer" className="text-link-secondary ml-1">View full terms</a>. </p>
                        </div>
                      </Label>
                      {errors.terms_accepted && <p className="text-red-500 text-sm mt-2 ml-9">{errors.terms_accepted.message}</p>}
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card className="shadow-xl border-0 bg-white/90 backdrop-blur-sm transform transition-all duration-300 hover:-translate-y-2">
                  <CardHeader className="text-center pb-6">
                    <CardTitle className="text-2xl font-bold text-gray-900">Complete Your Payment</CardTitle>
                    <p className="text-gray-600"> You're almost done! Complete your payment to activate your membership. </p>
                  </CardHeader>
                  <CardContent>
                    <Suspense fallback={
                      <div className="space-y-6 animate-pulse">
                        <div className="space-y-4">
                          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
                          <div className="h-12 bg-gray-200 rounded"></div>
                        </div>
                        <div className="space-y-4">
                          <div className="h-6 bg-gray-200 rounded w-1/4"></div>
                          <div className="h-12 bg-gray-200 rounded"></div>
                        </div>
                        <div className="flex items-center justify-center py-8">
                          <Loader2 className="w-8 h-8 animate-spin text-teal-600" />
                          <span className="ml-3 text-gray-600">Loading secure payment form...</span>
                        </div>
                      </div>
                    }>
                      <StripePaymentForm
                        formData={watch()} // Pass current form data to StripePaymentForm
                        totalPrice={totalPrice}
                        onPaymentSuccess={handlePaymentSuccess}
                        onPaymentError={handlePaymentError}
                      />
                    </Suspense>
                  </CardContent>
                </Card>
              )}
            </div>
            <div className="lg:col-span-1">
              <div className="sticky top-40 space-y-6">
                <Card className="shadow-lg border-gray-200 transform transition-all duration-300 hover:-translate-y-2">
                  <CardHeader>
                    <CardTitle className="text-2xl font-bold flex items-center gap-2"> <DollarSign className="w-6 h-6 text-teal-600" /> Order Summary </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gradient-to-r from-blue-50 to-green-50 rounded-xl p-6 text-center h-48 w-full flex flex-col justify-center items-center"> <p className="text-lg italic text-gray-700">"{quote}"</p> </div>
                    <div className={`p-6 rounded-2xl bg-gradient-to-r ${selectedPlan.color} text-white`}>
                      <div className="flex items-center gap-3 mb-4"> <Shield className="w-8 h-8" /> <div> <h3 className="text-xl font-bold">{selectedPlan.name}</h3> <p className="text-white/90">{selectedPlan.subtitle}</p> </div> </div>
                      <div className="text-3xl font-bold"> ${paymentFrequency === "annual" ? selectedPlan.annualPrice.toFixed(2) : selectedPlan.monthlyPrice.toFixed(2)} </div>
                      <div className="text-white/90"> base price per child per {paymentFrequency === "annual" ? "year" : "month"} </div>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-3"> <Calculator className="w-5 h-5 text-blue-600" /> <span className="font-semibold text-blue-800">Total Price Calculation</span> </div>
                      <div className="space-y-2 text-sm text-blue-700">
                        <div className="flex justify-between"> <span>Base Price per Child:</span> <span>${paymentFrequency === "annual" ? selectedPlan.annualPrice.toFixed(2) : `${selectedPlan.monthlyPrice.toFixed(2)} (x2 for 1st & last)`}</span> </div>
                        <div className="flex justify-between"> <span>Number of Children:</span> <span>{childrenCount}</span> </div>
                        {childrenCount > 1 && ( <div className="flex justify-between items-start pt-2 border-t border-blue-200"> <span className="font-medium">Multi-child Discount:</span> <span className="text-right"> - ${((paymentFrequency === "annual" ? selectedPlan.annualPrice : (selectedPlan.monthlyPrice * 2)) * childrenCount - totalPrice).toFixed(2)} </span> </div> )}
                        <div className="flex justify-between text-lg font-bold text-blue-900 pt-2 border-t border-blue-200"> <span>Total:</span> <span>${totalPrice.toFixed(2)}</span> </div>
                      </div>
                    </div>
                    {paymentFrequency === "annual" && savings > 0 && ( <div className="bg-blue-50 border border-blue-200 rounded-xl p-4"> <div className="flex items-center gap-2 mb-2"> <Info className="w-5 h-5 text-blue-600" /> <span className="font-semibold text-blue-800">Annual Payment Benefit</span> </div> <div className="text-lg font-medium text-blue-600">${savings.toFixed(2)} saved vs monthly payments</div> <div className="text-sm text-blue-700"> for {childrenCount} {childrenCount > 1 ? 'children' : 'child'} annually </div> </div> )}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
                      <div className="text-center">
                        <div className="text-sm font-medium text-green-700 mb-2">TOTAL DUE TODAY</div>
                        <div className="text-4xl font-bold text-green-900 mb-2">${totalPrice.toFixed(2)}</div>
                        <div className="text-sm text-green-700"> {paymentFrequency === "annual" ? "Annual payment" : "2-month minimum payment (first & last month)"} for {childrenCount} {childrenCount > 1 ? 'children' : 'child'} </div>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="font-semibold text-gray-900">Payment Method</h4>
                      <div className="space-y-2"> {paymentOptions.map(opt => { const Icon = opt.icon; if (!availablePaymentOptions.some(aOpt => aOpt.id === opt.id)) return null; return ( <div key={opt.id} className={`flex items-center gap-3 p-3 rounded-lg ${ paymentMethod === opt.id ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50' }`}> <Icon className={`w-5 h-5 ${paymentMethod === opt.id ? 'text-blue-600' : 'text-gray-600'}`} /> <div> <div className="font-medium text-gray-900">{opt.name}</div> <div className="text-sm text-gray-600"> {opt.id === 'card' && "Secure credit card processing"} {opt.id === 'ach' && "Bank transfer details will be provided"} {(opt.id === 'zelle' || opt.id === 'paypal') && "Manual payment required upon submission"} </div> </div> </div> ); })} </div>
                    </div>
                    <div className="bg-blue-50 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2"> <Users2 className="w-5 h-5 text-blue-600" /> <span className="font-semibold text-blue-800">Family Coverage</span> </div>
                      <div className="text-blue-700"> {childrenCount} {childrenCount === 1 ? "child" : "children"} covered </div>
                    </div>
                    <div className="space-y-3">
                      <h4 className="font-semibold text-gray-900">What's Included</h4>
                      <div className="space-y-2"> <div className="flex items-center gap-2"> <CheckCircle className="w-4 h-4 text-green-500" /> <span className="text-sm text-gray-700">Unlimited wellness visits</span> </div> <div className="flex items-center gap-2"> <CheckCircle className="w-4 h-4 text-green-500" /> <span className="text-sm text-gray-700">Unlimited concern visits</span> </div> <div className="flex items-center gap-2"> <CheckCircle className="w-4 h-4 text-green-500" /> <span className="text-sm text-gray-700">ADHD visits</span> </div> {planTier !== "bronze" && ( <div className="flex items-center gap-2"> <CheckCircle className="w-4 h-4 text-green-500" /> <span className="text-sm text-gray-700">Telemedicine visits</span> </div> )} {planTier === "gold" && ( <div className="flex items-center gap-2"> <CheckCircle className="w-4 h-4 text-green-500" /> <span className="text-sm text-gray-700">Direct messaging</span> </div> )} </div>
                    </div>
                  </CardContent>
                </Card>
                <Button type="submit" className="w-full text-lg py-6 bg-gradient-to-r from-teal-600 to-cyan-600 text-white shadow-lg transition-all duration-300 transform hover:scale-105 hover:shadow-xl active:scale-100" disabled={isSubmitting}>
                  {isSubmitting ? ( <> <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Processing... </> ) : ( <> {paymentMethod === 'card' ? 'Proceed to Payment' : 'Complete Application'} <ArrowRight className="ml-2 h-5 w-5" /> </> )}
                </Button>
              </div>
            </div>
          </div>
        </form>
        <ExpandableFAQSection page="Join" />
      </div>
    </div>
  );
}
