

import React, { useState, useEffect, lazy, useCallback, memo } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Heart, Shield, Calendar, MessageSquare, LogIn, Menu, X, User, LogOut, Phone, Mail, ChevronDown, Globe } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { User as UserEntity } from "@/api/entities";
import PrefetchLink from "./components/PrefetchLink";
import { strategicPrefetch } from "./components/utils/prefetch";

// Lazy load components that aren't immediately needed
const PWAInstallPrompt = lazy(() => import("../components/PWAInstallPrompt"));
const Breadcrumbs = lazy(() => import("../components/Breadcrumbs"));
const ErrorBoundary = lazy(() => import("../components/ErrorBoundary"));

// PERF: Memoized fallback component for lazy loading
const LazyFallback = memo(({ children, minimal = false }) => {
  if (minimal) {
    return <div className="opacity-0 h-0 overflow-hidden" />;
  }
  return (
    <div className="flex justify-center items-center p-4">
      <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-teal-600"></div>
    </div>
  );
});

// PERF: Moved static navigation configuration outside the component function.
// This prevents these large arrays and objects from being recreated on every render.
const navigation = [
  { name: "Home", href: createPageUrl("Home"), icon: Heart },
  { name: "Plans", href: createPageUrl("Plans"), icon: Shield, prefetch: "hover", prefetchData: false },
  { name: "Services", href: createPageUrl("Services"), icon: Calendar, prefetch: "hover", prefetchData: false },
  { name: "FAQ", href: createPageUrl("FAQ"), icon: MessageSquare, prefetch: "viewport", prefetchData: false },
  { name: "Main Website", href: "https://www.omegapediatrics.com", icon: Globe, external: true },
];

const blogNav = {
  name: "Blog",
  icon: MessageSquare,
  prefetch: "hover",
  prefetchData: false,
  links: [
    { name: "What is Concierge?", href: createPageUrl("BlogWhatIsConciergeDoctor") },
    { name: "Is It Worth It?", href: createPageUrl("BlogAreTheyWorthIt") },
    { name: "How to Find a Doctor", href: createPageUrl("BlogHowToFind") },
    { name: "Fees & Insurance", href: createPageUrl("BlogFeesAndInsurance") },
    { name: "Why Omega Pediatrics?", href: createPageUrl("BlogOmegaAtlanta") },
  ]
};

// PERF: Memoized navigation item component to prevent unnecessary re-renders
const NavigationItem = memo(({ item, isActive }) => {
  if (item.external) {
    return (
      <a
        href={item.href}
        target="_blank"
        rel="noopener noreferrer"
        className={`text-lg font-medium px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 text-gray-600 hover:text-teal-600 hover:bg-teal-50 hover:shadow-sm hover:scale-105`}
        aria-label={`Visit ${item.name}`}
      >
        <item.icon className="w-5 h-5" aria-hidden="true" />
        {item.name}
      </a>
    );
  }

  return (
    <PrefetchLink
      to={item.href}
      prefetchOn={item.prefetch || "hover"}
      prefetchData={item.prefetchData || false}
      className={`text-lg font-medium px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 ${
        isActive(item.href)
          ? "text-teal-600 bg-teal-50 shadow-sm"
          : "text-gray-600 hover:text-teal-600 hover:bg-teal-50 hover:shadow-sm hover:scale-105"
      }`}
      aria-label={`Navigate to ${item.name}`}
    >
      <item.icon className="w-5 h-5" aria-hidden="true" />
      {item.name}
    </PrefetchLink>
  );
});

// PERF: Memoized mobile navigation item
const MobileNavigationItem = memo(({ item, isActive, onClose }) => {
  const handleClick = useCallback(() => {
    onClose();
  }, [onClose]);

  if (item.external) {
    return (
      <a
        href={item.href}
        target="_blank"
        rel="noopener noreferrer"
        onClick={handleClick}
        className={`-mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 flex items-center gap-4 transition-all duration-200 text-gray-900 hover:bg-gray-50 hover:scale-105`}
        aria-label={`Visit ${item.name}`}
      >
        <item.icon className="w-7 h-7" aria-hidden="true" />
        {item.name}
      </a>
    );
  }

  return (
    <PrefetchLink
      to={item.href}
      prefetchOn={item.prefetch || "hover"}
      prefetchData={item.prefetchData || false}
      onClick={handleClick}
      className={`-mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 flex items-center gap-4 transition-all duration-200 ${
        isActive(item.href)
          ? 'bg-teal-50 text-teal-600'
          : 'text-gray-900 hover:bg-gray-50 hover:scale-105'
      }`}
      aria-label={`Navigate to ${item.name}`}
    >
      <item.icon className="w-7 h-7" aria-hidden="true" />
      {item.name}
    </PrefetchLink>
  );
});

export default function Layout({ children, currentPageName }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const location = useLocation();
  const [showBottomBanner, setShowBottomBanner] = useState(false);

  useEffect(() => {
    // Optimize viewport tag
    const existingViewport = document.querySelector('meta[name="viewport"]');
    if (existingViewport) {
      existingViewport.setAttribute('content', 'width=device-width,initial-scale=1');
    }

    const fetchUser = async () => {
      try {
        const currentUser = await UserEntity.me();
        setUser(currentUser);
      } catch (error) {
        setUser(null);
      }
    };
    fetchUser();

    const handleScroll = () => {
      const topBannerPosition = 128; // h-32
      const scrolledPastTopBanner = window.scrollY > topBannerPosition + 60;
      setShowBottomBanner(scrolledPastTopBanner);
    };

    // Strategic prefetching based on current page
    strategicPrefetch(location.pathname);
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [location.pathname]);
  
  // PERF: Delayed Google Analytics loading logic - first interaction or 4s idle
  useEffect(() => {
    const bootAnalytics = () => {
      // Ensure this only runs once
      if (window._analyticsBooted) return;
      window._analyticsBooted = true;

      // Load gtag.js script
      const script1 = document.createElement('script');
      script1.async = true;
      script1.src = "https://www.googletagmanager.com/gtag/js?id=G-XKHHS6ZW6Z";
      document.head.appendChild(script1);

      // Initialize dataLayer and gtag, but prevent the automatic page view
      const script2 = document.createElement('script');
      script2.innerHTML = `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'G-XKHHS6ZW6Z', { send_page_view: false });
      `;
      document.head.appendChild(script2);
      
      // Manually send the first page_view event after initialization
      script2.onload = () => {
        if (typeof window.gtag === 'function') {
          window.gtag('event', 'page_view', {
            page_title: document.title,
            page_location: window.location.href,
            page_path: window.location.pathname + window.location.search
          });
        }
      };

      console.log('Analytics booted.');
    };
    
    // Set up triggers for booting analytics
    const interactionEvents = ['pointerdown', 'scroll', 'keydown'];
    interactionEvents.forEach(event => {
      document.addEventListener(event, bootAnalytics, { once: true, passive: true });
    });
    
    // Fallback timer: load after 4 seconds if no interaction
    const fallbackTimeout = setTimeout(bootAnalytics, 4000);

    return () => {
      clearTimeout(fallbackTimeout);
      interactionEvents.forEach(event => {
        document.removeEventListener(event, bootAnalytics);
      });
    };
  }, []);

  // PERF: Defer Rewardful script until first interaction or 4s idle (same as GA)
  useEffect(() => {
    const bootRewardful = () => {
      if (window._rewardfulBooted) return;
      window._rewardfulBooted = true;

      // Load Rewardful script
      const script = document.createElement('script');
      script.async = true;
      script.src = 'https://r.wdfl.co/rw.js';
      script.setAttribute('data-rewardful', 'your-rewardful-id'); // Replace with actual ID if needed
      document.head.appendChild(script);

      console.log('Rewardful script booted.');
    };

    // Set up triggers for booting Rewardful (same strategy as analytics)
    const interactionEvents = ['pointerdown', 'scroll', 'keydown'];
    interactionEvents.forEach(event => {
      document.addEventListener(event, bootRewardful, { once: true, passive: true });
    });

    // Fallback timer: load after 4 seconds if no interaction
    const fallbackTimeout = setTimeout(bootRewardful, 4000);

    return () => {
      clearTimeout(fallbackTimeout);
      interactionEvents.forEach(event => {
        document.removeEventListener(event, bootRewardful);
      });
    };
  }, []);

  useEffect(() => {
    // Track subsequent page views for SPA navigation
    // This only fires if analytics has already been booted
    if (window._analyticsBooted && typeof window.gtag === 'function') {
      window.gtag('event', 'page_view', {
        page_title: document.title,
        page_location: window.location.href,
        page_path: location.pathname + location.search
      });
    }
  }, [location]);

  // PERF: Memoized logout handler to prevent recreating on every render
  const handleLogout = useCallback(async () => {
    await UserEntity.logout();
    setUser(null);
    window.location.href = createPageUrl("Home");
  }, []);

  // PERF: Memoized mobile menu handlers
  const handleMobileMenuOpen = useCallback(() => setMobileMenuOpen(true), []);
  const handleMobileMenuClose = useCallback(() => setMobileMenuOpen(false), []);

  // PERF: Memoized isActive function to prevent recreating on every render
  const isActive = useCallback((href) => location.pathname === href, [location.pathname]);

  // PERF: Memoized auth navigation based on user state
  const authNav = [];
  const allNav = [...navigation, ...authNav];

  return (
    <>
      <style>{`
        body {
          font-family: 'Poppins', -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', sans-serif;
        }
        
        /* Keyframes for Animations */
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes slideInRight {
          from { opacity: 0; transform: translateX(20px); }
          to { opacity: 1; transform: translateX(0); }
        }
        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(20, 184, 166, 0.3); }
          50% { box-shadow: 0 0 30px rgba(20, 184, 166, 0.5), 0 0 40px rgba(20, 184, 166, 0.2); }
        }

        /* Enhanced Animation Utility Classes */
        .animate-fade-in {
          animation: fadeIn 0.6s ease-out forwards;
          opacity: 0;
        }
        .animate-fade-in-up {
          animation: fadeInUp 0.8s ease-out forwards;
          opacity: 0;
        }
        .animate-slide-in-right {
          animation: slideInRight 0.7s ease-out forwards;
          opacity: 0;
        }
        .animation-delay-200 { animation-delay: 200ms; }
        .animation-delay-400 { animation-delay: 400ms; }
        .animation-delay-600 { animation-delay: 600ms; }
        .animation-delay-800 { animation-delay: 800ms; }

        /* Enhanced Card Hover Effects */
        .card-hover {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .card-hover:hover {
          transform: translateY(-8px) scale(1.02);
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 0 0 1px rgba(20, 184, 166, 0.1);
        }

        /* Enhanced Button Effects */
        .btn-enhanced {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          position: relative;
          overflow: hidden;
        }
        .btn-enhanced:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.2);
        }
        .btn-enhanced:active {
          transform: translateY(0);
          transition: all 0.1s ease;
        }
        .btn-enhanced::before {
          content: '';
          position: absolute;
          top: 0;
          left: -100%;
          width: 100%;
          height: 100%;
          background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
          transition: left 0.6s;
        }
        .btn-enhanced:hover::before {
          left: 100%;
        }

        /* Enhanced Form Focus Effects */
        .input-enhanced {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .input-enhanced:focus {
          transform: translateY(-1px);
          box-shadow: 0 10px 25px -5px rgba(20, 184, 166, 0.2), 0 0 0 3px rgba(20, 184, 166, 0.1);
        }

        /* Skeleton Loading Animation */
        @keyframes shimmer {
          0% { background-position: -200px 0; }
          100% { background-position: calc(200px + 100%) 0; }
        }
        .skeleton {
          background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
          background-size: 200px 100%;
          animation: shimmer 1.5s infinite;
        }

        /* ACCESSIBILITY FIXES: Improved contrast for all text and interactive elements */
        .text-link {
          @apply text-teal-700 hover:text-teal-800 hover:underline decoration-2 underline-offset-2 transition-all duration-200 font-medium;
        }
        
        .text-link-bold {
          @apply text-teal-700 hover:text-teal-800 underline decoration-2 underline-offset-2 font-semibold transition-all duration-200;
        }
        
        .text-link-button {
          @apply text-teal-700 hover:text-teal-800 hover:bg-teal-50 px-2 py-1 rounded transition-all duration-200 font-medium;
        }
        
        .text-link-light {
          @apply text-teal-100 hover:text-white hover:underline decoration-2 underline-offset-2 transition-all duration-200 font-medium;
        }
        
        .text-link-dark {
          @apply text-teal-800 hover:text-teal-900 hover:underline decoration-2 underline-offset-2 transition-all duration-200 font-medium;
        }
        
        .text-link-secondary {
          @apply text-blue-700 hover:text-blue-800 hover:underline decoration-2 underline-offset-2 transition-all duration-200 font-medium;
        }
        
        .text-link-accent {
          @apply text-purple-700 hover:text-purple-800 hover:underline decoration-2 underline-offset-2 transition-all duration-200 font-medium;
        }

        /* Improved badge contrast */
        .badge-popular {
          background: linear-gradient(135deg, #047857 0%, #065f46 100%);
          color: white;
          font-weight: 600;
          text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }

        /* Better footer contrast */
        .footer-text {
          color: #e5e7eb; /* Equivalent to gray-200/300 */
        }
        
        .footer-text-light {
          color: #d1d5db; /* Equivalent to gray-300/400 */
        }

        /* Enhanced button text contrast */
        .btn-text-contrast {
          text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
          font-weight: 600;
        }
      `}</style>
      
      <div className={`min-h-screen bg-[#FFF9E8] ${currentPageName === 'Home' ? 'pb-0' : ''} ${showBottomBanner ? 'pb-24' : ''}`}>
        {/* Header */}
        <React.Suspense fallback={<LazyFallback minimal />}>
          <ErrorBoundary fallback="minimal">
            <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
              {/* PERF: Add preconnect hints for performance */}
              <link rel="preconnect" href="https://images.unsplash.com" />
              <link rel="preconnect" href="https://qtrypzzcjebvfcihiynt.supabase.co" />
              <link rel="preconnect" href="https://www.googletagmanager.com" />
              <link rel="preconnect" href="https://r.wdfl.co" />
              <link rel="preconnect" href="https://js.stripe.com" />
              
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex justify-between items-center h-32">
                  {/* Logo - PERF: Optimized with responsive images */}
                  <Link to={createPageUrl("Home")} className="flex items-center space-x-3 group">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 rounded-xl flex items-center justify-center overflow-hidden transition-all duration-300 group-hover:scale-105 group-hover:rotate-1">
                      <picture>
                        <source
                          media="(min-width: 768px)"
                          srcSet="
                            https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png?auto=format&fit=crop&q=80&fm=webp&w=96 96w,
                            https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png?auto=format&fit=crop&q=80&fm=webp&w=128 128w
                          "
                          sizes="(min-width: 768px) 96px, 64px"
                        />
                        <img 
                          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png?auto=format&fit=crop&q=80&fm=webp&w=64"
                          srcSet="
                            https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png?auto=format&fit=crop&q=80&fm=webp&w=64 64w,
                            https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png?auto=format&fit=crop&q=80&fm=webp&w=96 96w
                          "
                          sizes="(min-width: 768px) 96px, 64px"
                          alt="Omega Pediatrics - Premium Concierge Pediatric Care Logo"
                          className="w-full h-full object-contain transition-transform duration-300"
                          style={{ filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.1))' }}
                          loading="eager"
                          fetchpriority="high"
                          width="96"
                          height="96"
                          decoding="async"
                          onError={(e) => {
                            e.target.style.display = 'none';
                            e.target.parentElement.innerHTML = '<div class="bg-gradient-to-br from-teal-500 to-green-600 text-white p-2 sm:p-3 rounded-lg font-bold text-xs sm:text-sm text-center leading-tight">OMEGA<br/>PEDIATRICS</div>';
                          }}
                        />
                      </picture>
                    </div>
                  </Link>

                  {/* Desktop Navigation - PERF: Using memoized components */}
                  <nav className="hidden lg:flex items-center space-x-1">
                    {navigation.map((item) => (
                      <NavigationItem key={item.name} item={item} isActive={isActive} />
                    ))}
                    {/* Blog Dropdown */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <button className="text-lg font-medium px-4 py-2 rounded-lg transition-all duration-300 flex items-center gap-2 text-gray-600 hover:text-teal-600 hover:bg-teal-50 hover:shadow-sm hover:scale-105" aria-label="Open blog menu">
                          <blogNav.icon className="w-5 h-5" aria-hidden="true" />
                          {blogNav.name}
                          <ChevronDown className="w-4 h-4" aria-hidden="true" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        {blogNav.links.map(link => (
                          <DropdownMenuItem key={link.name} asChild>
                            <PrefetchLink to={link.href} prefetchOn="hover" className="w-full">
                              {link.name}
                            </PrefetchLink>
                          </DropdownMenuItem>
                        ))}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </nav>

                  {/* Auth Buttons - Enhanced */}
                  <div className="hidden lg:flex items-center space-x-4">
                    {user ? (
                      <>
                        <PrefetchLink 
                          to={createPageUrl("Dashboard")} 
                          prefetchOn="immediate"
                          prefetchData={true}
                          className="flex items-center gap-2 text-lg font-medium text-gray-600 hover:text-teal-600 transition-all duration-200 hover:scale-105" 
                          aria-label="Go to Dashboard"
                        >
                          <User className="w-5 h-5" aria-hidden="true" />
                          Dashboard
                        </PrefetchLink>
                        <button onClick={handleLogout} className="flex items-center gap-2 text-lg font-medium text-gray-600 hover:text-teal-600 transition-all duration-200 hover:scale-105" aria-label="Logout">
                          <LogOut className="w-5 h-5" aria-hidden="true" />
                          Logout
                        </button>
                      </>
                    ) : (
                      <>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <button className="flex items-center gap-2 text-lg font-medium text-gray-600 hover:text-teal-600 focus:outline-none transition-all duration-200 hover:scale-105" aria-label="Sign In Options">
                              <LogIn className="w-5 h-5" aria-hidden="true" />
                              Sign In
                              <ChevronDown className="w-4 h-4" aria-hidden="true" />
                            </button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuItem asChild>
                              <PrefetchLink to={createPageUrl("MemberSignIn")} prefetchOn="viewport" className="flex items-center gap-2 w-full">
                                <User className="w-4 h-4" aria-hidden="true" />
                                Login User
                              </PrefetchLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <PrefetchLink to={createPageUrl("AdminSignIn")} prefetchOn="viewport" className="flex items-center gap-2 w-full">
                                <Shield className="w-4 h-4" aria-hidden="true" />
                                Login Admin
                              </PrefetchLink>
                            </DropdownMenuItem>
                            <DropdownMenuItem asChild>
                              <PrefetchLink to={createPageUrl("Join")} prefetchOn="viewport" className="flex items-center gap-2 w-full">
                                <Heart className="w-4 h-4" aria-hidden="true" />
                                Sign Up
                              </PrefetchLink>
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                        <PrefetchLink to={createPageUrl("Join")} prefetchOn="hover" prefetchData={false}>
                          <Button size="lg" className="btn-enhanced bg-teal-600 text-white px-5 py-3 rounded-lg text-lg font-semibold hover:bg-teal-700 shadow-md">
                            Join Now
                          </Button>
                        </PrefetchLink>
                      </>
                    )}
                  </div>

                  {/* Mobile Menu Button */}
                  <div className="lg:hidden flex items-center">
                    <button
                      onClick={handleMobileMenuOpen}
                      className="p-2 rounded-md text-gray-600 hover:bg-gray-100 transition-all duration-200 hover:scale-105"
                      aria-label="Open mobile menu"
                    >
                      <Menu className="h-8 w-8" aria-hidden="true" />
                    </button>
                  </div>
                </div>

                {/* Mobile Menu */}
                {mobileMenuOpen && (
                  <div className="fixed inset-0 z-50 bg-white lg:hidden animate-fade-in">
                    <div className="pt-5 pb-6 px-5">
                      <div className="flex items-center justify-between">
                        <Link to={createPageUrl("Home")} className="flex items-center space-x-3" aria-label="Omega Pediatrics Home">
                          <picture>
                            <img 
                              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png?auto=format&fit=crop&q=60&fm=webp&w=64"
                              alt="Omega Pediatrics Logo" 
                              className="h-12 w-12 sm:h-16 sm:w-16 rounded-lg object-contain"
                              loading="lazy"
                              width="64"
                              height="64"
                              decoding="async"
                            />
                          </picture>
                          <span className="text-lg sm:text-xl font-bold text-gray-900">Omega Pediatrics</span>
                        </Link>
                        <button
                          onClick={handleMobileMenuClose}
                          className="p-2 rounded-md text-gray-600 hover:bg-gray-100 transition-all duration-200"
                          aria-label="Close mobile menu"
                        >
                          <X className="h-8 w-8" aria-hidden="true" />
                        </button>
                      </div>
                      <nav className="mt-6 space-y-2" role="navigation">
                        {allNav.map((item) => (
                          <MobileNavigationItem 
                            key={item.name} 
                            item={item} 
                            isActive={isActive} 
                            onClose={handleMobileMenuClose} 
                          />
                        ))}
                        {/* Mobile blog links */}
                        <Accordion type="single" collapsible className="w-full">
                          <AccordionItem value="blog-links" className="border-b-0">
                            <AccordionTrigger className="-mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 flex items-center gap-4 transition-all duration-200 text-gray-900 hover:bg-gray-50 hover:scale-105 hover:no-underline">
                              <blogNav.icon className="w-7 h-7" aria-hidden="true" />
                              Blog
                            </AccordionTrigger>
                            <AccordionContent className="pl-8">
                              {blogNav.links.map(link => (
                                <PrefetchLink
                                  key={link.name}
                                  to={link.href}
                                  onClick={handleMobileMenuClose}
                                  prefetchOn="hover"
                                  className="-mx-3 block rounded-lg px-3 py-2 text-xl font-medium leading-7 text-gray-700 hover:bg-gray-100"
                                >
                                  {link.name}
                                </PrefetchLink>
                              ))}
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>
                        <hr className="my-4"/>
                        {user ? (
                          <>
                            <PrefetchLink 
                              to={createPageUrl("Dashboard")} 
                              onClick={handleMobileMenuClose} 
                              prefetchOn="immediate"
                              prefetchData={true}
                              className="-mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 text-gray-900 hover:bg-gray-50 flex items-center gap-4 transition-all duration-200 hover:scale-105" 
                              aria-label="Go to Dashboard"
                            >
                              <User className="w-7 h-7" aria-hidden="true" />
                              Dashboard
                            </PrefetchLink>
                            <button onClick={() => { handleLogout(); handleMobileMenuClose(); }} className="w-full text-left -mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 text-gray-900 hover:bg-gray-50 flex items-center gap-4 transition-all duration-200 hover:scale-105" aria-label="Logout">
                              <LogOut className="w-7 h-7" aria-hidden="true" />
                              Logout
                            </button>
                          </>
                        ) : (
                          <>
                            <PrefetchLink to={createPageUrl("MemberSignIn")} onClick={handleMobileMenuClose} prefetchOn="viewport" className="-mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 text-gray-900 hover:bg-gray-50 flex items-center gap-4 transition-all duration-200 hover:scale-105" aria-label="Login as User">
                              <User className="w-7 h-7" aria-hidden="true" />
                              Login User
                            </PrefetchLink>
                            <PrefetchLink to={createPageUrl("AdminSignIn")} onClick={handleMobileMenuClose} prefetchOn="viewport" className="-mx-3 block rounded-lg px-3 py-3 text-2xl font-semibold leading-7 text-gray-900 hover:bg-gray-50 flex items-center gap-4 transition-all duration-200 hover:scale-105" aria-label="Login as Admin">
                              <Shield className="w-7 h-7" aria-hidden="true" />
                              Login Admin
                            </PrefetchLink>
                            <PrefetchLink to={createPageUrl("Join")} onClick={handleMobileMenuClose} prefetchOn="hover" className="mt-4 block w-full text-center bg-teal-600 text-white px-5 py-4 rounded-lg text-2xl font-semibold hover:bg-teal-700 shadow-md btn-enhanced" aria-label="Join Omega Pediatrics">
                              Join Now
                            </PrefetchLink>
                          </>
                        )}
                      </nav>
                    </div>
                  </div>
                )}
              </div>
            </header>
          </ErrorBoundary>
        </React.Suspense>

        {/* Top Exclusive Statement Banner - PERF: Removed unnecessary Suspense/ErrorBoundary wrappers for faster rendering. */}
        <div className="sticky top-32 z-40">
          <PrefetchLink to={createPageUrl("Plans")} prefetchOn="viewport" className="block" aria-label="Learn more about our exclusive pediatric concierge healthcare packages">
            <div className="bg-gradient-to-r from-orange-100 via-purple-100 to-blue-100 py-4 shadow-2xl hover:shadow-xl transition-all duration-300 border-t border-b border-purple-200 cursor-pointer hover:scale-[1.01]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center">
                  <p className="text-lg md:text-xl font-bold text-gray-800">
                    We offer Atlanta's most exclusive <span className="text-orange-500">pediatric</span> <span className="text-purple-600">concierge</span> <span className="text-blue-500">healthcare</span> package.
                  </p>
                </div>
              </div>
            </div>
          </PrefetchLink>
        </div>

        {/* Main Content */}
        <main className="flex-1">
          <React.Suspense fallback={<Breadcrumbs />}>
            <Breadcrumbs />
          </React.Suspense>
          
          <React.Suspense fallback={
            <div className="min-h-screen bg-[#FFF9E8] flex items-center justify-center">
              <div className="max-w-md w-full animate-pulse">
                <div className="bg-white rounded-lg shadow-lg p-8 space-y-4">
                  <div className="flex items-center justify-center mb-6">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
                  </div>
                  <div className="h-6 bg-gray-200 rounded w-3/4 mx-auto"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 rounded w-full"></div>
                    <div className="h-3 bg-gray-200 rounded w-5/6"></div>
                    <div className="h-3 bg-gray-200 rounded w-4/5"></div>
                  </div>
                </div>
              </div>
            </div>
          }>
            <ErrorBoundary>
              {children}
            </ErrorBoundary>
          </React.Suspense>
        </main>

        {/* Footer - PERF: Optimized images */}
        <React.Suspense fallback={<LazyFallback minimal />}>
          <ErrorBoundary fallback="minimal">
            <footer className="bg-gray-900 text-white"> {/* Darker background for better contrast */}
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  {/* Column 1: Logo and Description */}
                  <div className="md:col-span-2">
                    <div className="flex items-center space-x-3 mb-4">
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl flex items-center justify-center overflow-hidden">
                        <picture>
                          <img 
                            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/87cfeab78_omegapediatricslogo3D2.png?auto=format&fit=crop&q=60&fm=webp&w=80"
                            srcSet="
                              https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/87cfeab78_omegapediatricslogo3D2.png?auto=format&fit=crop&q=60&fm=webp&w=64 64w,
                              https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/87cfeab78_omegapediatricslogo3D2.png?auto=format&fit=crop&q=60&fm=webp&w=80 80w
                            "
                            sizes="80px"
                            alt="Omega Pediatrics Footer Logo"
                            className="w-full h-full object-contain"
                            style={{ filter: 'drop-shadow(0 2px 4px rgba(255,255,255,0.1))' }}
                            loading="lazy"
                            width="80"
                            height="80"
                            decoding="async"
                            onError={(e) => {
                              e.target.style.display = 'none';
                              e.target.parentElement.innerHTML = '<div style="background: #10b981; color: white; padding: 15px; border-radius: 8px; font-size: 12px; font-weight: bold;">OMEGA</div>';
                            }}
                          />
                        </picture>
                      </div>
                      <div>
                        <span className="text-xl sm:text-2xl font-bold text-white">Omega Pediatrics</span>
                        <p className="text-teal-200 font-semibold text-sm sm:text-base">Premium Membership Care</p>
                      </div>
                    </div>
                    <p className="footer-text-light mb-4"> {/* Better contrast class */}
                      Providing exceptional pediatric care through our comprehensive membership plans. Your child's health is our priority.
                    </p>
                    <div className="footer-text space-y-1"> {/* Better contrast class */}
                      <p><span className="font-semibold text-white">Hours:</span> 11 am to 9 pm Weekdays</p>
                      <p><span className="font-semibold text-white">Urgent Help:</span> Phone lines open 24/7</p>
                    </div>
                  </div>

                  {/* Column 2: Locations - Improved contrast */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-white">Our Locations</h3>
                    <ul className="space-y-3 footer-text-light">
                      <li>
                        <strong className="text-white">Roswell:</strong><br />
                        1305 Hembree Road STE 203, Roswell GA 30076
                      </li>
                      <li>
                        <strong className="text-white">Marietta:</strong><br />
                        1841 Piedmont Road NE, STE 100, Marietta GA 30066
                      </li>
                      <li>
                        <strong className="text-white">Riverdale:</strong><br />
                        65742 River Park Drive, Riverdale GA 30274
                      </li>
                    </ul>
                  </div>

                  {/* Column 3: Contact & Quick Links - Improved contrast */}
                  <div>
                    <h3 className="text-lg font-semibold mb-4 text-white">Contact</h3>
                    <ul className="space-y-2 footer-text-light mb-6">
                      <li>
                        <a href="tel:4704856342" className="flex items-center gap-2 text-white hover:text-teal-200 transition-colors duration-200 font-medium" aria-label="Call Omega Pediatrics">
                          <Phone className="w-4 h-4" aria-hidden="true" /> 470-485-6342
                        </a>
                      </li>
                      <li>
                        <a href="mailto:info@omegapediatrics.com" className="flex items-center gap-2 text-white hover:text-teal-200 transition-colors duration-200 font-medium" aria-label="Email Omega Pediatrics">
                          <Mail className="w-4 h-4" aria-hidden="true" /> info@omegapediatrics.com
                        </a>
                      </li>
                    </ul>

                    <h3 className="text-lg font-semibold mb-4 text-white">Quick Links</h3>
                    <ul className="space-y-2">
                      <li><PrefetchLink to={createPageUrl("Plans")} prefetchOn="viewport" className="footer-text-light hover:text-white transition-colors duration-200 font-medium">Membership Plans</PrefetchLink></li>
                      <li><PrefetchLink to={createPageUrl("Services")} prefetchOn="viewport" className="footer-text-light hover:text-white transition-colors duration-200 font-medium">Services</PrefetchLink></li>
                      <li><PrefetchLink to={createPageUrl("Join")} prefetchOn="viewport" className="footer-text-light hover:text-white transition-colors duration-200 font-medium">Join Now</PrefetchLink></li>
                      <li><PrefetchLink to={createPageUrl("BlogOmegaAtlanta")} prefetchOn="viewport" className="footer-text-light hover:text-white transition-colors duration-200 font-medium">Our Care Philosophy</PrefetchLink></li>
                    </ul>
                  </div>
                </div>
                <div className="mt-8 border-t border-gray-700 pt-8 text-center footer-text">
                  <p>&copy; {new Date().getFullYear()} Omega Pediatrics. All rights reserved.</p>
                </div>
              </div>
            </footer>
          </ErrorBoundary>
        </React.Suspense>

        {/* PWA Install Prompt - Lazy Loaded */}
        <React.Suspense fallback={<LazyFallback minimal />}>
          <ErrorBoundary fallback="minimal">
            <PWAInstallPrompt />
          </ErrorBoundary>
        </React.Suspense>
        
      </div>

      {/* Bottom Exclusive Statement Banner */}
      {showBottomBanner && (
        <div className="fixed bottom-0 left-0 right-0 z-40 animate-slide-in-right">
          <PrefetchLink to={createPageUrl("Plans")} prefetchOn="immediate" className="block" aria-label="Learn more about our exclusive pediatric concierge healthcare packages">
            <div className="bg-gradient-to-r from-orange-100 via-purple-100 to-blue-100 py-3 shadow-2xl hover:shadow-xl transition-all duration-300 border-t border-purple-200 cursor-pointer hover:scale-[1.01]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <p className="text-base md::text-lg font-bold text-gray-800 text-center">
                  We offer Atlanta's most exclusive <span className="text-orange-500">pediatric</span> <span className="text-purple-600">concierge</span> <span className="text-blue-500">healthcare</span> package.
                </p>
              </div>
            </div>
          </PrefetchLink>
        </div>
      )}
    </>
  );
}

