import Layout from "./Layout.jsx";

import Home from "./Home";

import Plans from "./Plans";

import Services from "./Services";

import Join from "./Join";

import ThankYou from "./ThankYou";

import ConciergeInquiry from "./ConciergeInquiry";

import Dashboard from "./Dashboard";

import Forum from "./Forum";

import PostDetails from "./PostDetails";

import Admin from "./Admin";

import MemberSignIn from "./MemberSignIn";

import AdminSignIn from "./AdminSignIn";

import FAQ from "./FAQ";

import NotFound from "./NotFound";

import BlogWhatIsConciergeDoctor from "./BlogWhatIsConciergeDoctor";

import BlogAreTheyWorthIt from "./BlogAreTheyWorthIt";

import BlogHowToFind from "./BlogHowToFind";

import BlogFeesAndInsurance from "./BlogFeesAndInsurance";

import BlogOmegaAtlanta from "./BlogOmegaAtlanta";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Plans: Plans,
    
    Services: Services,
    
    Join: Join,
    
    ThankYou: ThankYou,
    
    ConciergeInquiry: ConciergeInquiry,
    
    Dashboard: Dashboard,
    
    Forum: Forum,
    
    PostDetails: PostDetails,
    
    Admin: Admin,
    
    MemberSignIn: MemberSignIn,
    
    AdminSignIn: AdminSignIn,
    
    FAQ: FAQ,
    
    NotFound: NotFound,
    
    BlogWhatIsConciergeDoctor: BlogWhatIsConciergeDoctor,
    
    BlogAreTheyWorthIt: BlogAreTheyWorthIt,
    
    BlogHowToFind: BlogHowToFind,
    
    BlogFeesAndInsurance: BlogFeesAndInsurance,
    
    BlogOmegaAtlanta: BlogOmegaAtlanta,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Plans" element={<Plans />} />
                
                <Route path="/Services" element={<Services />} />
                
                <Route path="/Join" element={<Join />} />
                
                <Route path="/ThankYou" element={<ThankYou />} />
                
                <Route path="/ConciergeInquiry" element={<ConciergeInquiry />} />
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Forum" element={<Forum />} />
                
                <Route path="/PostDetails" element={<PostDetails />} />
                
                <Route path="/Admin" element={<Admin />} />
                
                <Route path="/MemberSignIn" element={<MemberSignIn />} />
                
                <Route path="/AdminSignIn" element={<AdminSignIn />} />
                
                <Route path="/FAQ" element={<FAQ />} />
                
                <Route path="/NotFound" element={<NotFound />} />
                
                <Route path="/BlogWhatIsConciergeDoctor" element={<BlogWhatIsConciergeDoctor />} />
                
                <Route path="/BlogAreTheyWorthIt" element={<BlogAreTheyWorthIt />} />
                
                <Route path="/BlogHowToFind" element={<BlogHowToFind />} />
                
                <Route path="/BlogFeesAndInsurance" element={<BlogFeesAndInsurance />} />
                
                <Route path="/BlogOmegaAtlanta" element={<BlogOmegaAtlanta />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}