
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ConciergeInquiry } from "@/api/entities";
import { User } from "@/api/entities";
import { Member } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox"; // This import is not used anymore based on changes, but keeping it for safety for other components
import { motion } from "framer-motion";
import { 
  User as UserIcon, 
  Mail, 
  Phone, 
  MessageSquare, 
  ArrowRight,
  ArrowDown,
  CheckCircle,
  Star,
  Home,
  Calendar,
  Shield,
  Heart,
  Stethoscope,
  Plane,
  Clock,
  Users,
  Award,
  Sparkles,
  Gift,
  Baby,
  Apple,
  GraduationCap,
  Monitor,
  Users2,
  Percent,
  X,
  Loader2 
} from "lucide-react";
import FAQSection from "../components/FAQSection";
import { faqsByPage } from "../components/ExpandableFAQSection";

export default function ConciergeInquiryPage() {
  const navigate = useNavigate();
  const [inquiryId, setInquiryId] = useState(null);
  const [initialData, setInitialData] = useState(null);
  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    phone: "",
    message: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [memberStatus, setMemberStatus] = useState({
    isMember: false,
    details: null
  });
  const [isCalendarOpen, setIsCalendarOpen] = useState(false);
  const [calendarUrl, setCalendarUrl] = useState("https://tidycal.com/clinic2/30-minute-meeting");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // SEO and Metadata Setup
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());

    const title = "Diamond Concierge Pediatrics | Elite Membership Inquiry in Atlanta";
    const description = "Inquire about Omega Pediatrics' Diamond Concierge plan, the pinnacle of luxury direct primary care. Unparalleled access and exclusive services for discerning families.";
    
    document.title = title;

    const createMetaTag = (attrs) => {
      const el = document.createElement('meta');
      Object.keys(attrs).forEach(attr => el.setAttribute(attr, attrs[attr]));
      el.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(el);
    };

    createMetaTag({ name: 'description', content: description });
    createMetaTag({ property: 'og:title', content: title });
    createMetaTag({ property: 'og:description', content: description });
    createMetaTag({ name: 'twitter:title', content: title });
    createMetaTag({ name: 'twitter:description', content: description });

    // Schema.org - FAQPage
    const inquiryFAQs = faqsByPage.ConciergeInquiry || [];
    if (inquiryFAQs.length > 0) {
      const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": inquiryFAQs.map(faq => ({
          "@type": "Question",
          "name": faq.question,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": faq.answer.replace(/<[^>]*>?/gm, '')
          }
        }))
      };
      const faqScript = document.createElement('script');
      faqScript.type = 'application/ld+json';
      faqScript.innerHTML = JSON.stringify(faqSchema);
      faqScript.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(faqScript);
    }

    const params = new URLSearchParams(window.location.search);
    const idFromUrl = params.get('id');
    setInquiryId(idFromUrl);

    const checkAllData = async () => {
      setIsLoading(true);
      try {
        // Run checks in parallel to be more efficient
        const memberStatusPromise = (async () => {
          try {
            const user = await User.me();
            if (user && user.member_id) {
              const memberDetails = await Member.get(user.member_id);
              if (memberDetails && memberDetails.status === 'active') {
                setMemberStatus({ isMember: true, details: memberDetails });
              } else {
                setMemberStatus({ isMember: false, details: memberDetails });
              }
            } else {
              setMemberStatus({ isMember: false, details: null });
            }
          } catch (e) {
            setMemberStatus({ isMember: false, details: null });
          }
        })();

        // Use idFromUrl directly from the current effect run
        const inquiryDataPromise = idFromUrl ? (async () => {
          try {
            const data = await ConciergeInquiry.get(idFromUrl);
            setFormData({
              full_name: data.full_name || '',
              email: data.email || '',
              phone: data.phone || '',
              message: '' // Message should be blank for them to fill
            });
            setInitialData(data);
          } catch (error) {
            console.error("Failed to fetch inquiry details for ID:", idFromUrl, error);
            // If fetching fails, clear formData and initialData to avoid displaying stale info
            setFormData({ full_name: '', email: '', phone: '', message: '' });
            setInitialData(null);
          }
        })() : Promise.resolve();
        
        await Promise.all([memberStatusPromise, inquiryDataPromise]);
        
      } catch (error) {
        console.error("Error loading page data:", error);
      } finally {
        setIsLoading(false);
      }
    };

    checkAllData();
  }, [window.location.search]); // Re-run effect when URL search parameters change

  const showPricing = memberStatus.isMember && memberStatus.details?.status === 'active';

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const submissionData = {
        message: formData.message,
        full_name: formData.full_name,
        email: formData.email,
        phone: formData.phone,
        status: 'new',
      };

      if (inquiryId) { // This is an update to an existing lead
        // Check for changes and add initial values if they have been changed
        if (initialData && formData.email !== initialData.email) {
          submissionData.initial_email = initialData.email;
        }
        if (initialData && formData.phone !== initialData.phone) {
          submissionData.initial_phone = initialData.phone;
        }
        await ConciergeInquiry.update(inquiryId, submissionData);
      } else { // This is a brand new inquiry (e.g., from an existing member)
        submissionData.terms_accepted = true; // Implicitly accepted as they are submitting this detailed form
        await ConciergeInquiry.create(submissionData);
      }

      const encodedName = encodeURIComponent(formData.full_name);
      const encodedEmail = encodeURIComponent(formData.email);
      const url = `https://tidycal.com/clinic2/30-minute-meeting?name=${encodedName}&email=${encodedEmail}`;
      setCalendarUrl(url);
      openCalendar();
    } catch (error) {
      console.error("Failed to submit inquiry:", error);
      alert("There was an error submitting your inquiry. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const openCalendar = () => {
    setIsCalendarOpen(true);
  };

  const closeCalendar = () => {
    setIsCalendarOpen(false);
  };
  
  const AnimatedArrows = () => {
    const arrowVariants = {
      initial: { opacity: 0, y: 0, x: 0 },
      animate: (i) => ({
        opacity: [0, 1, 0],
        y: [0, 10, 0],
        x: [0, 10, 0],
        transition: {
          delay: i * 0.3,
          duration: 1.5,
          repeat: Infinity,
          repeatType: "loop",
        },
      }),
    };

    return (
      <>
        {/* Desktop Arrows */}
        <div className="hidden lg:flex absolute top-1/2 -right-12 -translate-y-1/2 flex-col items-center gap-2 pointer-events-none">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={`desktop-arrow-${i}`}
              variants={arrowVariants}
              initial="initial"
              animate="animate"
              custom={i}
            >
              <ArrowRight className="w-10 h-10 text-purple-400" />
            </motion.div>
          ))}
        </div>

        {/* Mobile Arrows */}
        <div className="lg:hidden flex justify-center mt-6">
          {[...Array(3)].map((_, i) => (
            <motion.div
              key={`mobile-arrow-${i}`}
              variants={arrowVariants}
              initial="initial"
              animate="animate"
              custom={i}
            >
              <ArrowDown className="w-10 h-10 text-purple-400" />
            </motion.div>
          ))}
        </div>
      </>
    );
  };

  const coreServices = [
    { icon: Stethoscope, title: "Unlimited Physician Access", description: "Telemedicine, direct messaging, priority scheduling" },
    { icon: Calendar, title: "Minimum 2+ Extra Annual Visits", description: "Exceeds public health recommendations - newborns get up to 9 wellness checks, older kids up to 4 per year" },
    { icon: Home, title: "Priority Same-Day Home Visits", description: "When your child needs immediate care at home" },
    { icon: Shield, title: "Complete Preventive Care", description: "Diagnostics, lactation support, health advocacy" }
  ];

  const eliteServices = [
    { 
      icon: Plane, 
      title: "Luxury Annual Pediatric Wellness Retreat", 
      description: "3-day family retreat at luxury resort in Georgia/SC with health workshops and spa",
      highlight: "Family-Inclusive Experience"
    },
    { 
      icon: Clock, 
      title: "Personal Pediatric Nurse On-Call", 
      description: "24/7 immediate support from dedicated pediatric nursing professional - in addition to physician direct messaging access",
      highlight: "Available 24/7"
    },
    { 
      icon: Apple, 
      title: "Private Nutritionist Consultations", 
      description: "Tailored meal plans and ongoing dietary guidance for optimal child nutrition",
      highlight: "Personalized Plans"
    },
    { 
      icon: GraduationCap, 
      title: "Educational & Developmental Consultations", 
      description: "Custom developmental screening and academic planning support",
      highlight: "Academic Planning"
    }
  ];

  const freeDevices = [
    { name: "Tyto Kit", description: "Professional-grade home examination device" },
    { name: "Owlet Smart Sock", description: "For appropriate age monitoring" },
    { name: "Nanit Pro", description: "Advanced baby monitoring system" },
    { name: "Remmie Device", description: "Smart health tracking solution" }
  ];

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-blue-50">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-indigo-700 via-purple-700 to-blue-700 text-white overflow-hidden">
        {/* Diamond Ribbon */}
        <div className="absolute top-0 right-0 w-40 h-40 overflow-hidden">
          <div className="absolute top-6 right-[-40px] w-48 h-10 bg-gradient-to-r from-yellow-400 to-amber-500 transform rotate-45 shadow-lg flex items-center justify-center">
            <span className="text-purple-900 font-bold text-sm">
              Diamond Concierge
            </span>
          </div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <Sparkles className="w-16 h-16 mx-auto text-yellow-300 mb-6" />
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              Diamond <span className="text-yellow-300">Concierge</span> Care
            </h1>
            <p className="text-xl text-indigo-100 max-w-3xl mx-auto mb-8">
              The ultimate pediatric care experience with luxury services, 24/7 access, 
              and exclusive family wellness retreats. Investing in your child's health with exceptional service.
            </p>
            
            {/* Early Bird Special */}
            <div className="bg-gradient-to-r from-yellow-500 to-amber-500 text-purple-900 rounded-2xl p-6 max-w-4xl mx-auto mb-8">
              <div className="flex items-center justify-center gap-3 mb-3">
                <Gift className="w-8 h-8" />
                <h2 className="text-2xl font-bold">Limited Time: Early Bird Incentive</h2>
              </div>
              <p className="text-lg font-semibold">
                Pay for your full 2026 Diamond Concierge Package and receive <span className="font-bold">complimentary Gold membership care from October-December 2025!</span>
              </p>
              <p className="text-sm mt-2 opacity-90">
                Program launches January 2026 - Early registrants get immediate premium benefits
              </p>
            </div>

            <div className="text-center">
              {showPricing ? (
                <>
                  <div className="text-5xl font-bold text-yellow-300 mb-2">$30,000</div>
                  <div className="text-xl text-indigo-200">Annual Investment in Your Child's Health</div>
                </>
              ) : (
                <div className="bg-black/20 text-yellow-300 p-4 rounded-lg">Pricing available to active members.</div>
              )}
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Important Notice */}
        <div className="mb-12 bg-blue-50 border-2 border-blue-200 rounded-3xl p-8">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-blue-800 mb-4">Complete Gold Tier + Premium Concierge Services</h2>
            <p className="text-lg text-blue-700 mb-6">
              Diamond Concierge members receive <strong>everything included in our Gold membership tier</strong> PLUS all the exclusive concierge services listed below.
            </p>
            <div className="bg-white rounded-2xl p-6 shadow-md">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Multi-Child Discount Structure</h3>
              <p className="text-gray-700 mb-4">Discounts are applied per individual child, not to the entire family:</p>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-center">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <div className="text-2xl font-bold text-gray-900">{showPricing ? '$30,000' : 'Base Price'}</div>
                  <div className="text-sm text-gray-600">First Child</div>
                </div>
                <div className="p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{showPricing ? '$27,000' : '10% off'}</div>
                  <div className="text-sm text-gray-600">Second Child</div>
                </div>
                <div className="p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{showPricing ? '$25,500' : '15% off'}</div>
                  <div className="text-sm text-gray-600">Third Child</div>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">{showPricing ? '$24,000' : '20% off'}</div>
                  <div className="text-sm text-gray-600">Fourth+ Child</div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Core Services */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Enhanced Service Portfolio</h2>
            <p className="text-xl text-gray-600">Core services included in every Diamond package</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {coreServices.map((service, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 bg-indigo-50 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <service.icon className="w-8 h-8 text-indigo-600" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600">{service.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Signature Diamond Services */}
        <section className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Signature <span className="text-purple-600">Diamond</span> Services
            </h2>
            <p className="text-xl text-gray-600">
              Every Diamond Concierge membership includes these premium services at no extra cost.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {eliteServices.map((service, index) => (
              <Card key={index} className="border-0 shadow-xl hover:shadow-2xl transition-shadow duration-300 relative overflow-hidden">
                <div className="absolute top-4 right-4">
                  <Badge className="bg-purple-100 text-purple-800 border-purple-200">
                    <Star className="w-3 h-3 mr-1" />
                    {service.highlight}
                  </Badge>
                </div>
                <CardContent className="p-8">
                  <div className="flex items-start gap-6">
                    <div className="w-16 h-16 bg-purple-50 rounded-2xl flex items-center justify-center flex-shrink-0">
                      <service.icon className="w-8 h-8 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                      <p className="text-gray-600">{service.description}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        {/* Free Devices & Genetic Testing */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-3xl p-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Complimentary <span className="text-green-600">Technology</span> & Testing
              </h2>
              <p className="text-xl text-gray-600">Premium devices and genetic insights provided specific to your family's patient needs</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {freeDevices.map((device, index) => (
                <div key={index} className="bg-white rounded-xl p-6 shadow-md">
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Monitor className="w-6 h-6 text-green-600" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">{device.name}</h4>
                  <p className="text-gray-600 text-sm">{device.description}</p>
                </div>
              ))}
            </div>
            
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-blue-600" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Comprehensive Genetic Testing</h3>
                <p className="text-gray-600 mb-6">
                  Inclusive genetic screening via industry leaders: PreventionGenetics, Invitae, or GeneDX - specific to patient needs
                </p>
                <div className="flex justify-center gap-4 text-sm text-gray-500">
                  <span>• Hereditary Health Insights</span>
                  <span>• Personalized Care Plans</span>
                  <span>• Family Health History</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Membership Terms */}
        <section className="mb-16">
          <Card className="bg-yellow-50 border-yellow-200 shadow-xl">
            <CardContent className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-6 h-6 text-yellow-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-yellow-800 mb-3">Membership Terms & Early Bird Benefits</h3>
                  <div className="space-y-3 text-yellow-700">
                    <p>• <strong>12-Month Care Guarantee:</strong> Regardless of join date, you receive 12 full months of Diamond Concierge care</p>
                    <p>• <strong>Program Launch:</strong> Official Diamond Concierge tier begins January 2026</p>
                    <p>• <strong>Early Bird Bonus:</strong> Join before January and receive complimentary Gold membership care through December 2025</p>
                    <p>• <strong>Payment:</strong> Full annual payment required for 2026 to qualify for early bird benefits</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* New Pricing & Upgrade Policy Section */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="shadow-xl border-0">
              <CardHeader className="flex flex-row items-center gap-3">
                <Users2 className="w-8 h-8 text-blue-600" />
                <CardTitle className="text-2xl font-bold text-gray-900">Pricing & Sibling Policy</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-lg font-semibold text-gray-800">Base Price</p>
                  {showPricing ? (
                    <p className="text-3xl font-bold text-blue-600">$30,000 <span className="text-lg font-medium text-gray-600">/ year for the first child</span></p>
                  ) : (
                    <p className="text-xl font-medium text-gray-600">Visible to active members</p>
                  )}
                </div>
                <div className="pt-4 border-t">
                  <p className="text-lg font-semibold text-gray-800">Sibling & Multiple Birth Discounts</p>
                  <ul className="space-y-2 mt-2 text-gray-700">
                    <li className="flex items-center gap-2"><Percent className="w-4 h-4 text-green-500" /> <strong>Second Sibling:</strong> 10% Discount</li>
                    <li className="flex items-center gap-2"><Percent className="w-4 h-4 text-green-500" /> <strong>Third Sibling:</strong> 15% Discount</li>
                    <li className="flex items-center gap-2"><Percent className="w-4 h-4 text-green-500" /> <strong>Fourth+ Sibling:</strong> 20% Discount</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-xl border-0 bg-blue-50">
              <CardHeader className="flex flex-row items-center gap-3">
                <CheckCircle className="w-8 h-8 text-green-600" />
                <CardTitle className="text-2xl font-bold text-gray-900">Upgrade for Active Members</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-lg text-blue-800">
                  The Diamond Concierge plan is an exclusive upgrade available only to our active members.
                </p>
                <div className="p-3 bg-green-100 border border-green-200 rounded-lg">
                  <p className="font-semibold text-green-800">Annual Plan Members</p>
                  <p className="text-green-700">The remaining value of your current annual membership will be credited towards your Diamond Concierge fee.</p>
                </div>
                <div className="p-3 bg-orange-100 border border-orange-200 rounded-lg">
                  <p className="font-semibold text-orange-800">Monthly Plan Members</p>
                  <p className="text-orange-700">You can upgrade at any time, but monthly payments will not be credited towards the Diamond fee.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Member Status & Inquiry Form */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Member Status */}
          {memberStatus.isMember ? (
            <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 shadow-xl">
              <CardContent className="p-8">
                <div className="flex items-center gap-3 mb-6">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                  <h3 className="text-2xl font-bold text-gray-900">Upgrade Available</h3>
                </div>
                <div className="space-y-4 text-gray-700">
                  <p>Current Plan: <Badge className="ml-2">{memberStatus.details?.plan_tier?.toUpperCase()}</Badge></p>
                  {memberStatus.details?.payment_frequency === 'annual' ? (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <p className="font-semibold text-green-800">Annual Member Upgrade Policy:</p>
                      <p className="text-green-700 mb-2">
                        <strong>If you upgrade today</strong>, the prorated balance of your current annual membership will be discounted from the Diamond Concierge service fee.
                      </p>
                      <p className="text-green-700 text-sm">
                        This ensures you receive full value for your existing investment while transitioning to our premium Diamond tier.
                      </p>
                    </div>
                  ) : (
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                      <p className="font-semibold text-orange-800">Monthly Member Upgrade Policy:</p>
                      <p className="text-orange-700 mb-2">
                        <strong>If you upgrade today</strong>, you will need to pay the full annual Diamond Concierge fee. We are unable to apply monthly payment credits toward the Diamond upgrade.
                      </p>
                      <p className="text-orange-700 text-sm">
                        Monthly payments do not qualify for prorated discounts when upgrading to Diamond Concierge.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="relative">
              <Card className="bg-gradient-to-r from-red-50 to-pink-50 border-red-200 shadow-xl h-full">
                <CardContent className="p-8 text-center flex flex-col justify-center items-center h-full">
                  <Shield className="w-12 h-12 text-red-500 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">Membership Required</h3>
                  <p className="text-gray-600 mb-6 max-w-md mx-auto">
                    Diamond Concierge tier is exclusively available as an upgrade for verified active members. Until your registration is verified, you will not be able to access payment details of the Diamond Concierge service.
                  </p>
                </CardContent>
              </Card>
              <AnimatedArrows />
            </div>
          )}

          {/* Inquiry Form */}
          <Card className="shadow-xl border-0">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-gray-900">Connect with Our Concierge Team</CardTitle>
              <p className="text-gray-600">
                Provide your details below to send a message and schedule a complimentary video conference with our Concierge Coordinator at your convenience.
              </p>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="full_name" className="flex items-center gap-2">
                    <UserIcon className="w-4 h-4" />
                    Full Name *
                  </Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => handleInputChange("full_name", e.target.value)}
                    placeholder="Your full name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Address *
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange("email", e.target.value)}
                    placeholder="your.email@example.com"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone Number *
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handleInputChange("phone", e.target.value)}
                    placeholder="(555) 123-4567"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="message" className="flex items-center gap-2">
                    <MessageSquare className="w-4 h-4" />
                    Your Message *
                  </Label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={(e) => handleInputChange("message", e.target.value)}
                    placeholder="Please tell us about your family's needs, questions about the Diamond tier, or interest in early adopter benefits..."
                    rows={5}
                    required
                  />
                </div>
                
                <Button
                  type="submit"
                  className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white py-6 text-lg"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Submitting...</> : (
                    <>
                      Submit Inquiry & Schedule Meeting
                      <Calendar className="w-5 h-5 ml-2" />
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <FAQSection 
          pageName="ConciergeInquiry" 
          title="Diamond Concierge Questions"
        />

        {/* Custom Calendar Popup */}
        {isCalendarOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-2xl w-[75vw] h-[75vh] relative flex flex-col">
              <div className="flex justify-between items-center p-4 border-b">
                <h3 className="text-lg font-semibold text-gray-900">Schedule Your Informational Meeting</h3>
                <button 
                  onClick={closeCalendar}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
              <div className="flex-1 p-4">
                <iframe
                  src={calendarUrl}
                  className="w-full h-full border-0 rounded"
                  title="Schedule Informational Meeting"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
