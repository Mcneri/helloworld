
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CtaSection from '../components/home/CtaSection';

export default function BlogHowToFind() {
  useEffect(() => {
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    const title = "How to Find Concierge Doctor Near You | Private Pediatrician Atlanta GA";
    const description = "Expert guide on finding the right concierge doctor near you. Discover atlanta pediatricians offering concierge pediatric practice, pediatric clinic atlanta locations, and private pediatrician nearby for your family's pediatric care atlanta needs.";
    document.title = title;

    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = description;
    metaDescription.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(metaDescription);
    
    const schema = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": window.location.href
      },
      "headline": "How to Find Concierge Doctor Near You: Private Pediatrician Atlanta GA Selection Guide",
      "alternativeHeadline": "Finding the Best Atlanta Pediatricians and Concierge Pediatric Practice for Your Family",
      "description": description,
      "image": "https://images.unsplash.com/photo-1584432810601-6c7f27d2362b?w=800&auto=format&fit=crop&q=60",
      "author": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Expert Atlanta Pediatricians",
        "url": window.location.origin
      },
      "publisher": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Leading Pediatric Clinic Atlanta",
        "logo": {
          "@type": "ImageObject",
          "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png"
        },
        "url": window.location.origin
      },
      "datePublished": new Date().toISOString().split('T')[0],
      "dateModified": new Date().toISOString().split('T')[0],
      "keywords": "find concierge doctor near you, private pediatrician nearby, atlanta pediatricians, concierge pediatric practice, pediatric clinic atlanta, pediatric care atlanta, concierge doctors in georgia, children doctor atlanta, direct primary care",
      "about": [
        {
          "@type": "Thing",
          "name": "Concierge Doctor Selection",
          "description": "How to find the right private pediatrician nearby and evaluate atlanta pediatricians for your family"
        },
        {
          "@type": "Thing",
          "name": "Dr. Michael Nwaneri Credentials",
          "description": "30+ years experience across UK, Nigeria, Ghana, USA - vaccine-friendly pediatrician atlanta ga"
        },
        {
          "@type": "Thing",
          "name": "Pediatric Clinic Atlanta Features",
          "description": "What to look for in concierge pediatric practice and at home pediatrics services"
        }
      ],
      "mentions": [
        {
          "@type": "MedicalBusiness",
          "name": "Omega Pediatrics Georgia",
          "description": "Premier concierge pediatric practice offering pediatric care atlanta and private pediatrician nearby services"
        }
      ]
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.innerHTML = JSON.stringify(schema);
    schemaScript.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(schemaScript);
  }, []);

  return (
    <div className="bg-white">
      <div className="relative pt-12 pb-16 sm:pt-16 sm:pb-24 lg:pt-24 lg:pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-1 lg:gap-8">
            <div className="mx-auto max-w-4xl px-4 sm:max-w-2xl sm:px-6 text-center lg:px-0 lg:flex lg:items-center">
              <div className="lg:py-24">
                <h1 className="mt-4 text-4xl tracking-tight font-extrabold text-gray-900 sm:mt-5 sm:text-6xl lg:mt-6 xl:text-6xl">
                  <span className="block">How to Find the Right</span>
                  <span className="block text-teal-600">Concierge Doctor for Your Family</span>
                </h1>
                <div className="mt-6 text-left max-w-4xl mx-auto space-y-6 text-lg text-gray-700 leading-relaxed">
                  <p>
                    So you've decided to explore a more personalized healthcare experience for your family—that's fantastic! But now comes the next step: <strong>how to find a concierge doctor</strong> who's truly the right fit. It all starts with identifying your specific needs. Are you looking for a general practitioner, or perhaps a specialized <strong>pediatric concierge medicine</strong> approach? Once you know what you're looking for, searching for options to <strong>find a concierge doctor near you</strong> or exploring <strong>concierge doctors in your area</strong> becomes much more focused and productive.
                  </p>
                  
                  <p>
                    For families here in Georgia, finding the right <strong>concierge doctor near you</strong> involves more than just proximity—it's about checking credentials, reviewing available services, and most importantly, assessing whether the practice's philosophy aligns with your family's values. You want to look for a practice that offers comprehensive <strong>pediatric care Atlanta</strong> families can truly rely on, whether that's at a welcoming <strong>pediatric clinic Atlanta</strong> location or through convenient <strong>at home pediatrics</strong> services for eligible plans.
                  </p>
                  
                  <p>
                    At Omega Pediatrics, Dr. Michael Nwaneri stands out among <strong>concierge doctors in Georgia</strong> for his unique ability to connect with both parents and children. With over 30 years of experience practicing in the UK, Nigeria, Ghana, and now the USA, Dr. Nwaneri brings a depth of knowledge that's truly remarkable. What makes him special isn't just his extensive background—it's his almost spiritual way of connecting with families. Parents often tell us that when Dr. Nwaneri enters a room, their concerns and worries about illness seem to just fade away. His matter-of-fact approach and talent for explaining complex medical concepts using simple, relatable metaphors means even the most complicated health topics become clear and understandable.
                  </p>
                  
                  <p>
                    This is why families literally drive for two hours just to have their child seen by Dr. Nwaneri. He is widely recognized as one of the most effective vaccine-friendly pediatricians in Georgia, making him an ideal choice for families seeking both comprehensive care and a compassionate approach. When you're searching for a <strong>private pediatrician nearby</strong>, consider not just the services offered, but the genuine partnership you'll gain in your child's health journey. Our <strong>direct primary care</strong> model ensures that this partnership is built on accessibility, personalized attention, and a deep commitment to your family's well-being. Don't just pick the closest option; choose a practice that genuinely resonates with your healthcare goals for your children.
                  </p>
                </div>
                <div className="mt-10 sm:mt-12">
                  <Link to={createPageUrl("FAQ")}>
                    <Button size="lg" className="btn-enhanced bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg">
                      Read Our FAQs
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <CtaSection />
    </div>
  );
}
