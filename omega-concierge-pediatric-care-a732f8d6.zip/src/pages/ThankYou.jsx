
import React, { useEffect, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle,
  LayoutDashboard,
  Globe,
  ExternalLink,
  CreditCard,
  Banknote,
  AtSign,
  DollarSign,
  AlertCircle,
  Phone,
  Mail,
  Clock,
  CheckSquare
} from "lucide-react";
import { Member } from "@/api/entities";

export default function ThankYou() {
  const [searchParams] = useSearchParams();
  const [memberData, setMemberData] = useState(null);
  const [loading, setLoading] = useState(true);

  const memberId = searchParams.get('member_id');
  const paymentMethod = searchParams.get('payment_method');
  const paymentSuccess = searchParams.get('payment_success') === 'true';
  const emailFailed = searchParams.get('email_failed') === 'true';

  useEffect(() => {
    const fetchMemberData = async () => {
      if (memberId && memberId !== 'error') {
        try {
          const member = await Member.get(memberId);
          setMemberData(member);
        } catch (error) {
          console.error('Failed to fetch member data:', error);
        }
      }
      setLoading(false);
    };
    fetchMemberData();
  }, [memberId]);

  const getPaymentIcon = () => {
    switch (paymentMethod) {
      case 'card': return CreditCard;
      case 'ach': return Banknote;
      case 'zelle': return AtSign;
      case 'paypal': return DollarSign;
      default: return CreditCard;
    }
  };

  const getPaymentMethodName = () => {
    switch (paymentMethod) {
      case 'card': return 'Credit Card';
      case 'ach': return 'ACH Bank Transfer';
      case 'zelle': return 'Zelle';
      case 'paypal': return 'PayPal';
      default: return 'Payment Method';
    }
  };

  const getPlanBadgeColor = (tier) => {
    switch (tier) {
      case 'bronze': return 'bg-amber-100 text-amber-800';
      case 'silver': return 'bg-gray-100 text-gray-800';
      case 'gold': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const PaymentIcon = getPaymentIcon();

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-white to-green-50 flex items-center justify-center p-4">
      <div className="max-w-3xl mx-auto text-center">
        <Card className="shadow-2xl border-0 overflow-hidden">
          <div className="bg-gradient-to-r from-teal-600 to-cyan-600 text-white p-8">
            <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              Welcome to Omega Pediatrics!
            </h1>
            <p className="text-xl text-teal-100">
              Your membership application has been successfully submitted.
            </p>
          </div>

          <CardContent className="p-8 space-y-6">
            {loading ? (
              <div className="animate-pulse space-y-4">
                <div className="h-6 bg-gray-200 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2 mx-auto"></div>
              </div>
            ) : memberData ? (
              <div className="space-y-6">
                {/* Member Details */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                  <h3 className="text-lg font-semibold text-blue-900 mb-4">Your Membership Details</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-blue-700">Plan Selected</p>
                      <Badge className={`${getPlanBadgeColor(memberData.plan_tier)} text-sm font-semibold mt-1`}>
                        {memberData.plan_tier.charAt(0).toUpperCase() + memberData.plan_tier.slice(1)} Plan
                      </Badge>
                    </div>
                    <div>
                      <p className="text-sm text-blue-700">Payment Frequency</p>
                      <p className="font-semibold text-blue-900">
                        {memberData.payment_frequency.charAt(0).toUpperCase() + memberData.payment_frequency.slice(1)}
                        {memberData.payment_frequency === 'annual' && <span className="text-green-600 text-sm ml-2">(27% Savings!)</span>}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-blue-700">Children Covered</p>
                      <p className="font-semibold text-blue-900">{memberData.children_count}</p>
                    </div>
                    <div>
                      <p className="text-sm text-blue-700">Membership Starts</p>
                      <p className="font-semibold text-blue-900">
                        {new Date(memberData.start_date).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Payment Status */}
                <div className="space-y-4">
                  <div className="flex items-center justify-center gap-3 mb-4">
                    <PaymentIcon className="w-6 h-6 text-blue-600" />
                    <h3 className="text-lg font-semibold text-gray-900">{getPaymentMethodName()}</h3>
                  </div>

                  {paymentMethod === 'card' && paymentSuccess && (
                    <Alert className="border-green-200 bg-green-50">
                      <CheckSquare className="h-4 w-4 text-green-600" />
                      <AlertDescription className="text-green-800">
                        <strong>Payment Successful!</strong> Your credit card payment has been processed successfully. 
                        Your membership is now active and you'll receive a welcome email shortly.
                      </AlertDescription>
                    </Alert>
                  )}

                  {paymentMethod === 'card' && !paymentSuccess && (
                    <Alert className="border-yellow-200 bg-yellow-50">
                      <Clock className="h-4 w-4 text-yellow-600" />
                      <AlertDescription className="text-yellow-800">
                        <strong>Payment Processing:</strong> Your payment is being processed. 
                        You'll receive a confirmation email once it's complete.
                      </AlertDescription>
                    </Alert>
                  )}

                  {paymentMethod === 'ach' && (
                    <Alert className="border-blue-200 bg-blue-50">
                      <AlertCircle className="h-4 w-4 text-blue-600" />
                      <AlertDescription className="text-blue-800">
                        <div className="space-y-3">
                          <p><strong>Next Steps for ACH Payment:</strong></p>
                          <div className="bg-white p-4 rounded-lg border border-blue-200">
                            <div className="text-sm space-y-2">
                              <div><strong>Bank:</strong> Middlesex Federal Savings, F.A.</div>
                              <div><strong>Routing:</strong> 211370150</div>
                              <div><strong>Account:</strong> 98925236</div>
                              <div><strong>Amount:</strong> ${memberData.payment_frequency === 'annual' ? memberData.annual_amount : (memberData.monthly_amount * 2)}</div>
                            </div>
                          </div>
                          <p className="font-semibold">Important: Send payment within 24 hours and email receipt to info@omegapediatrics.com</p>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {paymentMethod === 'zelle' && (
                    <Alert className="border-purple-200 bg-purple-50">
                      <AtSign className="h-4 w-4 text-purple-600" />
                      <AlertDescription className="text-purple-800">
                        <div className="space-y-3">
                          <p><strong>Complete Your Zelle Payment:</strong></p>
                          <div className="bg-white p-4 rounded-lg border border-purple-200">
                            <div className="text-center">
                              <p><strong>Send to:</strong> info@omegapediatrics.com</p>
                              <p><strong>Amount:</strong> ${memberData.payment_frequency === 'annual' ? memberData.annual_amount : (memberData.monthly_amount * 2)}</p>
                            </div>
                          </div>
                          <p className="font-semibold">Set up recurring payments and email confirmation to info@omegapediatrics.com</p>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}

                  {paymentMethod === 'paypal' && (
                    <Alert className="border-indigo-200 bg-indigo-50">
                      <DollarSign className="h-4 w-4 text-indigo-600" />
                      <AlertDescription className="text-indigo-800">
                        <div className="space-y-3">
                          <p><strong>Complete Your PayPal Payment:</strong></p>
                          <p>Send ${memberData.payment_frequency === 'annual' ? memberData.annual_amount : (memberData.monthly_amount * 2)} to: <strong>info@omegapediatrics.com</strong></p>
                          <p className="font-semibold">Set up recurring payments and email receipt to info@omegapediatrics.com</p>
                        </div>
                      </AlertDescription>
                    </Alert>
                  )}
                </div>

                {emailFailed && (
                  <Alert className="border-yellow-200 bg-yellow-50">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <AlertDescription className="text-yellow-800">
                      Your membership was created successfully, but there was an issue sending the welcome email. 
                      Please contact us if you don't receive a confirmation email within 24 hours.
                    </AlertDescription>
                  </Alert>
                )}

                {/* Contact Information */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Need Help?</h4>
                  <div className="flex flex-col sm:flex-row gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-teal-600" />
                      <span>470-485-6342</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-teal-600" />
                      <span>info@omegapediatrics.com</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
                Thank you for choosing Omega Pediatrics. We've received your membership application.
              </p>
            )}

            <div className="flex flex-col sm:flex-row gap-4">
              <Button asChild className="flex-1 bg-teal-600 hover:bg-teal-700">
                <Link to={createPageUrl("Dashboard")} className="flex items-center justify-center gap-2">
                  <LayoutDashboard className="w-4 h-4" />
                  Go to Dashboard
                </Link>
              </Button>
              <Button asChild variant="outline" className="flex-1">
                <a href="https://www.omegapediatrics.com" target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2">
                  <Globe className="w-4 h-4" />
                  Visit Main Website
                  <ExternalLink className="w-4 h-4" />
                </a>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
