
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CtaSection from '../components/home/CtaSection';

export default function BlogOmegaAtlanta() {
  useEffect(() => {
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    const title = "Omega Pediatrics: Premier Concierge Doctor Atlanta | Top Pediatrician GA";
    const description = "Discover why Omega Pediatrics is Atlanta's top choice for concierge doctor atlanta services. Led by Dr. Michael Nwaneri, we offer exceptional concierge pediatric practice, pediatric care atlanta, children's medical concierge, and at home pediatrics for families seeking the best pediatrician atlanta ga.";
    document.title = title;

    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = description;
    metaDescription.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(metaDescription);
    
    const schema = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": window.location.href
      },
      "headline": "Omega Pediatrics: Premier Concierge Doctor Atlanta - Top Pediatrician GA with 30+ Years Experience",
      "alternativeHeadline": "Dr. Michael Nwaneri Leading Concierge Pediatric Practice and Children's Medical Concierge Atlanta",
      "description": description,
      "image": "https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?w=800&auto=format&fit=crop&q=60",
      "author": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Premier Concierge Doctor Atlanta",
        "url": window.location.origin
      },
      "publisher": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Leading Pediatric Care Atlanta Provider",
        "logo": {
          "@type": "ImageObject",
          "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png"
        },
        "url": window.location.origin
      },
      "datePublished": new Date().toISOString().split('T')[0],
      "dateModified": new Date().toISOString().split('T')[0],
      "keywords": "concierge doctor atlanta, top pediatrician atlanta, pediatrician atlanta ga, concierge pediatric practice, pediatric care atlanta, children's medical concierge, at home pediatrics, concierge medicine doctors near you, pediatric clinic atlanta, direct primary care DPC",
      "about": [
        {
          "@type": "Person",
          "name": "Dr. Michael Nwaneri",
          "description": "Top pediatrician atlanta ga with 30+ years international experience, leading concierge doctor atlanta practice",
          "jobTitle": "Pediatrician",
          "worksFor": {
            "@type": "MedicalBusiness",
            "name": "Omega Pediatrics"
          }
        },
        {
          "@type": "Thing",
          "name": "Spiritual Connection with Families",
          "description": "Dr. Nwaneri's unique ability to make concerns and illness fade away, making him the most effective vaccine-friendly pediatrician atlanta ga"
        },
        {
          "@type": "Thing",
          "name": "Comprehensive Pediatric Services",
          "description": "Concierge pediatric practice offering unlimited visits, at home pediatrics, and 24/7 access to top pediatrician atlanta"
        }
      ],
      "mentions": [
        {
          "@type": "MedicalBusiness",
          "name": "Omega Pediatrics Atlanta",
          "description": "Premier pediatric clinic atlanta offering concierge doctor atlanta services and children's medical concierge care",
          "address": {
            "@type": "PostalAddress",
            "addressLocality": "Atlanta",
            "addressRegion": "GA"
          }
        }
      ]
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.innerHTML = JSON.stringify(schema);
    schemaScript.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(schemaScript);
  }, []);

  return (
    <div className="bg-white">
      <div className="relative pt-12 pb-16 sm:pt-16 sm:pb-24 lg:pt-24 lg:pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-1 lg:gap-8">
            <div className="mx-auto max-w-4xl px-4 sm:max-w-2xl sm:px-6 text-center lg:px-0 lg:flex lg:items-center">
              <div className="lg:py-24">
                <h1 className="mt-4 text-4xl tracking-tight font-extrabold text-gray-900 sm:mt-5 sm:text-6xl lg:mt-6 xl:text-6xl">
                  <span className="block">Omega Pediatrics: Your Premier</span>
                  <span className="block text-teal-600">Concierge Doctor in Atlanta</span>
                </h1>
                <div className="mt-6 text-left max-w-4xl mx-auto space-y-6 text-lg text-gray-700 leading-relaxed">
                  <p>
                    When you search for a <strong>concierge doctor near you</strong> in the Atlanta area, you're looking for more than just a physician—you're seeking a true healthcare partner for your family. At Omega Pediatrics, we embody what it means to be a modern <strong>concierge doctor</strong> through our <strong>direct primary care</strong> model. Our practice is built on a foundation of trust, accessibility, and deeply personalized care. As one of the leading practices offering <strong>concierge doctors in Georgia</strong>, we provide a level of service specifically designed to give you complete peace of mind about your child's health.
                  </p>
                  
                  <p>
                    What truly sets us apart is Dr. Michael Nwaneri, who leads our team with over 30 years of experience practicing in the UK, Nigeria, Ghana, and now the USA. Dr. Nwaneri has an almost spiritual way of connecting with both parents and children that's truly remarkable. When he enters a room, parents consistently tell us their concerns, worries, and fears about illness seem to just fade away. His matter-of-fact approach combined with his talent for explaining complex medical concepts using simple, relatable metaphors means he can make even the most complicated health topics understandable—so clear that, as he likes to say, even a "caveman" would get it!
                  </p>
                  
                  <p>
                    This extraordinary ability to connect and communicate is why families literally drive for two hours just to have their child seen by Dr. Nwaneri. He is widely recognized as one of the most effective vaccine-friendly pediatricians in Georgia, making him the ideal choice for families who want comprehensive, evidence-based care delivered with genuine compassion. Our model provides the best of what you're looking for when seeking <strong>concierge medicine doctors near you</strong>: unlimited visits, 24/7 direct access to our pediatricians, and an unwavering commitment to your child's long-term wellness. Whether you visit our welcoming <strong>pediatric clinic Atlanta</strong> location or receive care through our <strong>at home pediatrics</strong> services for eligible plans, you'll experience the difference that personalized attention makes.
                  </p>
                  
                  <p>
                    If you've been on a long search to find a <strong>concierge doctor near your home</strong>, we're confident you'll feel right at home with Omega Pediatrics. Our <strong>DPC</strong> approach means no more wondering if you can afford to bring your child in for a concern, no more waiting weeks for appointments, and no more feeling rushed through visits. Instead, you'll have a true partner in your child's health—one who knows your family's unique needs and is always just a phone call away. This is what exceptional <strong>pediatric care Atlanta</strong> should look like, and it's exactly what we deliver every single day.
                  </p>
                </div>
                <div className="mt-10 sm:mt-12">
                  <Link to={createPageUrl("Join")}>
                    <Button size="lg" className="btn-enhanced bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg">
                      Join Our Practice
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <CtaSection />
    </div>
  );
}
