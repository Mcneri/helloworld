import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Users } from "lucide-react";

export default function MemberSignIn() {
  const navigate = useNavigate();

  useEffect(() => {
    const checkUser = async () => {
      try {
        const user = await User.me();
        if (user) {
          navigate(createPageUrl("Dashboard"));
        }
      } catch (e) {
        // User not logged in, stay on this page
      }
    };
    checkUser();
  }, [navigate]);

  const handleSignIn = async () => {
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl("Dashboard"));
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl border-0">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-blue-600" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-900">Member Sign In</CardTitle>
          <p className="text-gray-600">Access your membership dashboard and community forum</p>
        </CardHeader>
        <CardContent className="space-y-6">
          <Button onClick={handleSignIn} className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg">
            Sign In with Google
          </Button>
          <div className="text-center text-sm text-gray-500">
            <p>Don't have an account? <a href={createPageUrl("Join")} className="text-blue-600 hover:underline">Join Now</a></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}