
import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import CtaSection from '../components/home/CtaSection';

export default function BlogFeesAndInsurance() {
  useEffect(() => {
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    const title = "Concierge Doctor Fees HSA Medicare | Pediatric Clinic Atlanta Costs";
    const description = "Complete guide to concierge doctor fees, HSA eligibility, Medicare coverage for pediatric care atlanta. Learn about concierge pediatric practice costs, payment options, and whether pediatric clinic atlanta services are tax deductible.";
    document.title = title;

    const metaDescription = document.createElement('meta');
    metaDescription.name = 'description';
    metaDescription.content = description;
    metaDescription.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(metaDescription);

    const schema = {
      "@context": "https://schema.org",
      "@type": "BlogPosting",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": window.location.href
      },
      "headline": "Concierge Doctor Fees HSA Medicare Guide: Pediatric Clinic Atlanta Payment Options",
      "alternativeHeadline": "Understanding Concierge Pediatric Practice Costs and Insurance for Pediatric Care Atlanta",
      "description": description,
      "image": "https://images.unsplash.com/photo-1560518883-ce09059ee41f?w=800&auto=format&fit=crop&q=60",
      "author": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Transparent Pediatric Clinic Atlanta",
        "url": window.location.origin
      },
      "publisher": {
        "@type": "Organization",
        "name": "Omega Pediatrics - Affordable Pediatric Care Atlanta",
        "logo": {
          "@type": "ImageObject",
          "url": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/73cbf9b31_omegapediatricslogo3D1.png"
        },
        "url": window.location.origin
      },
      "datePublished": new Date().toISOString().split('T')[0],
      "dateModified": new Date().toISOString().split('T')[0],
      "keywords": "concierge doctor fees, concierge doctor fees HSA eligible, concierge doctors accept medicare, annual fee concierge doctor deductible, pediatric clinic atlanta costs, concierge pediatric practice pricing, pediatric care atlanta payment, direct primary care DPC",
      "about": [
        {
          "@type": "Thing",
          "name": "Concierge Doctor Fee Structure",
          "description": "HSA eligibility, Medicare coverage, and tax deductibility for pediatric clinic atlanta concierge services"
        },
        {
          "@type": "Thing",
          "name": "Direct Primary Care Benefits",
          "description": "Cost transparency and value of DPC model for pediatric care atlanta families"
        },
        {
          "@type": "Thing",
          "name": "Dr. Michael Nwaneri Financial Guidance",
          "description": "Clear communication about concierge pediatric practice costs and payment options"
        }
      ],
      "mentions": [
        {
          "@type": "FinancialProduct",
          "name": "HSA FSA Coverage",
          "description": "Health Savings Account eligibility for concierge doctor fees and pediatric care atlanta services"
        }
      ]
    };

    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.innerHTML = JSON.stringify(schema);
    schemaScript.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(schemaScript);
  }, []);

  return (
    <div className="bg-white">
      <div className="relative pt-12 pb-16 sm:pt-16 sm:pb-24 lg:pt-24 lg:pb-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="lg:grid lg:grid-cols-1 lg:gap-8">
            <div className="mx-auto max-w-4xl px-4 sm:max-w-2xl sm:px-6 text-center lg:px-0 lg:flex lg:items-center">
              <div className="lg:py-24">
                <h1 className="mt-4 text-4xl tracking-tight font-extrabold text-gray-900 sm:mt-5 sm:text-6xl lg:mt-6 xl:text-6xl">
                  <span className="block">Concierge Doctor Fees:</span>
                  <span className="block text-teal-600">Deductibility, Medicare, and HSA Eligibility</span>
                </h1>
                <div className="mt-6 text-left max-w-4xl mx-auto space-y-6 text-lg text-gray-700 leading-relaxed">
                  <p>
                    When considering <strong>direct primary care</strong> or <strong>DPC</strong> for your family, concerns about payment and eligibility are completely natural. One of the most frequent questions we hear is this: "Do <strong>concierge doctors accept Medicare</strong>?" Here's the straightforward answer: typically, concierge practices don't "accept" Medicare or private insurance for the membership fee itself. That's because this fee covers enhanced access, administrative services, and the personalized attention that makes the concierge model so special—not specific medical procedures. However, your insurance can still be incredibly useful for things like hospital visits, specialist referrals, and tests that your <strong>concierge doctor</strong> might order for your child.
                  </p>
                  
                  <p>
                    Now, when it comes to taxes, many parents wonder, "Are <strong>concierge doctor fees deductible</strong>?" Generally speaking, <strong>concierge doctor fees</strong> aren't considered tax deductible as a medical expense, and the <strong>annual fee for a concierge doctor isn't a deductible expense</strong> in the traditional sense. However, there's some good news for many families: "Are <strong>concierge doctor fees HSA eligible</strong>?" In many cases, these fees *can* be paid using a Health Savings Account (HSA) or Flexible Spending Account (FSA), provided they're for qualified medical care. We always recommend checking with your tax advisor or benefits administrator to confirm your specific eligibility, as these rules can vary.
                  </p>
                  
                  <p>
                    At Omega Pediatrics, we understand that navigating the financial aspects of <strong>pediatric care Atlanta</strong> can feel overwhelming. That's why Dr. Michael Nwaneri and our team work hard to make the value crystal clear. With over 30 years of experience across multiple countries, Dr. Nwaneri brings not just medical expertise, but also a unique ability to communicate complex concepts—including financial ones—in ways that are easy to understand. His straightforward, metaphor-filled communication style extends to helping families understand their healthcare investment, making sure you feel confident about every aspect of your child's care.
                  </p>
                  
                  <p>
                    Understanding the financial model of a <strong>pediatric clinic Atlanta</strong> offering concierge services is key to smart family budgeting. While the upfront membership fee might seem different from traditional insurance, it actually provides incredible transparency for the comprehensive <strong>pediatric care Atlanta</strong> families receive, eliminating surprise bills for covered services. This direct fee structure for quality <strong>pediatric care Atlanta</strong> can actually simplify managing your family's healthcare expenses. Knowing your costs upfront allows for better financial planning, often proving more predictable than navigating complex insurance co-pays and deductibles for routine care. When you factor in the peace of mind that comes with having direct access to Dr. Nwaneri—a physician so effective that families travel two hours just to see him—the value becomes even clearer.
                  </p>
                </div>
                <div className="mt-10 sm:mt-12">
                  <Link to={createPageUrl("Plans")}>
                    <Button size="lg" className="btn-enhanced bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg">
                      See Payment Options
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <CtaSection />
    </div>
  );
}
