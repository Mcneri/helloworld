
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Member } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input"; // Added
import { Label } from "@/components/ui/label"; // Added
import { Alert, AlertDescription } from "@/components/ui/alert"; // Alert already imported, AlertDescription added
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  ArrowRight,
  Shield,
  Calendar,
  Users, // Kept for children count display
  Users2, // Added for profile section icon
  Heart,
  Loader2,
  AlertCircle,
  DollarSign,
  CreditCard,
  Facebook,
  MessageCircle,
  ExternalLink,
  CheckCircle,
  Globe,
  Lock,
  LayoutDashboard,
  Check,
  ChevronsUpDown,
  PlusCircle,
  LogOut,
  User as UserIcon,
  Bell,
  Settings,
  BarChart2,
  UserCheck, // Added
  Star, // Added
  ArrowUpRight, // Added
  Edit3, // Added
  Save, // Added
  X // Added
} from "lucide-react";
import { format } from "date-fns";
import { updateSubscription } from "@/api/functions";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

// New imports for FAQ consolidation
import FAQSection from '../components/FAQSection';
import { faqsByPage } from "../components/ExpandableFAQSection";

import DashboardSkeleton from "../components/ui/DashboardSkeleton";

// --- IMPORTANT: Replace placeholders with your actual Stripe Price IDs ---
const STRIPE_PRICE_IDS = {
  monthly: {
    bronze: 'price_1RpgDkJtNJAGE3wfLxgNJEE6',
    silver: 'price_1RpgFxJtNJAGE3wfaeZs2nBD',
    gold: 'price_1RpgJ2JtNJAGE3wfg2dbIbdc',
  },
  annual: {
    bronze: 'price_1RpgDkJtNJAGE3wfcT2O2HLl',
    silver: 'price_1RpgHNJtNJAGE3wfTVVWXZF7',
    gold: 'price_1RpgKhJtNJAGE3wfYlAVgGim',
  }
};

const planOrder = ['bronze', 'silver', 'gold'];

function UpgradeButton({ currentPlan, targetPlan, paymentFrequency, subscriptionId, onUpgrade }) {
    const [isUpgrading, setIsUpgrading] = useState(false);
    const newPriceId = STRIPE_PRICE_IDS[paymentFrequency][targetPlan];

    const handleUpgradeClick = async () => {
        setIsUpgrading(true);
        try {
            await updateSubscription({ subscriptionId, newPriceId });
            // The webhook will handle the data update.
            // We can optionally show a success message and refresh the page.
            onUpgrade();
        } catch (error) {
            console.error("Upgrade failed:", error);
            alert(`Upgrade failed: ${error.message}`);
        } finally {
            setIsUpgrading(false);
        }
    };

    return (
        <AlertDialog>
            <AlertDialogTrigger asChild>
                <Button className="w-full bg-green-600 hover:bg-green-700">
                    Upgrade to {targetPlan.charAt(0).toUpperCase() + targetPlan.slice(1)}
                    <ArrowRight className="ml-2 w-4 h-4" />
                </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Plan Upgrade</AlertDialogTitle>
                    <AlertDialogDescription>
                        You are about to upgrade to the {targetPlan.charAt(0).toUpperCase() + targetPlan.slice(1)} plan. Stripe will charge you a prorated amount for the remainder of the current billing cycle. This action cannot be undone.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleUpgradeClick} disabled={isUpgrading}>
                        {isUpgrading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Upgrading...</> : 'Confirm Upgrade'}
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}

export default function Dashboard() {
  const [member, setMember] = useState(null);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true); // Renamed from 'loading' for consistency
  const [error, setError] = useState(null);
  const [upgradeMessage, setUpgradeMessage] = useState('');
  const [isEditingProfile, setIsEditingProfile] = useState(false); // Added
  const [editedProfile, setEditedProfile] = useState({}); // Added
  const [updateLoading, setUpdateLoading] = useState(false); // Added

  // Consolidated FAQ data from a central source
  // We assume faqsByPage.dashboard exists and contains the relevant FAQs
  const accordionFAQs = faqsByPage.dashboard || [
    // Fallback or example if faqsByPage.dashboard is not yet populated
    {
      question: "How do I access my member dashboard?",
      answer: "Once your membership is active, you can access your member dashboard to view plan details, manage your account, and access exclusive member resources."
    },
    {
      question: "How do I book appointments?",
      answer: "Members can schedule appointments through our dedicated member portal or by calling our priority scheduling line. We strive to accommodate appointments within 24-48 hours for non-urgent concerns."
    },
    {
      question: "What member community resources are available?",
      answer: "Members gain access to our private parents community, including exclusive Facebook and WhatsApp groups, paid online events, masterclasses, parenting support, and direct updates from our team."
    },
    {
      question: "Is there a patient portal for medical records?",
      answer: "Yes, we provide access to a secure, HIPAA-compliant patient portal for viewing medical records, test results, and secure communications with our medical team. This is separate from your membership dashboard."
    },
    {
      question: "Can I upgrade my membership plan?",
      answer: "Yes, you can upgrade your plan at any time. Stripe will charge a prorated amount for the remainder of your current billing cycle. Downgrades are only available at renewal time."
    },
    {
      question: "What if I have feedback or need support?",
      answer: "We welcome all feedback and are here to support you. Please contact our team at info@omegapediatrics.com or call 470-485-6342, and we will address your concerns promptly."
    }
  ];

  useEffect(() => {
    // SEO and Metadata Setup
    document.title = "Member Dashboard | Omega Pediatrics";

    // Remove any previously added SEO scripts to prevent duplicates
    document.querySelectorAll('script[data-b44-seo="true"]').forEach(el => el.remove());

    // Schema.org - FAQPage for this page
    if (accordionFAQs && accordionFAQs.length > 0) { // Added null/undefined check for accordionFAQs
      const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": accordionFAQs.map(faq => ({
          "@type": "Question",
          "name": faq.question,
          "acceptedAnswer": {
            "@type": "Answer",
            // Remove HTML tags from answer before adding to schema
            "text": faq.answer.replace(/<[^>]*>?/gm, '') 
          }
        }))
      };
      const faqScript = document.createElement('script');
      faqScript.type = 'application/ld+json';
      faqScript.innerHTML = JSON.stringify(faqSchema);
      faqScript.setAttribute('data-b44-seo', 'true'); // Custom attribute for cleanup
      document.head.appendChild(faqScript);
    }
    
    const loadDashboardData = async () => {
      setIsLoading(true);
      try {
        const currentUser = await User.me();
        setUser(currentUser);
        if (currentUser.member_id) {
          try {
            const memberData = await Member.get(currentUser.member_id);
            setMember(memberData);
          } catch (memberError) {
            // Handle case where member_id points to non-existent member
            console.warn("Member record not found for user, clearing member_id:", memberError);
            // Clear the invalid member_id from the user record
            try {
              await User.updateMyUserData({ member_id: null });
            } catch (updateError) {
              console.error("Failed to clear invalid member_id:", updateError);
            }
            setError("No active membership found for this account.");
          }
        } else {
          setError("No active membership found for this account.");
        }
      } catch (err) {
        setError("You must be logged in to view the dashboard.");
      } finally {
        setIsLoading(false);
      }
    };
    loadDashboardData();

    // Cleanup function to remove the added script tags when component unmounts
    return () => {
        document.querySelectorAll('script[data-b44-seo="true"]').forEach(el => el.remove());
    };
  }, [accordionFAQs]);

  const handleUpgradeSuccess = () => {
    setUpgradeMessage("Upgrade successful! Your new plan details will be reflected shortly.");
    // Small delay to allow message to be seen before reload
    setTimeout(() => window.location.reload(), 3000);
  }

  const planColors = {
    bronze: "bg-orange-100 text-orange-800 border-orange-300",
    silver: "bg-slate-100 text-slate-800 border-slate-300",
    gold: "bg-yellow-100 text-yellow-800 border-yellow-300",
  };

  const getPlanBenefits = (planTier) => {
    const baseBenefits = [
      "Unlimited wellness visits",
      "Unlimited concern visits",
      "ADHD visits",
      "Clogged ear irrigation",
      "School/daycare/sports forms"
    ];

    const silverBenefits = [
      ...baseBenefits,
      "Unlimited telemedicine visits",
      "Rapid tests (COVID, Flu, RSV, Strep)",
      "Medical ear piercing (annual only)",
      "Priority scheduling"
    ];

    const goldBenefits = [
      ...silverBenefits,
      "All vaccines included",
      "Newborn circumcision (annual only)",
      "Direct messaging to MD's cell phone",
      "Extended consultation times"
    ];

    const annualBenefits = {
      bronze: "1 sleep consultation, 1 lactation consultation",
      silver: "2 sleep consultations, 2 lactation consultations",
      gold: "3 sleep consultations, 3 lactation consultations"
    };

    switch(planTier) {
      case 'bronze': return { services: baseBenefits, annual: annualBenefits.bronze };
      case 'silver': return { services: silverBenefits, annual: annualBenefits.silver };
      case 'gold': return { services: goldBenefits, annual: annualBenefits.gold };
      default: return { services: baseBenefits, annual: annualBenefits.bronze };
    }
  };

  const planFeatures = {
    silver: {
      name: "Silver",
      subtitle: "Enhanced Care",
      monthlyPrice: 400,
      annualPrice: 3504,
      color: "from-slate-400 to-gray-500",
      features: [
        "Everything in Bronze, plus:",
        "Unlimited telemedicine visits",
        "Rapid tests (Covid, Flu, RSV, Strep)",
        "Medical ear piercing with 1-year re-piercings",
        "Priority scheduling"
      ]
    },
    gold: {
      name: "Gold",
      subtitle: "Premium Care",
      monthlyPrice: 500,
      annualPrice: 4380,
      color: "from-yellow-400 to-amber-500",
      features: [
        "Everything in Silver, plus:",
        "All vaccines included",
        "Newborn circumcision",
        "Direct messaging to MD's cell phone ($105/month value)",
        "Extended consultation times"
      ]
    },
    diamond: {
      name: "Diamond Concierge",
      subtitle: "Ultimate Luxury Care",
      annualPrice: 30000,
      color: "from-purple-600 to-indigo-600",
      features: [
        "Everything in Gold, plus:",
        "24/7 personal pediatric nurse on-call",
        "Priority same-day home visits",
        "Luxury annual pediatric wellness retreat",
        "Private nutritionist consultations",
        "Educational & developmental consultations",
        "Complimentary technology & genetic testing",
        "Free premium health devices (Tyto Kit, Owlet, etc.)"
      ]
    }
  };

  // Dummy navigation and URL creation for demonstration purposes.
  // In a real application, you would use a routing library like react-router-dom.
  const navigate = (url) => {
    console.log("Simulating navigation to:", url);
    window.location.href = url; // For actual navigation in a browser
  };

  const createPageUrl = (pageName) => {
    switch (pageName) {
      case "ConciergeInquiry":
        return "/concierge-inquiry"; // Replace with actual path in your routing setup
      case "Join":
        return "/join"; // Replace with actual path in your routing setup
      case "FAQ":
        return "/faq"; // New case for FAQ page
      default:
        return "/";
    }
  };

  const PlanUpgradeDialog = ({ plan, isAvailable, isDiamond = false }) => {
    const [isOpen, setIsOpen] = useState(false);

    const handleContinue = () => {
      setIsOpen(false);
      if (isDiamond) {
        navigate(createPageUrl("ConciergeInquiry"));
      } else {
        navigate(createPageUrl("Join") + `?plan=${plan.name.toLowerCase()}&billing=${member?.payment_frequency || 'annual'}`);
      }
    };

    return (
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button 
            className={`flex-1 bg-gradient-to-r ${plan.color} text-white hover:opacity-90 transition-opacity`}
            disabled={!isAvailable}
          >
            {isDiamond ? "Get" : "Explore"} {plan.name}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-center">
              <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-gradient-to-r ${plan.color} text-white mb-4`}>
                <Shield className="w-5 h-5" />
                {plan.name} Plan
              </div>
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-center">
              <p className="text-gray-600 mb-2">{plan.subtitle}</p>
              <div className="text-3xl font-bold text-gray-900">
                ${isDiamond ? plan.annualPrice.toLocaleString() : (member?.payment_frequency === 'annual' ? plan.annualPrice : plan.monthlyPrice)}
              </div>
              <div className="text-gray-600">
                {isDiamond ? "per year" : (member?.payment_frequency === 'annual' ? "per year" : "per month")}
              </div>
            </div>
            
            <div className="border-t pt-4">
              <h4 className="font-semibold text-gray-900 mb-3">What's Included:</h4>
              <div className="space-y-2">
                {plan.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-gray-700">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {isDiamond && (
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                <p className="text-sm text-purple-800">
                  <strong>Note:</strong> Diamond Concierge is our exclusive ultra-premium tier with luxury amenities and personalized care.
                </p>
              </div>
            )}
            
            <Button 
              onClick={handleContinue}
              className={`w-full bg-gradient-to-r ${plan.color} text-white hover:opacity-90 py-6 text-lg`}
            >
              Continue to {isDiamond ? "Diamond Concierge Details" : "Payment"}
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    );
  };

  const handleEditProfile = () => {
    setEditedProfile({
      full_name: user.full_name || '',
      email: user.email || '',
      // Add any additional User entity fields here
    });
    setIsEditingProfile(true);
  };

  const handleCancelEdit = () => {
    setIsEditingProfile(false);
    setEditedProfile({});
  };

  const handleSaveProfile = async () => {
    setUpdateLoading(true);
    try {
      await User.updateMyUserData({
        full_name: editedProfile.full_name,
        // Add other editable fields here
      });
      
      // Refresh user data
      const updatedUser = await User.me();
      setUser(updatedUser);
      setIsEditingProfile(false);
      setEditedProfile({});
    } catch (error) {
      setError("Failed to update profile. Please try again.");
      console.error('Profile update error:', error);
    } finally {
      setUpdateLoading(false);
    }
  };

  if (isLoading) {
    return <DashboardSkeleton />;
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="mb-4 text-6xl">
              <AlertCircle className="w-16 h-16 text-red-600 mx-auto" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">Access Error</h2>
            <p className="text-gray-600 mb-4">{error}</p>
            <Button onClick={() => window.location.reload()}>Try Again</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const benefits = getPlanBenefits(member?.plan_tier);
  const currentPlanIndex = member ? planOrder.indexOf(member.plan_tier) : -1;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Welcome back, {user?.full_name?.split(' ')[0] || 'Member'}! 👋</h1>
          <p className="text-gray-600 mt-2">Manage your membership and access your pediatric care resources.</p>
        </div>

        {member?.status === 'pending' && (
          <Alert className="mb-8 bg-yellow-50 border-yellow-200 text-yellow-800">
            <AlertCircle className="h-4 w-4" />
            <div className="ml-3">
              <p className="font-bold">Your Account is Pending Activation</p>
              <p className="text-sm">
                Your membership is not yet active. Please ensure you have completed all payment steps and wait for a verification call from our team. Full access will be granted upon activation.
              </p>
              <div className="mt-3 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 font-semibold text-sm">
                  🚨 IMPORTANT: This membership portal is NOT HIPAA compliant. Please do not share any protected health information (PHI) here. Use our secure patient portal for medical records and communications.
                </p>
              </div>
            </div>
          </Alert>
        )}

        {member?.status === 'active' && (
          <Alert className="mb-8 bg-teal-50 border-teal-200 text-teal-800">
            <AlertCircle className="h-4 w-4" />
            <div className="ml-3">
              <p className="font-bold">Privacy Notice</p>
              <p className="text-sm">
                This membership portal is NOT HIPAA compliant. Please do not share any protected health information (PHI) here. Use our secure patient portal for medical records and communications.
              </p>
            </div>
          </Alert>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Section */}
          <div className="lg:col-span-1">
            <Card className="shadow-lg">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-xl font-bold flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-blue-600" />
                  My Profile
                </CardTitle>
                {!isEditingProfile && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleEditProfile}
                    className="flex items-center gap-2"
                  >
                    <Edit3 className="w-4 h-4" />
                    Edit
                  </Button>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                {isEditingProfile ? (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="full_name">Full Name</Label>
                      <Input
                        id="full_name"
                        value={editedProfile.full_name}
                        onChange={(e) => setEditedProfile({
                          ...editedProfile,
                          full_name: e.target.value
                        })}
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email Address</Label>
                      <Input
                        id="email"
                        type="email"
                        value={editedProfile.email}
                        disabled
                        className="bg-gray-50 text-gray-500"
                        title="Email cannot be changed"
                      />
                      <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        onClick={handleSaveProfile}
                        disabled={updateLoading}
                        className="flex-1 flex items-center gap-2"
                      >
                        {updateLoading ? (
                          <>
                            <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="w-4 h-4" />
                            Save
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={handleCancelEdit}
                        disabled={updateLoading}
                        className="flex items-center gap-2"
                      >
                        <X className="w-4 h-4" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-gray-600">Full Name</p>
                      <p className="font-semibold text-gray-900">{user?.full_name || 'Not provided'}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Email</p>
                      <p className="font-semibold text-gray-900">{user?.email}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600">Account Type</p>
                      <Badge variant="outline" className="mt-1">
                        {user?.role === 'admin' ? 'Administrator' : 'Member'}
                      </Badge>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Membership Info */}
          <div className="lg:col-span-2">
            {member ? (
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl font-bold flex items-center gap-2">
                    <Shield className="w-5 h-5 text-teal-600" />
                    Your Membership
                    <Badge className={`ml-auto ${
                      member.status === 'active' ? 'bg-green-100 text-green-800' :
                      member.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-gray-100 text-gray-800'
                    }`}>
                      {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6"> {/* Added space-y-6 for consistent spacing */}
                  {/* Membership Details */}
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <Shield className="w-8 h-8 text-teal-600" />
                      <div>
                        <p className="text-sm text-gray-500">Membership Status</p>
                        <p className="font-semibold text-green-600 capitalize">{member.status}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <Calendar className="w-8 h-8 text-teal-600" />
                      <div>
                        <p className="text-sm text-gray-500">Next Renewal Date</p>
                        <p className="font-semibold">{format(new Date(member.renewal_date), "MMMM d, yyyy")}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <Users className="w-8 h-8 text-teal-600" />
                      <div>
                        <p className="text-sm text-gray-500">Children Covered</p>
                        <p className="font-semibold">{member.children_count}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                      <CreditCard className="w-8 h-8 text-purple-600" />
                      <div>
                        <p className="text-sm text-gray-500">Payment Frequency</p>
                        <p className="font-semibold capitalize">{member.payment_frequency}</p>
                      </div>
                    </div>
                  </div>

                  {/* Manage Subscription Card */}
                  <div className="border-t pt-6"> {/* mimic Card structure */}
                    <h3 className="text-xl font-bold mb-4">Manage Subscription</h3> {/* mimic CardTitle */}
                    <div className="space-y-6">
                      {upgradeMessage && (
                        <Alert className="bg-green-50 border-green-200 text-green-800 flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 flex-shrink-0"/>
                            {upgradeMessage}
                        </Alert>
                      )}

                      {member.stripe_subscription_id ? (
                        <>
                          {/* Current upgrade buttons for immediate processing */}
                          <div>
                            <p className="text-gray-600 mb-4">You can upgrade your plan at any time. Downgrades are only available at the end of your billing cycle.</p>
                            <div className="flex flex-col md:flex-row gap-4">
                              {currentPlanIndex < 1 && (
                                <UpgradeButton
                                    currentPlan={member.plan_tier}
                                    targetPlan="silver"
                                    paymentFrequency={member.payment_frequency}
                                    subscriptionId={member.stripe_subscription_id}
                                    onUpgrade={handleUpgradeSuccess}
                                />
                              )}
                              {currentPlanIndex < 2 && (
                                <UpgradeButton
                                    currentPlan={member.plan_tier}
                                    targetPlan="gold"
                                    paymentFrequency={member.payment_frequency}
                                    subscriptionId={member.stripe_subscription_id}
                                    onUpgrade={handleUpgradeSuccess}
                                />
                              )}
                            </div>
                            {currentPlanIndex === 2 && (
                                <div className="p-4 bg-yellow-50 rounded-lg text-center text-yellow-800 font-semibold">
                                    You are on our highest plan!
                                </div>
                              )}
                          </div>
                        </>
                      ) : (
                        <Alert variant="default" className="bg-teal-50 border-teal-200 text-teal-800">
                          <AlertCircle className="h-4 w-4" />
                          <div className="ml-3">
                            <p className="font-bold">Subscription Management Not Available</p>
                            <p className="text-sm">
                              This feature is only available for accounts with a subscription managed through Stripe. If you paid via another method or your payment is still processing, this section will become active once Stripe confirms your subscription.
                            </p>
                          </div>
                        </Alert>
                      )}

                      {/* Plan Comparison Section - Always Visible */}
                      <div className="border-t pt-6">
                        <h3 className="text-lg font-semibold text-gray-900 mb-4">Explore Plan Options</h3>
                        <p className="text-gray-600 mb-4">Compare features and upgrade to a plan that better fits your family's needs.</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                          {currentPlanIndex < 1 && (
                            <PlanUpgradeDialog 
                              plan={planFeatures.silver}
                              isAvailable={true}
                            />
                          )}
                          {currentPlanIndex < 2 && (
                            <PlanUpgradeDialog 
                              plan={planFeatures.gold}
                              isAvailable={true}
                            />
                          )}
                          <PlanUpgradeDialog 
                            plan={planFeatures.diamond}
                            isAvailable={true}
                            isDiamond={true}
                          />
                        </div>
                        
                        <div className="mt-4 p-3 bg-teal-50 border border-teal-200 rounded-lg">
                          <p className="text-sm text-teal-800">
                            {member.stripe_subscription_id ? (
                              <><strong>Quick Upgrade:</strong> Use the buttons above for immediate plan changes, or explore detailed comparisons with the "Explore Plan Options" buttons.</>
                            ) : (
                              <><strong>Upgrade Options:</strong> Explore our available plans and their features. Contact us to discuss upgrade options for your current membership.</>
                            )}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Payment Information */}
                  <div className="border-t pt-6"> {/* mimic Card structure */}
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2"> {/* mimic CardTitle */}
                      <DollarSign className="w-6 h-6 text-green-600" />
                      Payment Information
                    </h3>
                    <div className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="p-4 bg-green-50 rounded-lg">
                          <p className="text-sm text-gray-500">
                            {member.payment_frequency === 'annual' ? 'Annual Amount' : 'Monthly Amount'}
                          </p>
                          <p className="text-2xl font-bold text-green-600">
                            ${member.payment_frequency === 'annual' ? member.annual_amount : member.monthly_amount}
                          </p>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <p className="text-sm text-gray-500">Payment Method</p>
                          <p className="font-semibold text-blue-600 capitalize">
                            {member.payment_method.replace('_', ' ')}
                          </p>
                        </div>
                      </div>
                      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <p className="text-sm text-yellow-800">
                          <strong>Next Payment Due:</strong> {format(new Date(member.renewal_date), "MMMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Plan Benefits */}
                  <div className="border-t pt-6"> {/* mimic Card structure */}
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2"> {/* mimic CardTitle */}
                      <CheckCircle className="w-6 h-6 text-green-600" />
                      Your Plan Benefits
                    </h3>
                    <div className="space-y-6">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Included Services</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                          {benefits.services.map((service, index) => (
                            <div key={index} className="flex items-center gap-2">
                              <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                              <span className="text-sm text-gray-700">{service}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      {member.payment_frequency === 'annual' && (
                        <div className="p-4 bg-purple-50 border border-purple-200 rounded-lg">
                          <h4 className="font-semibold text-purple-800 mb-2">Annual Plan Bonus</h4>
                          <p className="text-sm text-purple-700">{benefits.annual}</p>
                        </div>
                      )}
                    </div>
                  </div>

                </CardContent>
              </Card>
            ) : (
              <Card className="shadow-lg">
                <CardContent className="p-8 text-center">
                  <div className="mb-4">
                    <Heart className="w-16 h-16 text-gray-300 mx-auto" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">No Active Membership</h3>
                  <p className="text-gray-600 mb-6">Join Omega Pediatrics today to access premium pediatric care for your family.</p>
                  <Button asChild className="bg-teal-600 hover:bg-teal-700">
                    <a href={createPageUrl("Join")}>Join Now</a>
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Community Access & Quick Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
          {/* Community Access */}
          <Card className="shadow-xl border-0 bg-gradient-to-br from-teal-50 to-cyan-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Heart className="w-6 h-6 text-red-500" />
                Member Community
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600 text-sm">
                Connect with other Omega Pediatrics families in our exclusive member communities.
              </p>

              <Button asChild className="w-full bg-teal-600 hover:bg-teal-700">
                <a
                  href="https://www.facebook.com/groups/omegapediatricsmembers"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <Facebook className="w-4 h-4" />
                  Join Private Facebook Group
                  <ExternalLink className="w-4 h-4" />
                </a>
              </Button>

              <Button asChild variant="outline" className="w-full">
                <a
                  href="https://chat.whatsapp.com/omegapediatricsmembers"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <MessageCircle className="w-4 h-4" />
                  Join WhatsApp Group
                  <ExternalLink className="w-4 h-4" />
                </a>
              </Button>

              <div className="p-3 bg-white rounded-lg border">
                <p className="text-xs text-gray-500 mb-2">Access includes:</p>
                <ul className="text-xs text-gray-600 space-y-1">
                  <li>• Parenting tips and support</li>
                  <li>• Exclusive events and masterclasses</li>
                  <li>• Direct updates from our team</li>
                  <li>• Member-only resources</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Quick Links */}
          <Card className="shadow-xl border-0">
            <CardHeader>
              <CardTitle>Quick Links</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button asChild variant="outline" className="w-full justify-start">
                <a href="https://www.omegapediatrics.com/book-appointment/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                  <Calendar className="w-4 h-4" />
                  Book Appointment
                  <ExternalLink className="w-4 h-4 ml-auto" />
                </a>
              </Button>

              <Button asChild variant="outline" className="w-full justify-start">
                <a href="https://portal.kareo.com/pp-webapp/app/new/login" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  Patient Portal
                  <ExternalLink className="w-4 h-4 ml-auto" />
                </a>
              </Button>

              <Button asChild variant="outline" className="w-full justify-start">
                <a href="tel:470-485-6342" className="flex items-center gap-2">
                  <Heart className="w-4 h-4" />
                  Call Us: 470-485-6342
                </a>
              </Button>

              <Button asChild variant="outline" className="w-full justify-start">
                <a href="mailto:info@omegapediatrics.com" className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  Email Us
                </a>
              </Button>
              
              {user?.is_admin && (
                <>
                  <hr className="my-2 border-t border-gray-200" />
                  <Button asChild variant="outline" className="w-full justify-start bg-teal-50 hover:bg-teal-100">
                    <a href="https://admin.omegapediatrics.com/sign-in" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-teal-600" />
                      Admin Sign-In
                      <ExternalLink className="w-4 h-4 ml-auto" />
                    </a>
                  </Button>
                  <Button asChild variant="outline" className="w-full justify-start bg-teal-50 hover:bg-teal-100">
                    <a href="https://admin.omegapediatrics.com" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-teal-600" />
                      Admin Panel
                      <ExternalLink className="w-4 h-4 ml-auto" />
                    </a>
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
       {/* FAQ Section */}
       <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-gradient-to-r from-teal-50 to-cyan-50 rounded-3xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">Member Support</h2>
          <Accordion type="single" collapsible className="max-w-4xl mx-auto">
            {accordionFAQs && accordionFAQs.map((faq, index) => ( // Added null/undefined check for accordionFAQs
              <AccordionItem key={index} value={`dashboard-faq-${index}`}>
                <AccordionTrigger className="text-left text-lg font-semibold text-gray-800 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <div className="text-center mt-8">
            <Button asChild className="bg-teal-600 hover:bg-teal-700 text-white">
              <a href={createPageUrl("FAQ")}>
                See More FAQs
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
