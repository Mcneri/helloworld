
import React, { useState, useEffect, lazy, Suspense, useMemo } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Heart,
  Stethoscope,
  Shield,
  Phone,
  Pill,
  CheckCircle,
  XCircle,
  ArrowRight,
  Info
} from "lucide-react";
import { Service } from "@/api/entities";
import { faqsByPage } from "../components/ExpandableFAQSection";
import PrefetchLink from "../components/PrefetchLink";
import ServiceCard from "../components/services/ServiceCard";

// Lazy load sections
const ServicesCtaSection = lazy(() => import("../components/services/ServicesCtaSection"));

// PageSkeleton for Suspense fallback
const PageSkeleton = () => (
    <div className="min-h-screen p-8 bg-gray-100 animate-pulse">
        <div className="h-24 bg-gray-300 rounded-lg mb-8"></div> {/* Header skeleton */}
        <div className="h-20 bg-gray-200 rounded-lg mb-8 mx-auto w-3/4"></div> {/* Concierge section skeleton */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-white rounded-lg shadow-md p-6 h-64">
                    <div className="h-6 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-5/6 mb-4"></div>
                    <div className="h-16 bg-gray-200 rounded w-full"></div>
                </div>
            ))}
        </div>
        <div className="h-32 bg-gray-300 rounded-lg mt-8"></div> {/* CTA skeleton */}
    </div>
);

export default function Services() {
  const [services, setServices] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // SEO and Metadata Setup
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());

    const title = "Concierge Pediatrics Services | Unlimited Visits & DPC Care Atlanta";
    const description = "Discover unlimited wellness visits, telemedicine, vaccines & more. Premium concierge pediatrics services across Bronze, Silver & Gold DPC plans in Atlanta.";
    // PERF: OPTIMIZED: Use responsive image URL for meta tags with WebP
    const imageUrl = "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=60&fm=webp&w=800";

    document.title = title;

    const createMetaTag = (attrs) => {
        const el = document.createElement('meta');
        Object.keys(attrs).forEach(attr => el.setAttribute(attr, attrs[attr]));
        el.setAttribute('data-b44-seo', 'true');
        document.head.appendChild(el);
    };

    createMetaTag({ name: 'description', content: description });
    createMetaTag({ property: 'og:title', content: title });
    createMetaTag({ property: 'og:description', content: description });
    createMetaTag({ property: 'og:image', content: imageUrl });
    createMetaTag({ property: 'og:url', content: window.location.href });
    createMetaTag({ property: 'og:type', content: 'WebPage' });

    // Twitter Card
    createMetaTag({ name: 'twitter:card', content: 'summary_large_image' });
    createMetaTag({ name: 'twitter:title', content: title });
    createMetaTag({ name: 'twitter:description', content: description });
    createMetaTag({ name: 'twitter:image', content: imageUrl });

    // Helper function to safely extract text from FAQ answers
    const extractTextFromAnswer = (answer) => {
      if (typeof answer === 'string') {
        return answer.replace(/<[^>]*>?/gm, '');
      } else if (React.isValidElement(answer) || typeof answer === 'object') {
        // For JSX/React elements, return a generic description
        return "Please visit our website for detailed information about this topic.";
      } else {
        return String(answer).replace(/<[^>]*>?/gm, '');
      }
    };

    // Define common entities for @graph schema
    const fullProviderDetails = {
        "@type": "MedicalBusiness",
        "@id": window.location.href + "#medicalbusiness", // Unique ID for referencing
        "name": "Omega Pediatrics",
        "image": imageUrl,
        "telephone": "+1-470-485-6342",
        "url": "https://members.omegapediatrics.com/",
        "priceRange": "$250-$500",
        "address": [
            {"@type": "PostalAddress", "streetAddress": "1305 Hembree Road STE 203", "addressLocality": "Roswell", "addressRegion": "GA", "postalCode": "30076", "addressCountry": "US"},
            {"@type": "PostalAddress", "streetAddress": "1841 Piedmont Road NE, STE 100", "addressLocality": "Marietta", "addressRegion": "GA", "postalCode": "30066", "addressCountry": "US"},
            {"@type": "PostalAddress", "streetAddress": "65742 River Park Drive", "addressLocality": "Riverdale", "addressRegion": "GA", "postalCode": "30274", "addressCountry": "US"}
        ],
        "areaServed": ["Atlanta", "Roswell", "Sandy Springs", "Alpharetta", "Buckhead", "East Cobb", "Kennesaw", "Cumming"]
    };

    const organizationPublisher = {
        "@type": "Organization",
        "@id": window.location.origin + "/#organization", // Unique ID for referencing
        "name": "Omega Pediatrics",
        "url": window.location.origin,
        "logo": {
            "@type": "ImageObject",
            "url": "https://res.cloudinary.com/dt3tp2v52/image/upload/v1709244084/OmegaPediatricsLogo_w5fj5p.png" // Example logo URL
        },
        "sameAs": [
            "https://www.facebook.com/omegapediatrics",
            "https://twitter.com/omegapediatrics",
            "https://www.instagram.com/omegapediatrics"
        ]
    };

    const loadPageData = async () => {
      setIsLoading(true);
      try {
        const fetchedServices = await Service.list();
        setServices(fetchedServices);

        // Prepare services for ItemList schema
        const servicesItemListElements = fetchedServices.map((service, index) => {
            const additionalProps = [];
            if (service.bronze_included) additionalProps.push({ "@type": "PropertyValue", "name": "Included in Bronze Plan", "value": "Yes" });
            if (service.silver_included) additionalProps.push({ "@type": "PropertyValue", "name": "Included in Silver Plan", "value": "Yes" });
            if (service.gold_included) additionalProps.push({ "@type": "PropertyValue", "name": "Included in Gold Plan", "value": "Yes" });
            if (service.annual_only) additionalProps.push({ "@type": "PropertyValue", "name": "Requires Annual Membership", "value": "Yes" });

            return {
                "@type": "ListItem",
                "position": index + 1,
                "item": {
                    "@type": "Service",
                    "name": service.name,
                    "description": service.description,
                    "provider": { "@id": fullProviderDetails["@id"] }, // Reference the MedicalBusiness defined above
                    "category": service.category,
                    "offers": {
                        "@type": "Offer",
                        "price": service.regular_price > 0 ? service.regular_price.toString() : "0",
                        "priceCurrency": "USD",
                        "additionalProperty": additionalProps
                    }
                }
            };
        });

        // Prepare FAQs for FAQPage schema
        const servicesFAQs = faqsByPage.Services || [];
        const faqMainEntity = Array.isArray(servicesFAQs) && servicesFAQs.length > 0 ? {
            "@type": "FAQPage",
            "mainEntity": servicesFAQs.map(faq => ({
                "@type": "Question",
                "name": faq.question,
                "acceptedAnswer": {
                    "@type": "Answer",
                    "text": extractTextFromAnswer(faq.answer)
                }
            }))
        } : null;

        const graphEntities = [
            fullProviderDetails, // MedicalBusiness entity
            organizationPublisher, // Organization entity for publisher
            {
                "@type": "WebPage",
                "url": window.location.href,
                "name": title,
                "description": description,
                "hasPart": [
                    {
                        "@type": "Article",
                        "headline": "What Exactly is a Concierge Doctor? Unpacking the Model",
                        "author": { "@id": fullProviderDetails["@id"] }, // Author is the medical business
                        "publisher": { "@id": organizationPublisher["@id"] }, // Publisher is the organization
                        "mainEntityOfPage": { "@id": createPageUrl("BlogWhatIsConciergeDoctor") }
                    }
                ]
            },
            {
                "@type": "ItemList",
                "name": "Omega Pediatrics Services List",
                "description": "Comprehensive list of services available through Omega Pediatrics' DPC and concierge membership plans.",
                "itemListElement": servicesItemListElements
            }
        ];

        if (faqMainEntity) {
            graphEntities.push(faqMainEntity);
        }

        const schema = {
            "@context": "https://schema.org",
            "@graph": graphEntities
        };

        const schemaScript = document.createElement('script');
        schemaScript.type = 'application/ld+json';
        schemaScript.innerHTML = JSON.stringify(schema);
        schemaScript.setAttribute('data-b44-seo', 'true');
        document.head.appendChild(schemaScript);

      } catch (error) {
        console.error('Failed to load page data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadPageData();

    return () => {
      document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());
    };
  }, []);

  // PERF: Memoized grouping function to prevent recreation
  const groupServicesByCategory = useMemo(() => (services) => {
    return services.reduce((acc, service) => {
      const { category } = service;
      if (!acc[category]) {
        acc[category] = [];
      }
      acc[category].push(service);
      return acc;
    }, {});
  }, []);

  // Loading skeleton component for services section
  const ServiceSkeleton = () => (
    <div className="space-y-8 animate-pulse">
      {[1, 2, 3].map((category) => (
        <div key={category}>
          <div className="bg-gray-200 h-8 w-48 mx-auto mb-6 rounded-md"></div> {/* Skeleton for category title */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((item) => (
              <div key={item} className="bg-white rounded-lg shadow-lg p-6">
                <div className="bg-gray-200 h-6 w-3/4 mb-3 rounded-md"></div> {/* Skeleton for service name */}
                <div className="bg-gray-200 h-4 w-full mb-2 rounded-md"></div> {/* Skeleton for description line 1 */}
                <div className="bg-gray-200 h-4 w-2/3 mb-4 rounded-md"></div> {/* Skeleton for description line 2 */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="bg-gray-200 h-4 w-24 rounded-md"></div>
                    <div className="bg-gray-200 h-5 w-5 rounded-full"></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="bg-gray-200 h-4 w-24 rounded-md"></div>
                    <div className="bg-gray-200 h-5 w-5 rounded-full"></div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="bg-gray-200 h-4 w-24 rounded-md"></div>
                    <div className="bg-gray-200 h-5 w-5 rounded-full"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );

  // PERF: Memoize the grouped services to prevent re-calculation on every render.
  // This calculation will only run again if the `services` array changes.
  const groupedServices = useMemo(() => groupServicesByCategory(services), [services, groupServicesByCategory]);
  const categories = Object.keys(groupedServices);

  return (
    <React.Suspense fallback={<PageSkeleton />}>
      <div className="bg-gradient-to-b from-teal-50 to-white">
        {/* Header - Enhanced with optimized background image */}
        <section className="relative bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white overflow-hidden">
          {/* PERF: Using CSS gradients instead of large background images for better performance */}
          <div className="absolute inset-0">
            <div className="absolute top-8 left-16 w-16 h-16 bg-blue-300/20 rounded-full animate-bounce"></div>
            <div className="absolute bottom-16 right-1/4 w-20 h-20 bg-indigo-300/20 rounded-full animate-pulse delay-500"></div>
          </div>
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div className="text-center">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-full mb-4 animate-pulse">
                  <Stethoscope className="w-10 h-10 text-blue-200" />
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in-up">
                Our Pediatric <Link to={createPageUrl("Services")} className="text-blue-300 hover:underline">Services</Link>
              </h1>
              <p className="text-xl text-blue-100 max-w-3xl mx-auto animate-fade-in-up animation-delay-200">
                Comprehensive <Link to={createPageUrl("Plans")} className="text-blue-200 hover:underline">DPC and concierge services</Link> designed to keep your child healthy and provide you with peace of mind.
              </p>
            </div>
          </div>
        </section>

        {/* Understanding Concierge Care Section */}
        <section className="bg-white py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">
              Understanding Our <Link to={createPageUrl("BlogWhatIsConciergeDoctor")} className="text-link">Concierge Care</Link> Model
            </h2>
            <p className="text-lg text-gray-600 mb-4">
              Wondering "<strong>what is a concierge doctor</strong>?" It's a healthcare model built around you. A <strong>concierge doctor</strong> offers personalized, membership-based care with enhanced access, direct communication, and unhurried appointments.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              This approach allows us to provide proactive, comprehensive healthcare focused on a deep doctor-patient relationship. If you're looking for <strong>concierge medicine doctors near me</strong> who prioritize your family's well-being, you're in the right place.
            </p>
            <PrefetchLink to={createPageUrl("BlogWhatIsConciergeDoctor")} prefetchOn="viewport">
              <Button size="lg" variant="outline" className="btn-enhanced border-gray-300 hover:bg-teal-50 hover:border-teal-300">
                Learn More About Our Approach
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </PrefetchLink>
          </div>
        </section>

        {/* Main Content */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">What's Included in Your <Link to={createPageUrl("Plans")} className="text-link">Membership</Link>?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto animate-fade-in animation-delay-200">
              Explore the extensive range of <Link to={createPageUrl("Services")} className="text-link">services available across our Bronze, Silver, and Gold DPC plans</Link>.
            </p>
          </div>

          {isLoading ? (
            <ServiceSkeleton />
          ) : (
            categories.map((category, categoryIndex) => (
              <div key={category} className="mb-12">
                <h3 className={`text-2xl font-bold text-gray-900 mb-6 capitalize text-center border-b-2 border-indigo-200 pb-2 animate-fade-in animation-delay-${categoryIndex * 100}`}>
                  {category} Services
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {groupedServices[category].map((service) => (
                    <ServiceCard key={service.id} service={service} />
                  ))}
                </div>
              </div>
            ))
          )}

          <Suspense fallback={<div className="h-64 mt-16" />}>
            <ServicesCtaSection />
          </Suspense>
        </section>
      </div>
    </React.Suspense>
  );
}
