
import React, { useState, useEffect, lazy, Suspense } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ForumPost } from "@/api/entities";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge"; // Added
import {
  MessageSquare,
  Plus,
  Clock, // Added
  User as UserIcon,
  Loader2,
  Edit3 // Added
} from "lucide-react";
import { format } from "date-fns";

// Lazy load the post creation dialog since it's not immediately needed
const CreatePostDialog = lazy(() => import("../components/CreatePostDialog"));

export default function Forum() {
  const [posts, setPosts] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  // Function to load/refresh posts
  const loadPosts = async () => {
    try {
      const postData = await ForumPost.list('-created_date');
      setPosts(postData);
    } catch (error) {
      console.error("Error fetching posts:", error);
      // Optionally handle error, e.g., show a toast notification
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const user = await User.me();
        setCurrentUser(user);
        await loadPosts(); // Load posts after user is fetched
      } catch (error) {
        console.error("Error fetching data:", error);
        // If user fetching fails or posts fetching fails, navigate to Home
        navigate(createPageUrl("Home"));
      } finally {
        setIsLoading(false);
      }
    };
    fetchData();
  }, [navigate]);

  if (isLoading) {
    return <div className="flex justify-center items-center h-screen"><Loader2 className="w-12 h-12 animate-spin text-blue-600" /></div>;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50">
      {/* Enhanced Header */}
      <section className="relative bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 text-white overflow-hidden">
        {/* Animated background elements - variation 3 */}
        <div className="absolute inset-0">
          <div className="absolute top-16 left-1/3 w-10 h-10 bg-fuchsia-300/20 rounded-full animate-pulse delay-200"></div>
          <div className="absolute top-1/2 right-1/4 w-14 h-14 bg-violet-300/20 rounded-full animate-bounce"></div>
          <div className="absolute bottom-8 left-10 w-24 h-24 bg-cyan-300/20 rounded-full animate-pulse"></div>
          <div className="absolute bottom-20 right-10 w-12 h-12 bg-teal-300/20 rounded-full animate-bounce delay-300"></div>
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <div className="mb-6">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-full mb-4 animate-pulse">
                <MessageSquare className="w-10 h-10 text-fuchsia-200" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Community <span className="text-fuchsia-200">Forum</span>
            </h1>
            <p className="text-xl text-indigo-100 max-w-3xl mx-auto">
              Connect with other members, share experiences, and get advice.
            </p>
            {/* Sparkle effect */}
            <div className="mt-6 flex justify-center">
              <div className="flex space-x-2">
                <div className="w-2 h-2 bg-fuchsia-300 rounded-full animate-ping"></div>
                <div className="w-2 h-2 bg-violet-300 rounded-full animate-ping delay-100"></div>
                <div className="w-2 h-2 bg-cyan-300 rounded-full animate-ping delay-200"></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <div className="p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          {currentUser && ( // Only show Create Post button if user is logged in
            <div className="text-right mb-8">
              <Suspense fallback={
                <Button disabled className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Loading...
                </Button>
              }>
                {/* CreatePostDialog handles its own button/trigger */}
                <CreatePostDialog user={currentUser} onPostCreated={loadPosts} />
              </Suspense>
            </div>
          )}

          <div className="space-y-6">
            {posts.map(post => (
              <Link key={post.id} to={createPageUrl(`PostDetails?id=${post.id}`)} className="block">
                <Card className="hover:shadow-xl hover:border-blue-300 transition-all duration-300">
                  <CardHeader>
                    <CardTitle className="text-xl text-gray-900 hover:text-blue-700">{post.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-gray-500 flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <UserIcon className="w-4 h-4" />
                      <span>{post.author_name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      <span>{format(new Date(post.created_date), 'MMM d, yyyy')}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
            {posts.length === 0 && ( // Removed !showForm condition as showForm no longer exists
              <div className="text-center py-12">
                <MessageSquare className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-800">No posts yet.</h3>
                <p className="text-gray-500">Be the first to start a conversation!</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
