import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Baby, AlertTriangle } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-[calc(100vh-300px)] flex flex-col items-center justify-center text-center p-4 bg-gradient-to-br from-yellow-50 via-white to-red-50">
      <div className="bg-white/80 backdrop-blur-sm p-8 md:p-12 rounded-2xl shadow-2xl border border-gray-200">
        <div className="w-24 h-24 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
          <AlertTriangle className="w-12 h-12 text-red-500" />
        </div>
        <h1 className="text-6xl md:text-8xl font-bold text-red-500">404</h1>
        <h2 className="text-2xl md:text-3xl font-semibold text-gray-800 mt-4">Oops! The bath water has left the baby.</h2>
        <p className="text-gray-600 mt-4 max-w-md mx-auto">
          It looks like the page you're searching for has gone missing. Don't worry, we can help you find your way back.
        </p>
        <div className="mt-8">
          <Link to={createPageUrl("Home")}>
            <Button size="lg" className="bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300">
              <Baby className="w-5 h-5 mr-2" />
              Return to Safe Waters (Home)
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}