
import React, { useState, useEffect, Suspense } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Heart,
  Shield,
  Clock,
  Users,
  ArrowRight,
  Users2
} from "lucide-react";
import SectionSkeleton from "../components/ui/SectionSkeleton";
import PrefetchLink from "../components/PrefetchLink";

// Lazy load ALL sections except the hero - this reduces initial bundle size significantly
const PricingPreviewSection = React.lazy(() => import("../components/home/PricingPreviewSection"));
const TestimonialsSection = React.lazy(() => import("../components/home/TestimonialsSection"));
const ExpandableFAQSection = React.lazy(() => import("../components/ExpandableFAQSection"));
const CtaSection = React.lazy(() => import("../components/home/CtaSection"));

// PERFORMANCE: Moved static `benefits` array outside the component function.
// This prevents it from being recreated on every single render of the Home component.
const benefits = [
  {
    icon: Heart,
    title: "Unlimited Wellness Visits",
    description: <>Regular check-ups and preventive care without limits for families across <Link to={createPageUrl("Services")} className="text-link">Atlanta</Link></>
  },
  {
    icon: Shield,
    title: "Comprehensive DPC Coverage",
    description: <>From basic care to premium <Link to={createPageUrl("Services")} className="text-link">concierge pediatrics services</Link> across all plans</>
  },
  {
    icon: Clock,
    title: "Priority Scheduling",
    description: <>Get appointments when you need them most with Atlanta's <Link to={createPageUrl("Services")} className="text-link">best pediatrics concierge service</Link></>
  },
  {
    icon: Users,
    title: "Family-Focused Care",
    description: <><Link to={createPageUrl("Plans")} className="text-link">Direct pay membership pediatrics</Link> designed specifically for busy families in Roswell, Alpharetta, and beyond</>
  }
];

export default function Home() {
  const [faqsByPage, setFaqsByPage] = useState({});

  useEffect(() => {
    // PERF: This function contains all non-critical setup (SEO, schemas)
    // and will be deferred until the browser is idle.
    const deferredOperations = () => {
      // Remove any existing data-b44-seo elements to prevent duplicates
      document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());

      const preconnectUnsplash = document.createElement('link');
      preconnectUnsplash.rel = 'preconnect';
      preconnectUnsplash.href = 'https://images.unsplash.com';
      preconnectUnsplash.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(preconnectUnsplash);

      const preconnectSupabase = document.createElement('link');
      preconnectSupabase.rel = 'preconnect';
      preconnectSupabase.href = 'https://qtrypzzcjebvfcihiynt.supabase.co';
      preconnectSupabase.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(preconnectSupabase);

      // PERF: Optimized: Preload critical hero image with WebP and proper dimensions
      const preloadLink = document.createElement('link');
      preloadLink.rel = 'preload';
      preloadLink.href = 'https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=800';
      preloadLink.as = 'image';
      preloadLink.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(preloadLink);
      
      const title = "Best Concierge Pediatrician & DPC | Atlanta, East Cobb, Alpharetta, Milton, GA";
      const description = "Omega Pediatrics offers premier direct primary care for children in Atlanta. Experience top-tier membership pediatrics in East Cobb, Alpharetta, Milton, and surrounding areas with unlimited visits and personalized care.";
      const imageUrl = "https://images.unsplash.com/photo-1609220136736-443140cffec6?w=600&h=400&auto=format&fit=crop&q=75&ixlib=rb-4.0.3";
      
      document.title = title;

      const createMetaTag = (attrs) => {
          const el = document.createElement('meta');
          Object.keys(attrs).forEach(attr => el.setAttribute(attr, attrs[attr]));
          el.setAttribute('data-b44-seo', 'true');
          document.head.appendChild(el);
      };

      // All meta tags run directly inside the deferredOperations function
      createMetaTag({ name: 'description', content: description });
      createMetaTag({ property: 'og:title', content: title });
      createMetaTag({ property: 'og:description', content: description });
      createMetaTag({ property: 'og:image', content: imageUrl });
      createMetaTag({ property: 'og:url', content: window.location.href });
      createMetaTag({ property: 'og:type', content: 'website' });
      createMetaTag({ name: 'twitter:image', content: imageUrl });
      createMetaTag({ name: "msvalidate.01", content: "0988113E58BF840499B609011297E019" });
      createMetaTag({ name: 'twitter:card', content: 'summary_large_image' });
      createMetaTag({ name: 'twitter:title', content: title });
      createMetaTag({ name: 'twitter:description', content: description });
      createMetaTag({ name: 'twitter:image', content: imageUrl });

      const schema = {
        "@context": "https://schema.org",
        "@graph": [
            {
                "@type": "Organization",
                "name": "Omega Pediatrics",
                "url": window.location.origin,
                "logo": "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=96&h=64&fit=crop&auto=format&q=85",
                "@id": window.location.origin + "/#organization"
            },
            {
                "@type": "LocalBusiness",
                "name": "Omega Pediatrics",
                "description": "Atlanta's premier concierge pediatric practice offering direct pay membership pediatrics (DPC pediatrics).",
                "image": imageUrl,
                "url": window.location.href,
                "telephone": "+1-470-485-6342",
                "priceRange": "$250-$500",
                "keywords": "concierge pediatrician, DPC pediatrics, membership pediatrics, direct primary care, Atlanta, East Cobb, Alpharetta, Milton, Roswell, Sandy Springs, Buckhead, best concierge pediatrician",
                "address": [
                    {"@type": "PostalAddress", "streetAddress": "1305 Hembree Road STE 203", "addressLocality": "Roswell", "addressRegion": "GA", "postalCode": "30076", "addressCountry": "US"},
                    {"@type": "PostalAddress", "streetAddress": "1841 Piedmont Road NE, STE 100", "addressLocality": "Marietta", "addressRegion": "GA", "postalCode": "30066", "addressCountry": "US"},
                    {"@type": "PostalAddress", "streetAddress": "65742 River Park Drive", "addressLocality": "Riverdale", "addressRegion": "GA", "postalCode": "30274", "addressCountry": "US"}
                ],
                "areaServed": [
                    {"@type": "City", "name": "Atlanta"},
                    {"@type": "City", "name": "Sandy Springs"},
                    {"@type": "City", "name": "East Cobb"},
                    {"@type": "City", "name": "Buckhead"},
                    {"@type": "City", "name": "Roswell"},
                    {"@type": "City", "name": "Alpharetta"},
                    {"@type": "City", "name": "Kennesaw"},
                    {"@type": "City", "name": "Cumming"},
                    {"@type": "City", "name": "Marietta"},
                    {"@type": "City", "name": "Riverdale"}
                ],
                "openingHoursSpecification": {
                    "@type": "OpeningHoursSpecification",
                    "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
                    "opens": "11:00",
                    "closes": "21:00"
                }
            },
            {
                "@type": "WebPage",
                "url": window.location.href,
                "name": title,
                "description": description,
                "isPartOf": {"@id": window.location.origin + "/#organization"},
                "hasPart": [
                  {
                    "@type": "Article",
                    "headline": "Omega Pediatrics: Your Premier Concierge Doctor in Atlanta",
                    "author": {"@type": "Organization", "name": "Omega Pediatrics"},
                    "publisher": {"@id": window.location.origin + "/#organization"},
                    "mainEntityOfPage": {"@id": createPageUrl("BlogOmegaAtlanta")}
                  }
                ]
            }
        ]
    };
    
      const schemaScript = document.createElement('script');
      schemaScript.type = 'application/ld+json';
      schemaScript.innerHTML = JSON.stringify(schema);
      schemaScript.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(schemaScript);

      // Lazy load FAQ data only when needed
      import("../components/ExpandableFAQSection").then(module => {
        const homeFAQs = module.faqsByPage?.Home || [];
        setFaqsByPage({ Home: homeFAQs });
        
        if (Array.isArray(homeFAQs) && homeFAQs.length > 0) {
          const extractTextFromAnswer = (answer) => {
            if (typeof answer === 'string') {
              return answer.replace(/<[^>]*>?/gm, '');
            } else if (React.isValidElement(answer) || typeof answer === 'object') {
              return "Please visit our website for detailed information about this topic.";
            } else {
              return String(answer).replace(/<[^>]*>?/gm, '');
            }
          };

          const faqSchema = {
            "@context": "https://schema.org",
            "@type": "FAQPage",
            "mainEntity": homeFAQs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": {
                "@type": "Answer",
                "text": extractTextFromAnswer(faq.answer)
              }
            }))
          };
          const faqScript = document.createElement('script');
          faqScript.type = 'application/ld+json';
          faqScript.innerHTML = JSON.stringify(faqSchema);
          faqScript.setAttribute('data-b44-seo', 'true');
          document.head.appendChild(faqScript);
        }
      });
    };

    // PERF: Aggressively defer all non-critical SEO/Schema work until the browser is truly idle.
    // This is the key fix to prevent JavaScript execution from blocking the LCP render.
    if (window.requestIdleCallback) {
      window.requestIdleCallback(deferredOperations);
    } else {
      // Fallback for older browsers, with a longer delay
      setTimeout(deferredOperations, 1000);
    }
  }, []);

  return (
    <div>
      {/* Hero Section - Critical above-the-fold content loaded first */}
      <Suspense fallback={<SectionSkeleton type="hero" />}>
        <section className="relative overflow-hidden pt-10">
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-50/30 to-green-50/10" />
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <p className="text-xl font-semibold text-teal-600 animate-fade-in-up">Atlanta's leading provider of <span className="text-green-600"><Link to={createPageUrl("Services")} className="text-link">concierge pediatrics</Link></span></p>
                  <h1 className="text-4xl md:text-6xl font-bold text-gray-800 leading-tight animate-fade-in-up animation-delay-200">
                    Best <Link to={createPageUrl("Services")} className="text-link">Concierge Pediatrics</Link>
                    <span className="block text-teal-600">Made <span className="text-amber-500">Simple</span></span>
                  </h1>
                  <p className="text-xl text-gray-600 max-w-lg animate-fade-in-up animation-delay-400">
                    Welcome to Omega Pediatrics, offering <Link to={createPageUrl("Plans")} className="text-link">direct pay membership pediatrics (DPC pediatrics)</Link> to families across Atlanta, Roswell, Sandy Springs, Alpharetta, Buckhead, East Cobb, Kennesaw, and Cumming. Experience the <span className="font-semibold"><Link to={createPageUrl("Services")} className="text-link text-yellow-600">best pediatrics concierge service</Link></span> with unlimited visits and priority scheduling.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 animate-fade-in-up animation-delay-600">
                  <PrefetchLink to={createPageUrl("Plans")} prefetchOn="viewport" prefetchData={false}>
                    <Button size="lg" className="btn-enhanced bg-teal-600 hover:bg-teal-700 text-white px-8 py-4 text-lg">
                      View Plans & Pricing
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </PrefetchLink>
                  <PrefetchLink to={createPageUrl("Services")} prefetchOn="viewport" prefetchData={false}>
                    <Button variant="outline" size="lg" className="btn-enhanced px-8 py-4 text-lg border-gray-300 hover:bg-teal-50 hover:border-teal-300">
                      Explore Services
                    </Button>
                  </PrefetchLink>
                </div>

                <div className="bg-teal-50 border border-teal-200 rounded-2xl p-6 animate-fade-in-up animation-delay-600">
                  <h2 className="text-lg font-semibold text-teal-800 flex items-center gap-2 mb-2">
                    <Heart className="w-5 h-5 text-red-500" />
                    Limited Memberships Available
                  </h2>
                  <p className="text-teal-700">
                    To ensure the highest quality concierge pediatrics service, our memberships are limited. A waiting list may apply.
                  </p>
                </div>
              </div>

              <div className="relative animate-fade-in-up animation-delay-200">
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-200 to-green-200 rounded-3xl blur-2xl opacity-30" />
                <picture>
                  <source
                    media="(min-width: 1024px)"
                    srcSet="
                      https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=600 600w,
                      https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=800 800w
                    "
                    sizes="(min-width: 1024px) 600px, 400px"
                  />
                  <source
                    media="(min-width: 768px)"
                    srcSet="
                      https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=500 500w,
                      https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=700 700w
                    "
                    sizes="(min-width: 768px) 500px, 400px"
                  />
                  <img
                    src="https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=400"
                    srcSet="
                      https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=400 400w,
                      https://images.unsplash.com/photo-1609220136736-443140cffec6?auto=format&fit=crop&q=80&fm=webp&w=600 600w
                    "
                    sizes="(min-width: 1024px) 600px, (min-width: 768px) 500px, 400px"
                    alt="Happy mother with her two children enjoying quality pediatric care at Omega Pediatrics"
                    className="relative rounded-3xl shadow-2xl w-full h-64 sm:h-80 md:h-96 object-cover transition-transform duration-700 hover:scale-105"
                    fetchpriority="high"
                    loading="eager"
                    width="600"
                    height="400"
                    decoding="async"
                  />
                </picture>
              </div>
            </div>
          </div>
        </section>
      </Suspense>

      {/* Your Premier Concierge Doctor Section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">Your Premier <Link to={createPageUrl("BlogOmegaAtlanta")} className="text-link">Concierge Doctor in Atlanta</Link></h2>
            <p className="text-lg text-gray-600 mb-4">
              When you search for a "<strong>concierge doctor near me</strong>" in the Atlanta area, you're looking for more than just a physician – you're seeking a healthcare partner. At Omega Pediatrics, we embody what it means to be a modern <strong>concierge doctor</strong>. Our practice is built on a foundation of trust, accessibility, and deeply personalized care.
            </p>
            <p className="text-lg text-gray-600 mb-6">
              As one of the leading <strong>concierge doctors in Georgia</strong>, we offer a level of service designed to give you complete peace of mind.
            </p>
            <PrefetchLink to={createPageUrl("BlogOmegaAtlanta")} prefetchOn="viewport">
              <Button size="lg" variant="outline" className="btn-enhanced border-gray-300 hover:bg-teal-50 hover:border-teal-300">
                Learn Why We're Different
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </PrefetchLink>
          </div>
          <div className="relative h-64 sm:h-80 md:h-96">
             <picture>
               <source
                 media="(min-width: 768px)"
                 srcSet="
                   https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?auto=format&fit=crop&q=80&fm=webp&w=600 600w,
                   https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?auto=format&fit=crop&q=80&fm=webp&w=800 800w
                 "
                 sizes="(min-width: 768px) 600px, 400px"
               />
               <img 
                 src="https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?auto=format&fit=crop&q=80&fm=webp&w=400"
                 srcSet="
                   https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?auto=format&fit=crop&q=80&fm=webp&w=400 400w,
                   https://images.unsplash.com/photo-1532938911079-1b06ac7ceec7?auto=format&fit=crop&q=80&fm=webp&w=600 600w
                 "
                 sizes="(min-width: 768px) 600px, 400px"
                 alt="Compassionate pediatrician consulting with young patient and parent, showing the personal care approach of Omega Pediatrics" 
                 className="absolute inset-0 w-full h-full object-cover rounded-3xl shadow-xl"
                 loading="lazy"
                 width="600"
                 height="400"
                 decoding="async"
               />
             </picture>
          </div>
        </div>
      </section>

      {/* Benefits Section - Keep as is since it's above the fold */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4 animate-fade-in">
            Why Choose Atlanta's <Link to={createPageUrl("Services")} className="text-link">Best Concierge Pediatrics</Link>?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto animate-fade-in animation-delay-200">
            Our <Link to={createPageUrl("Plans")} className="text-link">direct pay membership pediatrics plans</Link> are designed to provide exceptional value and peace of mind for families across the Atlanta metro area.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <Card key={index} className={`card-hover border-gray-200 shadow-lg bg-white animate-fade-in-up animation-delay-${(index + 1) * 200}`}>
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-teal-50 rounded-2xl flex items-center justify-center mx-auto mb-6 transition-all duration-300 hover:bg-teal-100 hover:scale-110">
                  <benefit.icon className="w-8 h-8 text-teal-600" />
                </div>
                <h3 className="text-xl font-semibold text-gray-800 mb-3">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* What is a Concierge Doctor Callout */}
        <Card className="mt-16 bg-teal-50 border-teal-200">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-teal-800 mb-3">New to Concierge Care?</h3>
            <p className="text-lg text-teal-700 mb-4 max-w-2xl mx-auto">
              A <strong>concierge doctor</strong> provides personalized, membership-based care with enhanced access and longer appointments. It's a modern approach to healthcare focused on you.
            </p>
            <PrefetchLink to={createPageUrl("BlogWhatIsConciergeDoctor")} prefetchOn="viewport">
              <Button variant="link" className="text-lg text-link">
                Learn More About the Concierge Model <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </PrefetchLink>
          </CardContent>
        </Card>

        {/* Location-Specific Services Notice */}
        <div className="mt-16 bg-gradient-to-r from-blue-50 to-purple-50 rounded-3xl p-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Serving Families Throughout Atlanta</h3>
            <p className="text-lg text-gray-700 mb-4">
              Families in Roswell, Alpharetta, Sandy Springs, Buckhead, East Cobb, Kennesaw, and Cumming trust Omega Pediatrics for their children's health. Experience the benefits of our <Link to={createPageUrl("Services")} className="text-link-secondary">best concierge pediatrics service</Link> right in your neighborhood with convenient locations and personalized <Link to={createPageUrl("Plans")} className="text-link-secondary">DPC pediatrics care</Link>.
            </p>
            <div className="flex justify-center items-center gap-4 text-sm text-gray-600 flex-wrap">
              <span className="px-3 py-1 bg-white rounded-full">🏥 Roswell</span>
              <span className="px-3 py-1 bg-white rounded-full">🏥 Marietta</span>
              <span className="px-3 py-1 bg-white rounded-full">🏥 Riverdale</span>
              <span className="px-3 py-1 bg-white rounded-full">🚗 Serving All Metro Atlanta</span>
            </div>
          </div>
        </div>

        {/* Bilingual Services Notice */}
        <div className="mt-16 bg-gradient-to-r from-green-50 to-emerald-50 rounded-3xl p-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">Bilingual Care Available</h3>
            <p className="text-lg text-gray-700 mb-4">
              We proudly serve families in both English and Spanish. Our <Link to={createPageUrl("Services")} className="text-link text-green-600">bilingual staff and providers</Link>,
              including Dr. Michael Nwaneri, ensure clear communication and culturally sensitive care for all families.
            </p>
            <div className="flex justify-center items-center gap-4 text-sm text-gray-600">
              <span className="px-3 py-1 bg-white rounded-full">🇺🇸 English</span>
              <span className="px-3 py-1 bg-white rounded-full">🇪🇸 Español</span>
            </div>
          </div>
        </div>

        {/* Additional Membership Benefits */}
        <div className="mt-16 bg-gradient-to-r from-purple-50 to-blue-50 rounded-3xl p-8">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Exclusive <Link to={createPageUrl("Plans")} className="text-link-accent">Membership</Link> and <Link to={createPageUrl("Services")} className="text-link-accent">Concierge Benefits</Link></h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white rounded-2xl p-6 shadow-md transition-transform duration-300 hover:scale-105">
                <Users2 className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Private Parents Community</h4>
                <p className="text-gray-600">Access to our exclusive private parents group and paid online events and masterclasses</p>
              </div>
              <div className="bg-white rounded-2xl p-6 shadow-md transition-transform duration-300 hover:scale-105">
                <Heart className="w-12 h-12 text-pink-600 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-900 mb-3"><Link to={createPageUrl("Plans")} className="text-link">Annual Plan</Link> Perks</h4>
                <div className="text-gray-600 space-y-2">
                  <p><strong><Link to={createPageUrl("Services")} className="text-link">Sleep Consultations</Link>:</strong> 1-4 complimentary sessions with a baby sleep specialist physician</p>
                  <p><strong><Link to={createPageUrl("Services")} className="text-link">Lactation Support</Link>:</strong> 1-4 consultations based on your <Link to={createPageUrl("Plans")} className="text-link">membership tier</Link></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ALL BELOW-THE-FOLD SECTIONS ARE NOW LAZY LOADED */}
      <Suspense fallback={<SectionSkeleton type="pricing" />}>
        <PricingPreviewSection createPageUrl={createPageUrl} />
      </Suspense>
      
      {/* Is it Worth it Callout */}
      <div className="text-center bg-gray-50 py-12">
        <h3 className="text-2xl font-bold text-gray-800 mb-3">Are Concierge Doctors Worth It?</h3>
        <p className="text-lg text-gray-600 mb-4 max-w-2xl mx-auto">
          The value of a <strong>concierge doctor</strong> often outweighs the cost, especially with the peace of mind that comes from direct, priority access to your pediatrician.
        </p>
        <PrefetchLink to={createPageUrl("BlogAreTheyWorthIt")} prefetchOn="viewport">
          <Button variant="link" className="text-lg text-link">
            Explore the Value Proposition <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </PrefetchLink>
      </div>

      <Suspense fallback={<SectionSkeleton />}>
        <TestimonialsSection createPageUrl={createPageUrl} />
      </Suspense>
      
      <div className="mt-20">
        <Suspense fallback={<SectionSkeleton />}>
          <ExpandableFAQSection />
        </Suspense>
      </div>

      <Suspense fallback={<SectionSkeleton />}>
        <CtaSection createPageUrl={createPageUrl} />
      </Suspense>
    </div>
  );
}
