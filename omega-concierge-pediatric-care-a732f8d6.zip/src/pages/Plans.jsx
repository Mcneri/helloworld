
import React, { useState, useEffect, useCallback, lazy, Suspense, useMemo } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert } from "@/components/ui/alert";
import {
  Shield,
  CheckCircle,
  X,
  ArrowRight,
  Calculator,
  CreditCard,
  Banknote,
  Sparkles,
  Info,
  Loader2,
  Mail,
  Phone,
  ExternalLink
} from "lucide-react";
import { User } from "@/api/entities";
import { Member } from "@/api/entities";
import { updateSubscription } from "@/api/functions";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { ConciergeInquiry } from "@/api/entities";
import { Checkbox } from "@/components/ui/checkbox";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { useApiError, ApiErrorAlert } from "../components/ApiErrorHandler";
import SectionSkeleton from "../components/ui/SectionSkeleton";
import PlansSkeleton from "../components/ui/PlansSkeleton";
import PrefetchLink from "@/components/PrefetchLink";

// Lazy load sections
const DiamondConciergeSection = lazy(() => import("../components/plans/DiamondConciergeSection"));
const PaymentMethodsSection = lazy(() => import("../components/plans/PaymentMethodsSection"));
const MiniFAQ = lazy(() => import("../components/MiniFAQ"));

// PERF: Moved static `plans` array outside the component function.
// This prevents it from being recreated on every single render of the Plans component.
const plans = [
    {
        name: "Bronze",
        tier: "bronze",
        priceIdMonthly: 'price_1RpgDkJtNJAGE3wfLxgNJEE6', // Monthly
        priceIdAnnual: 'price_1RpgDkJtNJAGE3wfcT2O2HLl',  // Annual
        monthly: 250,
        annual: 2190,
        savingsPercentage: "27%",
        description: "Essential care for your child's wellness.",
        features: [
            "Unlimited wellness visits",
            "Unlimited concern visits",
            "Unlimited ADHD visits",
            "Clogged ear irrigation",
            "School/daycare/sports forms",
            "Home Visits (With diamond upgrade)", // Explicitly not included, but listed for comparison
            "Telemedicine visits", // Explicitly not included, but listed for comparison
            "Rapid tests", // Explicitly not included, but listed for comparison
            "Medical ear piercing with 1-year re-piercings*", // Explicitly not included, but listed for comparison
            "All vaccines included", // Explicitly not included, but listed for comparison
            "Newborn circumcision", // Explicitly not included, but listed for comparison
            "Direct messaging to MD's cell phone", // Explicitly not included, but listed for comparison
            "Priority scheduling", // Explicitly not included, but listed for comparison
            "Extended consultations", // Explicitly not included, but listed for comparison
        ],
        annualPerks: [
            "1 complimentary sleep consultation",
            "1 complimentary lactation consultation"
        ],
        color: "amber",
        cta: "Choose Bronze",
    },
    {
        name: "Silver",
        tier: "silver",
        priceIdMonthly: 'price_1RpgFxJtNJAGE3wfaeZs2nBD', // Monthly
        priceIdAnnual: 'price_1RpgHNJtNJAGE3wfTVVWXZF7',  // Annual
        monthly: 400,
        annual: 3504,
        savingsPercentage: "27%",
        description: "Enhanced care with more services included.",
        popular: true,
        features: [
            "Unlimited wellness visits",
            "Unlimited concern visits",
            "Unlimited ADHD visits",
            "Clogged ear irrigation",
            "School/daycare/sports forms",
            "Home Visits (With diamond upgrade)",
            "Unlimited telemedicine visits",
            "Rapid tests (Covid, Flu, RSV, Strep)",
            "Medical ear piercing with 1-year re-piercings*",
            "All vaccines included",
            "Newborn circumcision",
            "Direct messaging to MD's cell phone",
            "Priority scheduling",
            "Extended consultation times",
        ],
        annualPerks: [
            "2 complimentary sleep consultations",
            "2 complimentary lactation consultations"
        ],
        color: "slate",
        cta: "Choose Silver",
    },
    {
        name: "Gold",
        tier: "gold",
        priceIdMonthly: 'price_1RpgJ2JtNJAGE3wfg2dbIbdc', // Monthly
        priceIdAnnual: 'price_1RpgKhJtNJAGE3wfYlAVgGim',  // Annual
        monthly: 500,
        annual: 4380,
        savingsPercentage: "27%",
        description: "Our most comprehensive care plan.",
        features: [
            "Unlimited wellness visits",
            "Unlimited concern visits",
            "Unlimited ADHD visits",
            "Clogged ear irrigation",
            "School/daycare/sports forms",
            "Home Visits (With diamond upgrade)",
            "Unlimited telemedicine visits",
            "Rapid tests (Covid, Flu, RSV, Strep)",
            "Medical ear piercing with 1-year re-piercings*",
            "All vaccines included",
            "Newborn circumcision",
            "Direct messaging to MD's cell phone ($105/month value)",
            "Priority scheduling",
            "Extended consultation times",
        ],
        annualPerks: [
            "3 complimentary sleep consultations",
            "3 complimentary lactation consultations"
        ],
        color: "yellow",
        cta: "Choose Gold",
    },
];

const planOrder = ['bronze', 'silver', 'gold'];

const planFeatureInclusion = {
  bronze: {
    "Unlimited wellness visits": true,
    "Unlimited concern visits": true,
    "Unlimited ADHD visits": true,
    "Clogged ear irrigation": true,
    "School/daycare/sports forms": true,
    "Home Visits (With diamond upgrade)": false,
    "Telemedicine visits": false,
    "Rapid tests": false,
    "Medical ear piercing with 1-year re-piercings*": false,
    "All vaccines included": false,
    "Newborn circumcision": false,
    "Direct messaging to MD's cell phone": false,
    "Priority scheduling": false,
    "Extended consultations": false,
  },
  silver: {
    "Unlimited wellness visits": true,
    "Unlimited concern visits": true,
    "Unlimited ADHD visits": true,
    "Clogged ear irrigation": true,
    "School/daycare/sports forms": true,
    "Home Visits (With diamond upgrade)": false,
    "Unlimited telemedicine visits": true,
    "Rapid tests (Covid, Flu, RSV, Strep)": true,
    "Medical ear piercing with 1-year re-piercings*": true,
    "All vaccines included": false,
    "Newborn circumcision": false,
    "Direct messaging to MD's cell phone": false,
    "Priority scheduling": true,
    "Extended consultation times": false,
  },
  gold: {
    "Unlimited wellness visits": true,
    "Unlimited concern visits": true,
    "Unlimited ADHD visits": true,
    "Clogged ear irrigation": true,
    "School/daycare/sports forms": true,
    "Home Visits (With diamond upgrade)": false,
    "Unlimited telemedicine visits": true,
    "Rapid tests (Covid, Flu, RSV, Strep)": true,
    "Medical ear piercing with 1-year re-piercings*": true,
    "All vaccines included": true,
    "Newborn circumcision": true,
    "Direct messaging to MD's cell phone ($105/month value)": true,
    "Priority scheduling": true,
    "Extended consultation times": true,
  }
};

const planStyles = {
    amber: {
        cardBorder: "border-amber-300",
        headerBg: "bg-amber-50",
        iconBg: "bg-gradient-to-br from-amber-500 to-orange-600",
        buttonClasses: "bg-gradient-to-r from-amber-600 to-orange-700 hover:from-amber-700 hover:to-orange-800",
        iconEffect: "", // No specific effect for bronze
    },
    slate: {
        cardBorder: "border-slate-300",
        headerBg: "bg-slate-50",
        iconBg: "bg-gradient-to-br from-slate-400 to-gray-500 shadow-md",
        buttonClasses: "bg-gradient-to-r from-slate-400 to-gray-500 hover:from-slate-500 hover:to-gray-600 shadow-lg hover:shadow-xl",
        iconEffect: "animate-pulse",
    },
    yellow: {
        cardBorder: "border-yellow-200",
        headerBg: "bg-yellow-50",
        iconBg: "bg-gradient-to-br from-yellow-400 to-amber-500 shadow-lg",
        buttonClasses: "bg-gradient-to-r from-yellow-400 to-amber-500 hover:from-yellow-500 hover:to-amber-600 shadow-xl hover:shadow-2xl transform hover:scale-[1.02] transition-all duration-300",
        iconEffect: "animate-bounce",
    }
};

function UpgradeButton({ targetPlan, memberDetails, onUpgrade }) {
    const [isUpgrading, setIsUpgrading] = useState(false);

    const newPriceId = targetPlan && memberDetails.payment_frequency ?
        (memberDetails.payment_frequency === 'monthly' ? targetPlan.priceIdMonthly : targetPlan.priceIdAnnual) : null;

    const handleUpgradeClick = async () => {
        setIsUpgrading(true);
        try {
            if (!memberDetails.stripe_subscription_id || !newPriceId) {
                throw new Error("Missing subscription ID or new price ID for upgrade.");
            }
            await updateSubscription({
                subscriptionId: memberDetails.stripe_subscription_id,
                newPriceId
            });
            onUpgrade();
        } catch (error) {
            console.error("Upgrade failed:", error);
            alert(`Upgrade failed: ${error.message}`);
        } finally {
            setIsUpgrading(false);
        }
    };

    const buttonClasses = planStyles[targetPlan.color]?.buttonClasses || '';

    return (
        <AlertDialog>
            <AlertDialogTrigger asChild>
                <Button className={`w-full ${buttonClasses} text-white`} size="lg" disabled={!newPriceId} aria-label={`Upgrade to ${targetPlan.name} plan`}>
                    Upgrade to {targetPlan.name}
                    <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
                <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Plan Upgrade</AlertDialogTitle>
                    <AlertDialogDescription>
                        You are about to upgrade to the {targetPlan.name} plan. Stripe will immediately charge you a prorated amount for the remainder of the current billing cycle. This action cannot be undone.
                    </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleUpgradeClick} disabled={isUpgrading}>
                        {isUpgrading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin"/> Upgrading...</> : 'Confirm Upgrade'}
                    </AlertDialogAction>
                </AlertDialogFooter>
            </AlertDialogContent>
        </AlertDialog>
    );
}

export default function Plans() {
  const navigate = useNavigate();
  const [billingCycle, setBillingCycle] = useState("annual");
  const [memberStatus, setMemberStatus] = useState({
    isMember: false,
    details: null
  });
  const [memberStatusLoading, setMemberStatusLoading] = useState(false);
  const [upgradeMessage, setUpgradeMessage] = useState('');
  const { error: apiError, handleApiCall, clearError: clearApiError } = useApiError();

  const handleUpgradeSuccess = () => {
    setUpgradeMessage("Upgrade successful! Your plan has been updated. Reloading page...");
    setTimeout(() => window.location.reload(), 3000);
  };

  // Enhanced member status check with rate limiting and caching - wrapped in useCallback
  const checkMemberStatus = useCallback(async (retryCount = 0) => {
    // Prevent multiple simultaneous calls
    if (memberStatusLoading) return;
    
    // Check if we have cached data (valid for 5 minutes)
    const cacheKey = 'memberStatus';
    const cacheTimestampKey = 'memberStatusTimestamp';
    const cachedStatus = localStorage.getItem(cacheKey);
    const cachedTimestamp = localStorage.getItem(cacheTimestampKey);
    
    if (cachedStatus && cachedTimestamp) {
      const now = Date.now();
      const fiveMinutes = 5 * 60 * 1000;
      const cacheAge = now - parseInt(cachedTimestamp);
      
      if (cacheAge < fiveMinutes) {
        console.log('Using cached member status');
        setMemberStatus(JSON.parse(cachedStatus));
        return;
      }
    }

    setMemberStatusLoading(true);
    
    try {
      const user = await User.me();
      if (user && user.member_id) {
        try {
          const memberDetails = await Member.get(user.member_id);
          const statusData = memberDetails && memberDetails.status === 'active' 
            ? { isMember: true, details: memberDetails }
            : { isMember: false, details: memberDetails };
          
          setMemberStatus(statusData);
          
          // Cache the result
          localStorage.setItem(cacheKey, JSON.stringify(statusData));
          localStorage.setItem(cacheTimestampKey, Date.now().toString());
          
        } catch (memberError) {
          console.warn("Member record not found for user, clearing member_id. Error details:", memberError);
          
          if (memberError.response && memberError.response.status === 500) {
            try {
              await User.updateMyUserData({ member_id: null });
              console.info("Successfully cleared invalid member_id from user record");
            } catch (updateError) {
              console.error("Failed to clear invalid member_id:", updateError);
            }
          }
          
          const statusData = { isMember: false, details: null };
          setMemberStatus(statusData);
          localStorage.setItem(cacheKey, JSON.stringify(statusData));
          localStorage.setItem(cacheTimestampKey, Date.now().toString());
        }
      } else {
        const statusData = { isMember: false, details: null };
        setMemberStatus(statusData);
        localStorage.setItem(cacheKey, JSON.stringify(statusData));
        localStorage.setItem(cacheTimestampKey, Date.now().toString());
      }
    } catch (e) {
      if (e.response && e.response.status === 429) {
        // Handle rate limiting with exponential backoff
        const maxRetries = 3;
        if (retryCount < maxRetries) {
          const delay = Math.pow(2, retryCount) * 1000; // 1s, 2s, 4s
          console.warn(`Rate limited, retrying in ${delay}ms (attempt ${retryCount + 1}/${maxRetries})`);
          setTimeout(() => checkMemberStatus(retryCount + 1), delay);
          return;
        } else {
          console.error("Rate limiting: Max retries exceeded");
          // Use cached data if available, even if expired
          if (cachedStatus) {
            console.log('Using expired cached member status due to rate limiting');
            setMemberStatus(JSON.parse(cachedStatus));
          } else {
            setMemberStatus({ isMember: false, details: null });
          }
        }
      } else if (e.response && e.response.status === 401) {
        console.info("User not authenticated on Plans page - this is normal for public access");
        setMemberStatus({ isMember: false, details: null });
      } else {
        console.error("Unexpected error checking member status:", e);
        // Use cached data if available
        if (cachedStatus) {
          console.log('Using cached member status due to error');
          setMemberStatus(JSON.parse(cachedStatus));
        } else {
          setMemberStatus({ isMember: false, details: null });
        }
      }
    } finally {
      setMemberStatusLoading(false);
    }
  }, [memberStatusLoading]); // Include memberStatusLoading as dependency

  // Memoize plansFAQs to ensure stability for useEffect dependency
  const plansFAQs = React.useMemo(() => [
    {
      question: "What are the main differences between Bronze, Silver, and Gold plans?",
      answer: <>
        <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Bronze includes essential DPC pediatrics services</Link> like <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>unlimited wellness and concern visits</Link>. <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Silver adds telemedicine, rapid tests, and ear piercing</Link> for enhanced <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>concierge pediatrics care</Link>. <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Gold includes everything plus all vaccines, circumcision, and direct messaging</Link> with providers - representing the <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>best pediatrics concierge service</Link>.
      </>
    },
    {
      question: "Are there financial benefits to choosing annual payment?",
      answer: <>
        Yes, <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>annual payment offers significant savings of approximately 27% compared to monthly billing</Link>, plus additional perks like complimentary <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>sleep and lactation consultations</Link> for families throughout Atlanta.
      </>
    },
    {
      question: "How do multi-child discounts work?",
      answer: <>
        Our <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>concierge pediatrics</Link> <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>multi-child discounts</Link> apply per child: the first child pays full price, the second receives a 15% discount, the third gets 30%, and the fourth or more children receive 45% off their respective fees.
      </>
    },
    {
      question: "What is the minimum commitment for monthly plans?",
      answer: <>
        <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Monthly direct pay membership pediatrics plans require a 2-month minimum commitment</Link>. You pay for the first and last month upfront, allowing you to cancel up to 5 weeks before your subscription period ends without being billed for additional months.
      </>
    },
    {
      question: "How does the cancellation policy work?",
      answer: <>
        <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Memberships can be cancelled</Link> by notifying us at least 5 weeks before the end of your paid term. This ensures you won't be billed for the final month, as you've already paid for it upfront.
      </>
    },
    {
      question: "Can I upgrade my plan after joining?",
      answer: <>
        Yes, you can <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>upgrade your DPC pediatrics plan</Link> at any time with prorated billing. Downgrades are only available at renewal time to ensure continuity of care.
      </>
    },
    {
      question: "What's included in the annual plan bonuses?",
      answer: <>
        <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Annual members</Link> receive complimentary <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>sleep consultations and lactation support</Link>: Bronze gets 1 each, Silver gets 2 each, and Gold gets 3 each.
      </>
    },
    {
      question: "Are vaccines included in all plans?",
      answer: <>
        <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>All vaccines are only included in the Gold and Diamond Concierge plans</Link>. <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>Bronze and Silver members</Link> would need separate payment or insurance coverage for vaccines.
      </>
    },
    {
      question: "What about the ear piercing re-piercings benefit?",
      answer: <>
        The <Link to={createPageUrl('Services')} className='text-teal-600 hover:underline hover:text-teal-700'>medical ear piercing service includes free unlimited re-piercings for 1 year</Link>, but this benefit only applies while your <Link to={createPageUrl('Plans')} className='text-teal-600 hover:underline hover:text-teal-700'>membership is maintained</Link>. If you cancel your membership, the re-piercing benefit ends.
      </>
    }
  ], []); // Empty dependency array since the content is static

  useEffect(() => {
    // SEO and Metadata Setup
    document.querySelectorAll('[data-b44-seo="true"]').forEach(el => el.remove());

    const title = "Best Concierge Pediatrics Plans | DPC Membership Options Atlanta GA";
    const description = "Compare Bronze, Silver & Gold concierge pediatrics plans in Atlanta. Unlimited visits, priority care & 27% annual savings. Best DPC pediatrics for families.";
    const imageUrl = "https://images.unsplash.com/photo-1609220136736-443140cffec6?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.0.3";
    
    document.title = title;

    const createMetaTag = (attrs) => {
        const el = document.createElement('meta');
        Object.keys(attrs).forEach(attr => el.setAttribute(attr, attrs[attr]));
        el.setAttribute('data-b44-seo', 'true');
        document.head.appendChild(el);
    };

    createMetaTag({ name: 'description', content: description });
    
    // Twitter Card
    createMetaTag({ name: 'twitter:card', content: 'summary_large_image' });
    createMetaTag({ name: 'twitter:title', content: title });
    createMetaTag({ name: 'twitter:description', content: description });
    createMetaTag({ name: 'twitter:image', content: imageUrl });

    // Combined Schema.org
    const schema = {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "WebPage",
          "name": "Omega Pediatrics Membership Plans",
          "description": description,
          "url": window.location.href,
          "mainEntity": {
            "@type": "ItemList",
            "itemListElement": plans.map(plan => ({
              "@type": "Service",
              "name": `${plan.name} Plan - ${plan.description}`,
              "description": plan.description,
              "provider": { "@id": window.location.origin + "/#organization" }
            })).concat([
              { 
                "@type": "Service", 
                "name": "Diamond Concierge Plan - Ultimate Concierge Pediatrics", 
                "description": "Ultimate luxury pediatric care with home visits and personalized concierge service.",
                "provider": { "@id": window.location.origin + "/#organization" }
              }
            ])
          },
          "hasPart": [
            {
              "@type": "Article",
              "headline": "Are Concierge Doctors Worth It? Understanding the Value",
              "author": {"@type": "Organization", "name": "Omega Pediatrics"},
              "publisher": {"@id": window.location.origin + "/#organization"},
              "mainEntityOfPage": {"@id": createPageUrl("BlogAreTheyWorthIt")}
            },
            {
              "@type": "Article",
              "headline": "Concierge Doctor Fees: Deductibility, Medicare, and HSA Eligibility",
              "author": {"@type": "Organization", "name": "Omega Pediatrics"},
              "publisher": {"@id": window.location.origin + "/#organization"},
              "mainEntityOfPage": {"@id": createPageUrl("BlogFeesAndInsurance")}
            }
          ]
        },
        {
            "@type": "Organization",
            "@id": window.location.origin + "/#organization",
            "name": "Omega Pediatrics",
            "url": window.location.origin,
            "logo": imageUrl,
            "contactPoint": {
                "@type": "ContactPoint",
                "telephone": "+1-470-485-6342",
                "contactType": "customer service"
            }
        },
        {
            "@type": "LocalBusiness",
            "@id": window.location.origin + "/#localbusiness",
            "name": "Omega Pediatrics",
            "image": imageUrl,
            "telephone": "+1-470-485-6342",
            "url": "https://members.omegapediatrics.com/",
            "priceRange": "$250-$500",
            "address": [
                {"@type": "PostalAddress", "streetAddress": "1305 Hembree Road STE 203", "addressLocality": "Roswell", "addressRegion": "GA", "postalCode": "30076", "addressCountry": "US"},
                {"@type": "PostalAddress", "streetAddress": "1841 Piedmont Road NE, STE 100", "addressLocality": "Marietta", "addressRegion": "GA", "postalCode": "30066", "addressCountry": "US"},
                {"@type": "PostalAddress", "streetAddress": "65742 River Park Drive", "addressLocality": "Riverdale", "addressRegion": "GA", "postalCode": "30274", "addressCountry": "US"}
            ],
            "areaServed": ["Atlanta", "Roswell", "Sandy Springs", "Alpharetta", "Buckhead", "East Cobb", "Kennesaw", "Cumming"]
        }
      ]
    };
    
    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.innerHTML = JSON.stringify(schema);
    schemaScript.setAttribute('data-b44-seo', 'true');
    document.head.appendChild(schemaScript);

    // Schema.org - FAQPage - Safe processing of FAQ answers
    if (plansFAQs.length > 0) {
      const extractTextFromAnswer = (answer) => {
        if (typeof answer === 'string') {
          return answer.replace(/<[^>]*>?/gm, '');
        } else if (React.isValidElement(answer) || typeof answer === 'object') {
          return "Please visit our website for detailed information about this topic.";
        } else {
          return String(answer).replace(/<[^>]*>?/gm, '');
        }
      };

      const faqSchema = {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": plansFAQs.map(faq => ({
          "@type": "Question",
          "name": faq.question,
          "acceptedAnswer": {
            "@type": "Answer",
            "text": extractTextFromAnswer(faq.answer)
          }
        }))
      };
      const faqScript = document.createElement('script');
      faqScript.type = 'application/ld+json';
      faqScript.innerHTML = JSON.stringify(faqSchema);
      faqScript.setAttribute('data-b44-seo', 'true');
      document.head.appendChild(faqScript);
    }

    // Check member status with improved error handling
    checkMemberStatus();
  }, [checkMemberStatus, plansFAQs]); // Include dependencies

  const calculateSavings = useCallback((plan) => {
    // Calculates absolute dollar savings for annual plan
    if (billingCycle === "annual") {
      return (plan.monthly * 12) - plan.annual;
    }
    return 0;
  }, [billingCycle]);

  const getPrice = useCallback((plan) => {
    if (billingCycle === "annual") {
      return plan.annual;
    }
    return plan.monthly;
  }, [billingCycle]);

  return (
    <React.Suspense fallback={<PlansSkeleton />}>
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-white to-green-50">
        {/* Header */}
        <section className="relative bg-gradient-to-r from-teal-600 via-purple-600 to-cyan-600 text-white overflow-hidden">
          {/* Animated background elements */}
          <div className="absolute inset-0">
            <div className="absolute top-8 left-16 w-16 h-16 bg-blue-300/20 rounded-full animate-bounce"></div>
            <div className="absolute bottom-24 right-1/4 w-20 h-20 bg-indigo-300/20 rounded-full animate-pulse delay-500"></div>
          </div>
          
          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
            <div className="text-center">
              <div className="mb-6">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-white/10 rounded-full mb-4 animate-pulse">
                  <Shield className="w-10 h-10 text-blue-200" />
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 animate-fade-in-up">
                Choose Your <span className="text-yellow-300">Perfect</span> <Link to={createPageUrl("Services")} className="text-yellow-300 hover:underline">DPC Plan</Link>
              </h1>
              <p className="text-xl text-teal-100 max-w-3xl mx-auto animate-fade-in-up animation-delay-200">
                Comprehensive <Link to={createPageUrl("Services")} className="text-teal-200 hover:underline">concierge pediatrics care</Link> tailored to families in Atlanta, Roswell, Alpharetta, Sandy Springs, Buckhead, East Cobb, Kennesaw, and Cumming. All <Link to={createPageUrl("Plans")} className="text-teal-200 hover:underline">direct pay membership pediatrics plans</Link> include <Link to={createPageUrl("Services")} className="text-teal-200 hover:underline">unlimited wellness visits and concern visits</Link>.
              </p>
              
              <div className="mt-6 flex justify-center animate-fade-in-up animation-delay-400">
                <div className="flex space-x-2">
                  <div className="w-2 h-2 bg-yellow-300 rounded-full animate-ping"></div>
                  <div className="w-2 h-2 bg-pink-300 rounded-full animate-ping delay-100"></div>
                  <div className="w-2 h-2 bg-blue-300 rounded-full animate-ping delay-200"></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Main Content Sections */}
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {apiError && (
            <ApiErrorAlert 
              error={apiError} 
              onDismiss={clearApiError}
              className="mb-6"
            />
          )}

          {/* Billing Toggle */}
          <div className="text-center mb-12">
            <div className="bg-teal-50 border border-teal-200 rounded-xl p-4 inline-block mb-4">
              <p className="font-semibold text-teal-800">Note: To ensure quality <Link to={createPageUrl("Services")} className="text-teal-800 hover:underline">concierge pediatrics service</Link>, memberships are limited. A waiting list may apply.</p>
            </div>
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 inline-block mb-4">
              <p className="font-semibold text-blue-800">Monthly <Link to={createPageUrl("Plans")} className="text-blue-800 hover:underline">DPC Plans</Link>: 2-month minimum commitment (pay first and last month upfront)</p>
            </div>
            <p className="text-lg text-gray-600 mb-4">Multi-child discounts are available for our <Link to={createPageUrl("Plans")} className="text-teal-600 hover:underline hover:text-teal-700">direct pay membership pediatrics</Link> (up to 45% off) and applied on the sign-up page.</p>
            <div className="inline-flex items-center bg-white rounded-2xl p-2 shadow-lg border">
              <button
                onClick={() => setBillingCycle("monthly")}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                  billingCycle === "monthly"
                    ? "bg-teal-600 text-white shadow-md"
                    : "text-gray-600 hover:text-teal-600"
                }`}
                aria-label="Switch to monthly billing cycle"
              >
                <CreditCard className="w-5 h-5" />
                Monthly (2-month min)
              </button>
              <button
                onClick={() => setBillingCycle("annual")}
                className={`flex items-center gap-2 px-6 py-3 rounded-xl font-medium transition-all ${
                  billingCycle === "annual"
                    ? "bg-green-600 text-white shadow-md"
                    : "text-gray-600 hover:text-green-600"
                }`}
                aria-label="Switch to annual billing cycle with 27% savings"
              >
                <Banknote className="w-5 h-5" />
                Annual
                <Badge className="bg-green-100 text-green-800 ml-2">Save 27%</Badge>
              </button>
            </div>
          </div>

          {upgradeMessage && (
              <div className="mb-8">
                  <Alert className="bg-green-50 border-green-200 text-green-800 flex items-center gap-2">
                      <CheckCircle className="h-5 w-5 flex-shrink-0"/>
                      <p>{upgradeMessage}</p>
                  </Alert>
              </div>
          )}

          {/* Show loading state for member status */}
          {memberStatusLoading && (
            <div className="mb-6 bg-blue-50 border border-blue-200 rounded-xl p-4 text-center">
              <div className="flex items-center justify-center gap-2">
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                <span className="text-blue-800">Checking membership status...</span>
              </div>
            </div>
          )}

          {/* Savings Calculator */}
          {billingCycle === "annual" && (
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-2xl p-8 mb-12">
              <div className="text-center">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <Calculator className="w-8 h-8 text-green-600" />
                  <h2 className="text-2xl font-bold text-green-800">See Your Annual Savings</h2>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {plans.map((plan, index) => (
                    <div key={index} className="text-center bg-white/50 p-4 rounded-lg">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{plan.name} Plan</h3>
                      <div className="space-y-1 text-gray-700">
                        <div><span className="font-medium">If you pay Monthly:</span> ${plan.monthly} x 12 = ${plan.monthly * 12}</div>
                        <div><span className="font-medium">If you pay Annually:</span> ${plan.annual}</div>
                        <div className="text-xl font-bold text-green-600 mt-2">You save ${calculateSavings(plan)}!</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Are they Worth it? Section */}
          <div className="mb-12 bg-white border border-gray-200 rounded-2xl p-8 animate-fade-in text-center shadow-lg">
            <h2 className="text-2xl font-bold text-gray-800 mb-3">Considering the Investment?</h2>
            <p className="text-lg text-gray-600 mb-4 max-w-3xl mx-auto">
              Wondering "<strong>are concierge doctors worth it</strong>"? While there's a membership fee, the value from unlimited visits, direct access to your pediatrician, and total peace of mind often makes it a wise decision for your family's health.
            </p>
            <PrefetchLink to={createPageUrl("BlogAreTheyWorthIt")} prefetchOn="viewport">
              <Button variant="link" className="text-lg text-teal-600 hover:text-teal-700">
                Read Our Full Value Analysis <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </PrefetchLink>
          </div>

          {/* Plans Comparison */}
          <div className="mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center animate-fade-in">Compare Our Concierge Pediatrics Plans</h2>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {plans.map((plan, index) => {
                const isCurrentPlan = memberStatus.isMember &&
                  memberStatus.details.plan_tier === plan.tier;

                const currentPlanIndex = memberStatus.isMember ? planOrder.indexOf(memberStatus.details.plan_tier) : -1;
                const targetPlanIndex = planOrder.indexOf(plan.tier);
                const isUpgradeOption = memberStatus.isMember &&
                                      targetPlanIndex > currentPlanIndex;
                
                const style = planStyles[plan.color];

                return (
                  <Card key={plan.tier} className={`card-hover relative border-2 ${style.cardBorder} shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-2 ${plan.popular ? 'ring-2 ring-teal-500' : ''} ${isCurrentPlan ? 'bg-gradient-to-br from-gray-50 via-white to-gray-100' : ''} animate-fade-in-up animation-delay-${(index + 1) * 200}`}>
                    {plan.popular && !isCurrentPlan && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                        <Badge className="bg-teal-600 text-white px-4 py-2 text-sm font-medium">
                          Most Popular
                        </Badge>
                      </div>
                    )}

                    {isCurrentPlan && (
                      <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 z-20">
                        <Badge className="bg-green-600 text-white px-4 py-2 text-sm font-medium">
                          Your Current Plan
                        </Badge>
                      </div>
                    )}

                    <CardHeader className={`text-center ${isCurrentPlan ? 'bg-gradient-to-r from-green-50 to-emerald-50' : style.headerBg} rounded-t-lg ${isCurrentPlan ? 'relative overflow-hidden' : ''}`}>
                      {isCurrentPlan && (
                        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent transform -skew-y-1 animate-pulse opacity-50"></div>
                      )}
                      <div className={`w-16 h-16 ${isCurrentPlan ? 'bg-gradient-to-br from-green-500 to-emerald-600' : style.iconBg} rounded-2xl flex items-center justify-center mx-auto mb-4 ${style.iconEffect || ''} relative z-10 transition-all duration-300 hover:scale-110`}>
                        <Shield className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-2xl font-bold text-gray-900 relative z-10">{plan.name}</CardTitle>
                      <p className="text-gray-600 relative z-10">{plan.description}</p>

                      <div className="mt-6 relative z-10">
                        <div className="text-4xl font-bold text-gray-900">
                          ${billingCycle === "annual" ? plan.annual : (plan.monthly * 2)}
                        </div>
                        <div className="text-gray-600">
                          {billingCycle === "annual" ? "per year" : "for 2 months (minimum)"}
                        </div>
                        {billingCycle === "annual" && (
                          <div className="mt-2 p-3 bg-green-100 rounded-lg">
                            <div className="text-lg font-semibold text-green-800">
                              Save ${calculateSavings(plan)}
                            </div>
                            <div className="text-sm text-green-700">vs monthly billing</div>
                          </div>
                        )}
                        {billingCycle === "monthly" && (
                          <div className="mt-2 p-3 bg-blue-100 rounded-lg">
                            <div className="text-sm text-blue-800">
                              Pay first & last month upfront
                            </div>
                            <div className="text-xs text-blue-600">
                              ${plan.monthly}/month after initial payment
                            </div>
                          </div>
                        )}
                      </div>
                    </CardHeader>

                    <CardContent className={`p-8 ${isCurrentPlan ? 'bg-gradient-to-b from-green-50/30 to-white' : ''}`}>
                      <div className="space-y-4 mb-8">
                        {plan.features.map((featureName, idx) => {
                          const isIncluded = planFeatureInclusion[plan.tier]?.[featureName] || false;
                          return (
                            <div key={idx} className="flex items-center gap-3">
                              {isIncluded ? (
                                <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                              ) : (
                                <X className="w-5 h-5 text-gray-300 flex-shrink-0" />
                              )}
                              <span className={`${isIncluded ? 'text-gray-700' : 'text-gray-400'}`}>
                                {featureName}
                              </span>
                            </div>
                          );
                        })}
                      </div>

                      {isCurrentPlan ? (
                        <Button
                          disabled
                          className="w-full bg-green-600 text-white cursor-not-allowed opacity-75"
                          size="lg"
                          aria-label="This is your current plan"
                        >
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Current Plan
                        </Button>
                      ) : isUpgradeOption && memberStatus.details.stripe_subscription_id ? (
                          <UpgradeButton
                              targetPlan={plan}
                              memberDetails={memberStatus.details}
                              onUpgrade={handleUpgradeSuccess}
                          />
                      ) : (
                        <Link to={createPageUrl("Join") + `?plan=${plan.tier}&billing=${billingCycle}`}>
                          <Button
                            className={`w-full ${style.buttonClasses} text-white transition-transform hover:scale-105 active:scale-100`}
                            size="lg"
                            aria-label={isUpgradeOption ? `Upgrade to ${plan.name} plan` : `Choose ${plan.name} plan`}
                          >
                            {isUpgradeOption ? `Upgrade to ${plan.name}` : `Choose ${plan.name}`}
                            <ArrowRight className="w-5 h-5 ml-2" />
                          </Button>
                        </Link>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Financial Questions Callout */}
          <div className="mt-12 bg-blue-50 border border-blue-200 rounded-2xl p-6 animate-fade-in shadow-lg">
            <h3 className="text-lg font-semibold text-blue-800 mb-3 flex items-center gap-2">
              <Info className="w-5 h-5" />
              Payment & Insurance Questions?
            </h3>
            <div className="space-y-2 text-blue-700">
              <p>
                Have questions like "<strong>do concierge doctors accept medicare</strong>" or "<strong>are concierge doctor fees HSA eligible</strong>"? We've got answers to help you understand your options.
                <Link to={createPageUrl("BlogFeesAndInsurance")} className="text-blue-800 font-semibold hover:underline ml-2">
                  Learn more here.
                </Link>
              </p>
            </div>
          </div>

          {/* Important Policy Notice */}
          <div className="mb-12 bg-orange-50 border border-orange-200 rounded-2xl p-6 animate-fade-in shadow-lg">
            <h3 className="text-lg font-semibold text-orange-800 mb-3 flex items-center gap-2">
              <Info className="w-5 h-5" />
              Important <Link to={createPageUrl("Plans")} className="text-orange-800 hover:underline">DPC Pediatrics Policy</Link> Updates
            </h3>
            <div className="space-y-2 text-orange-700">
              <p><strong>Monthly Plans:</strong> Our <Link to={createPageUrl("Plans")} className="text-orange-700 hover:underline">direct pay membership pediatrics plans require 2-month minimum commitment</Link>. You pay for the first and last month upfront.</p>
              <p><strong><Link to={createPageUrl("Services")} className="text-orange-700 hover:underline">Concierge Service</Link> Cancellation:</strong> Cancel up to 5 weeks before your subscription period ends to avoid additional billing.</p>
              <p><strong>Ear Piercing Benefits:</strong> Free unlimited re-piercings for 1 year only apply while <Link to={createPageUrl("Services")} className="text-orange-700 hover:underline">concierge pediatrics membership</Link> is maintained.*</p>
            </div>
          </div>

          {/* Lazy Loaded Concierge Plan Section */}
          <Suspense fallback={<SectionSkeleton />}>
              <DiamondConciergeSection memberStatus={memberStatus} />
          </Suspense>
        </section>

        {/* Lazy Loaded Mini FAQ Section */}
        <Suspense fallback={<SectionSkeleton />}>
          <MiniFAQ faqs={plansFAQs} title="Plan Questions" />
        </Suspense>

        {/* Lazy Loaded Payment Methods Section */}
        <Suspense fallback={<div className="h-64" />}>
            <PaymentMethodsSection />
        </Suspense>
      </div>
    </React.Suspense>
  );
}
